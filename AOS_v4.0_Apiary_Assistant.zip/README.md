# AOS v4.0 — Apiary Assistant

## Added

- Apiary Assistant page.
- Ask local AOS questions:
  - What should I inspect today?
  - Which colonies worry you?
  - Which queens should I breed from?
  - Which colonies have weak evidence?
  - What feeding or treatment follow-ups are due?
  - Tell me about H16.
- Quick buttons for common questions.
- AI export includes an assistant daily briefing.
- Self-test/runtime smoke includes Apiary Assistant.

## Important

This is a local rule-based assistant. It does not call an external AI service. It uses the data already inside AOS.
