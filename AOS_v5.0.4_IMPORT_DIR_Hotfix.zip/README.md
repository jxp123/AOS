# AOS v5.0.4 — IMPORT_DIR Hotfix

This is a targeted hotfix for the startup crash in v5.0.3.

## Fixed

- `ImportError: cannot import name 'IMPORT_DIR' from aos.core.settings`
- AOS now defines and creates the `imports` folder correctly.
- Data Safety export/import service now also works if older settings are present.

## Use

Replace v5.0.3 with this release.

Your data remains in `data/aos.db`. If v5.0.3 failed before opening, no data should have been changed.
