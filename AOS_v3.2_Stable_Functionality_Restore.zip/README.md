# AOS v3.2 — Stable Functionality Restore

Restores the missing user-facing functionality after the v3.1 engineering reset.

## Restored
- Colonies add / edit / delete
- Queens add / edit / delete
- Equipment add / edit / delete
- Inspection entry and log
- Guided inspection draft / commit / reject
- Natural language parse and stage
- Weather / forage entry and log
- Data integrity and baseline restore
- 7-day inspection scheduler
- Operations Centre
- Apiary Brain
- Excel export
- AI JSON export
- Self-tests
