from nicegui import ui
from aos.engines.operations import todays_work, shift_briefing

def page():
    w=todays_work(); ui.label('Operations').classes('text-h5')
    with ui.row():
        for k in ['overdue','due_today','due_soon','estimated_duration']:
            with ui.card(): ui.label(k.replace('_',' ').title()); ui.label(str(w[k])).classes('text-h5')
    with ui.card().classes('w-full'): ui.label(shift_briefing())
    ui.label('Inspection Queue').classes('text-h6'); ui.table(columns=[{'name':k,'label':k.replace('_',' ').title(),'field':k} for k in ['code','status','days_since','reason']],rows=w['inspection_queue'],row_key='code').classes('w-full')
    ui.label('Suggested Route').classes('text-h6'); ui.label(' → '.join(w['route']) if w['route'] else 'No inspections due.')
    ui.label('Equipment Checklist').classes('text-h6')
    for item in ['Smoker','Fuel','Hive tool','Notebook/phone','Queen clip','Marker pen','Spare frames','Feeder']: ui.checkbox(item)
