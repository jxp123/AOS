from nicegui import ui
from aos.core.settings import APP_VERSION
from aos.ui import brain, operations, scheduler, records, natural_language, guided, tests

def render_app():
    ui.label('🐝 Apiary Operating System').classes('text-h4'); ui.label(f'v{APP_VERSION} Stable Functionality Restore').classes('text-subtitle1')
    with ui.tabs().classes('w-full') as tabs:
        t_brain=ui.tab('Apiary Brain'); t_ops=ui.tab('Operations'); t_sched=ui.tab('Inspection Scheduler'); t_nl=ui.tab('Natural Language'); t_guided=ui.tab('Guided Inspection'); t_records=ui.tab('Records'); t_tests=ui.tab('Tests / Exports')
    with ui.tab_panels(tabs,value=t_brain).classes('w-full'):
        with ui.tab_panel(t_brain): brain.page()
        with ui.tab_panel(t_ops): operations.page()
        with ui.tab_panel(t_sched): scheduler.page()
        with ui.tab_panel(t_nl): natural_language.page()
        with ui.tab_panel(t_guided): guided.page()
        with ui.tab_panel(t_records): records.page()
        with ui.tab_panel(t_tests): tests.page()
