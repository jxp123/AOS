# AOS v5.1 — Field Inspection Workflow Stable

Built on the v5.0.4 hotfix, so the `IMPORT_DIR` startup issue remains fixed.

## Added

- Field Inspection Mode.
- Mobile-friendly staged workflow:
  1. Select colony/nuc
  2. Queen and brood evidence
  3. Brood/stores/bee frame counts
  4. Queen cells, temperament and notes
  5. Review and stage draft
- Live evidence-quality score.
- Live recommendation based on entered evidence.
- Draft-first safety: field entries are staged first, then committed from Guided Inspection.
- Navigation updated under Daily Work.
