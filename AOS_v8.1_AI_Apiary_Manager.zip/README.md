# AOS v8.1 — AI Apiary Manager

Adds conversational AOS queries and daily AI-style briefing. Works out of the box using rule-based reasoning over your database.
