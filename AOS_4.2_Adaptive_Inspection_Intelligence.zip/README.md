# AOS 4.2 — Adaptive Inspection Intelligence

This release changes the inspection workflow from a static checklist to an adaptive inspection guide powered by the Colony State Engine.

## Fixed / improved

- If a colony is Current, it should not remain in Do Today unless a separate high-risk condition exists.
- Inspection focus is no longer a vague tick-box list.
- The inspection form now asks questions that directly address the reason the colony was flagged.
- Low stores creates a feeding question.
- Swarm risk creates a swarm-action question.
- Low health creates brood-pattern and disease-sign questions.
- The inspection screen explains why each observation is being requested.
- Mission Control cards now show reasoning from the Colony State Engine.

## Behaviour

AOS now follows this pattern:

1. Colony State Engine identifies concerns.
2. Adaptive Inspection Engine turns those concerns into inspection questions.
3. User completes the targeted form.
4. Finish Inspection records the inspection.
5. Mission Control recalculates the lane and state.
