from datetime import date
from nicegui import ui
from aos.core.settings import APP_VERSION
from aos.services.repository import Repository
from aos.engines.colony_state_engine import ColonyStateEngine
from aos.engines.adaptive_inspection_engine import AdaptiveInspectionEngine

try:
    from aos.engines.digital_twin import apiary_layout, colony_workspace, inspection_focus, confidence_meter, trend_rows
except Exception:
    apiary_layout = colony_workspace = inspection_focus = confidence_meter = trend_rows = None

try:
    from aos.engines.operations_planner import upcoming_jobs
except Exception:
    upcoming_jobs = None

try:
    from aos.engines.intelligence_platform import intelligence_summary
except Exception:
    intelligence_summary = None

from aos.engines.inspection_workspace_v32 import (
    inspection_priorities,
    timeline_items,
    latest_summary,
    stage_inspection,
    save_inspection_plain_english,
)


STATUS = {
    "urgent": {"label": "Urgent", "symbol": "●", "bg": "#fff1f2", "border": "#9f1239", "text": "#881337"},
    "review": {"label": "Review", "symbol": "▲", "bg": "#fff7ed", "border": "#c2410c", "text": "#7c2d12"},
    "ok": {"label": "OK", "symbol": "■", "bg": "#eff6ff", "border": "#1d4ed8", "text": "#1e3a8a"},
    "info": {"label": "Info", "symbol": "◆", "bg": "#f8fafc", "border": "#64748b", "text": "#334155"},
}


def _safe(value, fallback="—"):
    return value if value not in [None, ""] else fallback


def _repo_cards():
    repo = Repository()
    rows = []
    for c in repo.list_apiary_entities(True):
        rows.append({
            "code": c.get("code", ""),
            "name": c.get("name", ""),
            "type": c.get("type", ""),
            "equipment": c.get("equipment", ""),
            "health": 75,
            "status_badge": "■ OK",
            "queen": "",
            "latest_inspection": "",
            "next_action": "Monitor",
            "reason": c.get("objective", ""),
        })
    return rows


def _cards():
    try:
        if apiary_layout:
            layout = apiary_layout()
            cards = layout.get("hives", []) + layout.get("nucs", []) + layout.get("other", [])
            if cards:
                return cards
    except Exception:
        pass
    return _repo_cards()


def _jobs():
    try:
        if upcoming_jobs:
            return upcoming_jobs()
    except Exception:
        pass
    return []


def _risk_count():
    try:
        if intelligence_summary:
            return intelligence_summary().get("high_risk", 0)
    except Exception:
        pass
    return len([c for c in _cards() if _status_key(c) == "urgent"])


def _status_key(card):
    badge = str(card.get("status_badge", ""))
    health = int(card.get("health") or 0)
    if "Overdue" in badge or "No record" in badge or health < 50:
        return "urgent"
    if "Due" in badge or health < 75:
        return "review"
    return "ok"


def _card_style(key):
    s = STATUS[key]
    return f"background:{s['bg']}; border:2px solid {s['border']}; color:{s['text']}; border-radius:14px;"


def _colony_data(code):
    try:
        if colony_workspace:
            data = colony_workspace(code)
            if data:
                return data
    except Exception:
        pass
    repo = Repository()
    colony = next((c for c in repo.list_apiary_entities(True) if c.get("code") == code), {})
    return {
        "colony": colony,
        "card": next((c for c in _cards() if c.get("code") == code), {}),
        "timeline": [],
        "inspections": [],
        "confidence": {"score": 0, "evidence": [], "missing": ["No data loaded"]},
    }


def _focus(code):
    return inspection_priorities(code)


def _confidence(code):
    try:
        if confidence_meter:
            return confidence_meter(code)
    except Exception:
        pass
    return {"score": 0, "evidence": [], "missing": ["No confidence data"]}


def _trends(code):
    try:
        if trend_rows:
            return trend_rows(code)
    except Exception:
        pass
    return []


def render_aos3():
    ui.add_head_html("""
    <style>
      html, body, #__nuxt { height:100%; margin:0; background:#eef2f7; overflow:hidden; }
      .nicegui-content { height:100vh !important; width:100vw !important; padding:0 !important; overflow:hidden !important; }
      .aos3-root {
        height:100vh; width:100vw;
        display:grid; grid-template-rows:56px minmax(0, 1fr);
        gap:10px; padding:10px; box-sizing:border-box; overflow:hidden;
      }
      .aos3-top {
        display:flex; align-items:center; gap:14px; justify-content:space-between;
        background:#ffffff; border:1px solid #cbd5e1; border-radius:16px;
        padding:8px 12px; box-sizing:border-box; min-height:0;
      }
      .aos3-grid {
        min-height:0; min-width:0;
        display:grid; grid-template-columns:240px minmax(0, 1fr) 360px;
        gap:12px; overflow:hidden;
      }
      .aos3-nav, .aos3-main, .aos3-inspector {
        min-height:0; box-sizing:border-box; border-radius:18px; padding:14px; overflow:auto;
      }
      .aos3-nav { background:#111827; color:white; }
      .aos3-main { background:#ffffff; }
      .aos3-inspector { background:#f8fafc; border:1px solid #cbd5e1; }
      .aos3-nav button { width:100%; justify-content:flex-start; margin:4px 0; }
      .aos3-title-row { display:flex; align-items:center; justify-content:space-between; gap:12px; }
      .aos3-feedback { background:#dbeafe; border-left:5px solid #1d4ed8; padding:8px; border-radius:8px; margin:8px 0; }
      .aos3-kpi { min-width:130px; border:1px solid #cbd5e1; border-radius:14px; background:white; }
      .aos3-lanes { display:grid; grid-template-columns:repeat(4, minmax(205px, 1fr)); gap:10px; align-items:start; }
      .aos3-lane { background:#f8fafc; border:1px solid #cbd5e1; border-radius:14px; padding:10px; min-height:250px; }
      .aos3-card { padding:10px; cursor:pointer; margin-bottom:8px; }
      .aos3-card:hover { outline:3px solid #2563eb; }
      .aos3-actionbar { position:sticky; top:0; z-index:5; background:#f8fafc; border:1px solid #cbd5e1; padding:10px; border-radius:14px; margin:8px 0 12px 0; }
      .aos3-actionbar button { min-width:105px; }
      .aos3-empty { background:#f8fafc; border:1px dashed #94a3b8; padding:10px; border-radius:12px; color:#334155; }
      .aos3-section { color:#bfdbfe; font-size:12px; text-transform:uppercase; letter-spacing:.06em; margin-top:14px; }
      .aos3-search { width:340px; }
      .timeline-card { border-left:5px solid #1d4ed8; background:#f8fafc; border-radius:12px; padding:12px; margin:8px 0; }
      .timeline-date { font-weight:700; font-size:16px; }
      .timeline-type { color:#334155; font-size:13px; text-transform:uppercase; letter-spacing:.04em; }
      .inspection-grid { display:grid; grid-template-columns:repeat(3, minmax(170px, 1fr)); gap:10px; }
      .counter-card { border:1px solid #cbd5e1; border-radius:14px; padding:10px; background:#ffffff; }
      .finish-bar { position:sticky; bottom:0; z-index:6; background:#ffffff; border-top:2px solid #cbd5e1; padding:12px; margin-top:12px; }
      .snapshot-card { background:#ffffff; border:1px solid #cbd5e1; border-radius:12px; padding:10px; }
    </style>
    """)

    state = {"selected": None, "last": "AOS 3.5 loaded. Colony summary and live Mission Control updates are active.", "completed_today": set(), "last_saved": {}}
    main = None
    inspector = None

    def selected_code():
        return state.get("selected")


    def is_completed_today(code):
        return code in state.get("completed_today", set())

    def apply_live_status(card):
        card = dict(card or {})
        code = card.get("code")
        if is_completed_today(code):
            card = dict(card)
            card["health"] = max(int(card.get("health") or 0), 80)
            card["status_badge"] = "■ Current"
            card["next_action"] = "Next inspection due later"
            card["latest_inspection"] = str(date.today())
        return card

    def readable_colony_summary(colony, card, code):
        latest = latest_summary(code)
        queen_bits = []
        for key in ["queen", "Queen ID", "queen_id"]:
            if card.get(key):
                queen_bits.append(card.get(key))
        if colony.get("queen_id"):
            queen_bits.append(colony.get("queen_id"))
        return [
            ("Status", _safe(card.get("status_badge"), "Unknown")),
            ("Health", f"{card.get('health', 0)}%"),
            ("Latest inspection", _safe(card.get("latest_inspection"), latest.get("date", "Never"))),
            ("Queen", _safe(card.get("queen") or colony.get("queen_id") or colony.get("queen"), "Not linked")),
            ("Type", _safe(colony.get("type"))),
            ("Equipment", _safe(colony.get("equipment"))),
            ("Objective", _safe(colony.get("objective"))),
        ]

    def notify(message, positive=True):
        state["last"] = message
        ui.notify(message, type="positive" if positive else "warning")
        render_inspector()

    def header(title, purpose=""):
        main.clear()
        with main:
            with ui.row().classes("aos3-title-row w-full"):
                ui.label(title).classes("text-h4")
                ui.label(f"v{APP_VERSION}").classes("text-caption")
            if purpose:
                with ui.expansion("About this workspace", icon="info").classes("w-full"):
                    ui.markdown(purpose)
            with ui.card().classes("aos3-feedback w-full"):
                ui.label(state["last"])

    def render_inspector():
        inspector.clear()
        with inspector:
            ui.label("Inspector").classes("text-h5")
            ui.label(state["last"]).classes("text-caption")
            ui.separator()
            code = selected_code()
            if not code:
                with ui.card().classes("aos3-empty w-full"):
                    ui.label("No colony selected.")
                    ui.label("Click Select on a colony card. This panel updates immediately.")
                return

            data = _colony_data(code)
            colony = data.get("colony") or {}
            card = ColonyStateEngine().state_for(code).to_card()
            conf = data.get("confidence") or _confidence(code)
            latest = latest_summary(code)

            ui.label(f"{code} — {_safe(colony.get('name'))}").classes("text-h6")
            with ui.card().classes("w-full"):
                ui.label(f"Health: {card.get('health', 0)}%")
                ui.label(f"Status: {_safe(card.get('status_badge'), 'Unknown')}")
                ui.label(f"Confidence: {conf.get('score', 0)}%")
                ui.label(f"Queen: {_safe(card.get('queen'), 'Not linked')}")
                ui.label(f"Latest: {_safe(card.get('latest_inspection'), 'Never')}")
            ui.label("Latest activity").classes("text-h6")
            with ui.card().classes("w-full"):
                ui.label(latest.get("date", ""))
                ui.label(latest.get("type", ""))
                ui.label(latest.get("title", ""))
            ui.label("AI focus").classes("text-h6")
            with ui.card().classes("w-full"):
                for item in _focus(code):
                    ui.label(f"☐ {item}")
            ui.label("Quick actions").classes("text-h6")
            with ui.row():
                ui.button("Open", on_click=lambda: open_colony(code))
                ui.button("Inspect", on_click=lambda: open_inspection_workspace(code))
            with ui.row():
                ui.button("History", on_click=lambda: open_history(code))
                ui.button("Trends", on_click=lambda: open_trends(code))

    def select_colony(code):
        state["selected"] = code
        notify(f"Selected {code}. Inspector updated.")

    def actionbar(code):
        with ui.card().classes("aos3-actionbar w-full"):
            with ui.row().classes("w-full"):
                ui.label(f"Actions for {code}").classes("text-h6")
                ui.button("Start Inspection", on_click=lambda: open_inspection_workspace(code))
                ui.button("History", on_click=lambda: open_history(code))
                ui.button("Trends", on_click=lambda: open_trends(code))
                ui.button("Mission Control", on_click=open_home)

    def card_widget(card):
        key = _status_key(card)
        s = STATUS[key]
        with ui.card().classes("aos3-card").style(_card_style(key)):
            ui.label(f"{s['symbol']} {card.get('code')}").classes("text-h6")
            ui.label(f"{s['label']} — {_safe(card.get('status_badge'))}")
            ui.label(f"Health: {card.get('health',0)}%")
            ui.label(f"Queen: {_safe(card.get('queen'))}")
            ui.label(f"Next: {_safe(card.get('next_action'), 'Monitor')}")
            if card.get("explain"):
                ui.label(card.get("explain")).style("font-size:12px; color:#334155;")
            with ui.row():
                ui.button("Select", on_click=lambda c=card.get("code"): select_colony(c))
                ui.button("Open", on_click=lambda c=card.get("code"): open_colony(c))
                ui.button("Inspect", on_click=lambda c=card.get("code"): open_inspection_workspace(c))

    def open_home():
        header("Mission Control", """
**Purpose**  
See today's operational position without page-level scrolling.

**What changed in v3.2**  
Inspect now opens a real inspection workspace, not just advice.
""")
        cards = _cards()
        jobs = _jobs()
        try:
            lanes = ColonyStateEngine().lanes()
        except Exception:
            lanes = {
                "Do Today": [c for c in cards if _status_key(c) == "urgent"],
                "Watch Closely": [c for c in cards if _status_key(c) == "review"],
                "Healthy": [c for c in cards if _status_key(c) == "ok"],
                "Upcoming": [],
            }
        with main:
            with ui.row().classes("w-full"):
                for title, value in [("Colonies", len(cards)), ("High-risk", _risk_count()), ("Jobs", len(jobs)), ("Selected", selected_code() or "None")]:
                    with ui.card().classes("aos3-kpi"):
                        ui.label(title).classes("text-caption")
                        ui.label(str(value)).classes("text-h5")
            ui.label("Operational Board").classes("text-h5")
            with ui.element("div").classes("aos3-lanes"):
                for lane, lane_cards in lanes.items():
                    with ui.column().classes("aos3-lane"):
                        ui.label(lane).classes("text-h6")
                        if not lane_cards:
                            with ui.card().classes("aos3-empty w-full"):
                                ui.label("No colonies.")
                        for c in lane_cards[:10]:
                            card_widget(c)
            ui.label("Today's Jobs").classes("text-h5")
            if jobs:
                ui.table(
                    columns=[
                        {"name":"due","label":"Due","field":"due"},
                        {"name":"colony","label":"Colony","field":"colony"},
                        {"name":"job","label":"Job","field":"job"},
                        {"name":"priority","label":"Priority","field":"priority"},
                    ],
                    rows=jobs[:8],
                    row_key="job",
                ).classes("w-full")
            else:
                with ui.card().classes("aos3-empty w-full"):
                    ui.label("No jobs generated yet.")
        state["last"] = "Mission Control opened."
        render_inspector()

    def open_colony(code):
        state["selected"] = code
        data = _colony_data(code)
        colony = data.get("colony") or {}
        card = ColonyStateEngine().state_for(code).to_card()
        conf = data.get("confidence") or _confidence(code)
        latest = latest_summary(code)

        header(f"Colony Workspace — {code}", """
**Purpose**  
Work with one colony without losing context.

**What changed in v3.5**  
The main screen now starts with practical summary cards. The full technical record is hidden in an expandable section.
""")
        with main:
            actionbar(code)
            with ui.row().classes("w-full"):
                for title, value in [
                    ("Health", f"{card.get('health',0)}%"),
                    ("Status", _safe(card.get("status_badge"), "Unknown")),
                    ("Confidence", f"{conf.get('score',0)}%"),
                    ("Latest", latest.get("date", "No history")),
                ]:
                    with ui.card().classes("aos3-kpi"):
                        ui.label(title).classes("text-caption")
                        ui.label(str(value)).classes("text-h6")
            with ui.row().classes("w-full"):
                with ui.card().classes("w-full"):
                    ui.label("Today's priorities").classes("text-h6")
                    for item in _focus(code):
                        ui.checkbox(item, value=False)
                with ui.card().classes("w-full"):
                    ui.label("Colony snapshot").classes("text-h6")
                    for label, value in readable_colony_summary(colony, card, code):
                        with ui.row().classes("w-full").style("justify-content:space-between; border-bottom:1px solid #e2e8f0; padding:4px 0;"):
                            ui.label(label).style("font-weight:600; color:#334155;")
                            ui.label(str(value))
                with ui.card().classes("w-full"):
                    ui.label("Latest activity").classes("text-h6")
                    ui.label(latest.get("date", ""))
                    ui.label(latest.get("type", ""))
                    ui.label(latest.get("title", ""))
                    ui.label(latest.get("details", ""))
            with ui.expansion("Full technical colony record", icon="storage").classes("w-full"):
                ui.label("Detailed record").classes("text-h6")
                ui.table(
                    columns=[{"name":"field","label":"Field","field":"field"},{"name":"value","label":"Value","field":"value"}],
                    rows=[{"field":k, "value":str(v)} for k,v in colony.items()],
                    row_key="field",
                ).classes("w-full")
            ui.label("Recent Timeline").classes("text-h5")
            render_timeline_cards(code, limit=4)
        notify(f"Opened {code}. Use Start Inspection to record a new inspection.")


    def render_timeline_cards(code, limit=None):
        rows = timeline_items(code)
        if limit:
            rows = rows[:limit]
        if not rows:
            with ui.card().classes("aos3-empty w-full"):
                ui.label("No history yet. Start an inspection to create the first record.")
            return

        for row in rows:
            with ui.card().classes("timeline-card w-full"):
                ui.label(row.get("date", "")).classes("timeline-date")
                ui.label(row.get("type", "")).classes("timeline-type")
                ui.label(row.get("title", "")).classes("text-h6")
                lines = row.get("detail_lines") or []
                if lines:
                    for line in lines:
                        ui.label(line).style("margin: 6px 0;")
                elif row.get("details"):
                    ui.label(row.get("details", ""))
                with ui.row():
                    ui.button("Start Inspection", on_click=lambda c=code: open_inspection_workspace(c))
                    ui.button("Back to Colony", on_click=lambda c=code: open_colony(c))

    def open_history(code):
        state["selected"] = code
        header(f"Timeline History — {code}", """
**Purpose**  
Chronological colony history, latest first.

**What changed in v3.2**  
This is now shown as timeline cards rather than a table.
""")
        with main:
            actionbar(code)
            render_timeline_cards(code)
        notify(f"Opened timeline history for {code}.")




    def open_inspection_workspace(code):
        state["selected"] = code
        state_obj = ColonyStateEngine().state_for(code).asdict()
        focus_items = _focus_items(code)
        questions = AdaptiveInspectionEngine().questions(code)

        header(f"Record Inspection — {code}", """
**Purpose**  
Record an inspection that directly answers the reasons this colony was flagged.

**What changed in v4.2**  
The inspection form adapts to the Colony State Engine. If stores, brood, queen status or swarm risk are concerns, the form asks for those observations directly.
""")

        widgets = {}

        with main:
            actionbar(code)

            with ui.card().classes("w-full"):
                ui.label("Current state before inspection").classes("text-h6")
                with ui.row():
                    for label, value in [
                        ("Status", state_obj.get("status")),
                        ("Lane", state_obj.get("lane")),
                        ("Health", f"{state_obj.get('health')}%"),
                        ("Next action", state_obj.get("next_action")),
                    ]:
                        with ui.card().classes("aos3-kpi"):
                            ui.label(label).classes("text-caption")
                            ui.label(str(value)).classes("text-h6")
                ui.label("Why AOS is asking you to inspect").classes("text-h6")
                ui.label(state_obj.get("explain", ""))

            ui.label("Inspection focus").classes("text-h5")
            with ui.card().classes("w-full"):
                for item in focus_items:
                    sev = item.get("severity", "standard")
                    prefix = "🔴" if sev == "urgent" else ("🟠" if sev == "review" else "🔵")
                    ui.label(f"{prefix} {item.get('title')}").classes("text-h6")
                    ui.label(item.get("reason", "")).style("margin-bottom:8px; color:#334155;")

            ui.label("Inspection details").classes("text-h5")

            bool_fields = [q for q in questions if q["type"] == "bool"]
            number_fields = [q for q in questions if q["type"] == "number"]
            select_fields = [q for q in questions if q["type"] == "select"]

            with ui.row().classes("w-full"):
                with ui.card().style("min-width:280px; flex:1;"):
                    ui.label("Confirm observations").classes("text-h6")
                    for q in bool_fields:
                        widgets[q["field"]] = ui.checkbox(q["label"], value=q.get("default", False))
                        ui.label(q["reason"]).style("font-size:12px; color:#64748b; margin-bottom:6px;")

                with ui.card().style("min-width:280px; flex:1;"):
                    ui.label("Measure colony strength").classes("text-h6")
                    for q in number_fields:
                        widgets[q["field"]] = ui.number(q["label"], value=q.get("default", 0), min=0, step=0.5).classes("w-full")
                        ui.label(q["reason"]).style("font-size:12px; color:#64748b; margin-bottom:6px;")

                with ui.card().style("min-width:280px; flex:1;"):
                    ui.label("Targeted follow-up").classes("text-h6")
                    if select_fields:
                        for q in select_fields:
                            widgets[q["field"]] = ui.select(q["options"], value=q.get("default"), label=q["label"]).classes("w-full")
                            ui.label(q["reason"]).style("font-size:12px; color:#64748b; margin-bottom:6px;")
                    else:
                        ui.label("No targeted follow-up questions needed.")

            photo_note = ui.input("Photo note / reference").classes("w-full")
            notes = ui.textarea(
                "Notes",
                placeholder="Example: calm colony, stores low, added super, queen seen on frame 4.",
            ).classes("w-full")

            result_box = ui.column().classes("w-full")

            def collect_payload():
                payload = {}
                for q in questions:
                    field = q["field"]
                    widget = widgets.get(field)
                    if widget is not None:
                        payload[field] = widget.value

                extra_notes = notes.value or ""
                if photo_note.value:
                    extra_notes = (extra_notes + "\n" if extra_notes else "") + f"Photo note: {photo_note.value}"

                targeted_answers = []
                for q in questions:
                    field = q["field"]
                    if field not in ["queen_seen", "eggs_seen", "larvae_seen", "brood_frames", "stores_frames", "bee_coverage_frames", "queen_cells", "temperament"]:
                        targeted_answers.append(f"{q['label']}: {payload.get(field)}")
                if targeted_answers:
                    extra_notes = (extra_notes + "\n" if extra_notes else "") + "Targeted follow-up: " + "; ".join(targeted_answers)

                payload["inspection_date"] = str(date.today())
                payload["notes"] = extra_notes
                payload.setdefault("queen_seen", False)
                payload.setdefault("eggs_seen", False)
                payload.setdefault("larvae_seen", False)
                payload.setdefault("queen_cells", 0)
                payload.setdefault("brood_frames", 0)
                payload.setdefault("stores_frames", 0)
                payload.setdefault("bee_coverage_frames", 0)
                payload.setdefault("temperament", "Unknown")
                return payload

            def show_result(result):
                result_box.clear()
                with result_box:
                    with ui.card().classes("w-full"):
                        if result.get("saved"):
                            ui.label("✓ Inspection recorded").classes("text-h5 text-positive")
                        else:
                            ui.label("Inspection not recorded").classes("text-h5 text-negative")
                        ui.label(result.get("message", ""))
                        if result.get("warnings"):
                            ui.label("AOS noticed these points").classes("text-h6")
                            for w in result["warnings"]:
                                ui.label(f"⚠ {w}")
                        ui.label(result.get("next_step", ""))
                        with ui.row():
                            ui.button("View Mission Control", on_click=open_home)
                            ui.button("View Colony Workspace", on_click=lambda: open_colony(code))
                            ui.button("View Timeline", on_click=lambda: open_history(code))

            def finish_inspection():
                result = save_inspection_plain_english(code, collect_payload())
                show_result(result)
                if result.get("saved"):
                    state["selected"] = code
                    notify(f"Inspection recorded for {code}. Adaptive inspection and Mission Control refreshed.", positive=True)
                    open_home()
                else:
                    notify("Inspection was not recorded. Please review the message.", positive=False)

            with ui.card().classes("finish-bar w-full"):
                with ui.row():
                    ui.button("Finish Inspection", on_click=finish_inspection, color="positive")
                    ui.button("Cancel / Back to Colony", on_click=lambda: open_colony(code))

            result_box

        notify(f"Adaptive inspection form opened for {code}.", positive=True)

    def open_trends(code):
        state["selected"] = code
        header(f"Trends — {code}", "Trend data only. Actions remain available at the top.")
        with main:
            actionbar(code)
            ui.table(columns=[{"name":"date","label":"Date","field":"date"},{"name":"brood","label":"Brood","field":"brood"},{"name":"stores","label":"Stores","field":"stores"},{"name":"bees","label":"Bees","field":"bees"},{"name":"queen_cells","label":"Q Cells","field":"queen_cells"}],
                     rows=_trends(code), row_key="date").classes("w-full")
        notify(f"Opened trends for {code}.")

    def open_planning():
        header("Planning", "Upcoming jobs and inspection planning.")
        with main:
            jobs = _jobs()
            if jobs:
                ui.table(columns=[{"name":"due","label":"Due","field":"due"},{"name":"colony","label":"Colony","field":"colony"},{"name":"job","label":"Job","field":"job"},{"name":"priority","label":"Priority","field":"priority"}],
                         rows=jobs, row_key="job").classes("w-full")
            else:
                with ui.card().classes("aos3-empty w-full"):
                    ui.label("No jobs generated yet.")
        notify("Planning opened.")

    def open_analysis():
        header("Analysis", "Risk and summary view.")
        with main:
            cards = _cards()
            rows = [{"code": c.get("code"), "health": c.get("health"), "status": c.get("status_badge"), "next": c.get("next_action")} for c in cards]
            ui.table(columns=[{"name":"code","label":"Code","field":"code"},{"name":"health","label":"Health","field":"health"},{"name":"status","label":"Status","field":"status"},{"name":"next","label":"Next","field":"next"}],
                     rows=rows, row_key="code").classes("w-full")
        notify("Analysis opened.")

    def search(q):
        query = (q or "").strip().lower()
        if not query:
            notify("Search is empty.", positive=False)
            return
        match = next((c for c in _cards() if query in c.get("code","").lower() or query in c.get("name","").lower()), None)
        if match:
            open_colony(match["code"])
        else:
            header("Search Results", "No match found.")
            with main:
                ui.label(f"No direct colony match for '{q}'.")
                ui.button("Back to Mission Control", on_click=open_home)
            notify(f"Searched for '{q}'.", positive=False)

    with ui.element("div").classes("aos3-root"):
        with ui.element("div").classes("aos3-top"):
            ui.label("🐝 AOS 4.2 Adaptive Inspection Intelligence").classes("text-h5")
            search_box = ui.input("Search colony...").classes("aos3-search")
            ui.button("Search", on_click=lambda: search(search_box.value))
            ui.label(f"v{APP_VERSION}")

        with ui.element("div").classes("aos3-grid"):
            with ui.column().classes("aos3-nav"):
                ui.label("Workspaces").classes("text-h6")
                ui.button("Home", on_click=open_home)
                ui.button("Planning", on_click=open_planning)
                ui.button("Analysis", on_click=open_analysis)
                ui.separator()
                ui.label("Selected Colony").classes("aos3-section")
                ui.button("Open selected", on_click=lambda: open_colony(selected_code()) if selected_code() else notify("No colony selected.", False))
                ui.button("Inspect selected", on_click=lambda: open_inspection_workspace(selected_code()) if selected_code() else notify("No colony selected.", False))
                ui.button("History selected", on_click=lambda: open_history(selected_code()) if selected_code() else notify("No colony selected.", False))
                ui.separator()
                ui.label("Legend").classes("aos3-section")
                for key, s in STATUS.items():
                    ui.label(f"{s['symbol']} {s['label']}").style(f"background:{s['bg']}; color:{s['text']}; padding:4px; border-radius:6px;")

            with ui.column().classes("aos3-main") as main_holder:
                main = ui.column().classes("w-full")

            with ui.column().classes("aos3-inspector") as inspector_holder:
                inspector = ui.column().classes("w-full")

    render_inspector()
    open_home()
