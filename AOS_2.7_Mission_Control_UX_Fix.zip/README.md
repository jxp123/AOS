# AOS 2.7 — Mission Control UX Fix

This release directly addresses the issues reported in AOS 2.x.

## Fixed

- Select now gives visible confirmation and updates the right Inspector.
- Select also triggers a positive notification so the action is obvious.
- Open now opens the colony workspace and confirms it.
- Colony Workspace no longer starts with tables at the top.
- Quick actions are now immediately visible near the top of Colony Workspace.
- Selected-colony navigation buttons now give clear feedback if no colony is selected.
- Search results include a clear back-to-Mission-Control action.
- Empty states now explain what to do next.

## UX intent

The app should now make it obvious that every click has done something.
