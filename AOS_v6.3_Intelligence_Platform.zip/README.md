# AOS v6.3 — Intelligence Platform

Adds colony memory, predictive risk rows, seasonal planner and resource forecast.
