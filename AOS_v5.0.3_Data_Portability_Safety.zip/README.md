# AOS v5.0.3 — Data Portability Safety

This release adds the mechanism you asked for: export your live AOS data before installing a future release, then import it back afterwards.

## New safety mechanism

### Before installing any future AOS release

Run:

`Export_AOS_Data.bat`

This creates:

- `exports/aos_data_export_YYYYMMDD_HHMMSS.json`
- `exports/aos_sqlite_backup_YYYYMMDD_HHMMSS.db`

The JSON export is the main portable file for re-importing into future versions.

### After installing a future AOS release

1. Copy your JSON export into the new release's `imports` folder.
2. Run:

`Import_AOS_Data.bat`

or use:

`Administration → Data Safety`

## New UI

A new **Data Safety** page has been added under Administration.

It allows you to:

- Export JSON
- Export full SQLite database backup
- View latest exports
- Import selected JSON
- Replace the current database data with imported data

## Important

The import process creates a safety backup before replacing data.
