import json
import shutil
from datetime import datetime
from pathlib import Path

from aos.core.settings import DATA_DIR, DB_PATH, EXPORT_DIR, IMPORT_DIR, BACKUP_DIR
from aos.db.session import session_scope
from aos.db.models import (
    Colony, Queen, Equipment, Inspection, GuidedInspectionDraft,
    WeatherObservation, AuditLog
)

try:
    from aos.db.models import FeedingRecord, TreatmentRecord, QueenEvaluation, BreedingPlan
except Exception:
    FeedingRecord = None
    TreatmentRecord = None
    QueenEvaluation = None
    BreedingPlan = None

class DataPortabilityService:
    TABLE_MODELS = [
        ("colonies", Colony),
        ("queens", Queen),
        ("equipment", Equipment),
        ("inspections", Inspection),
        ("guided_inspection_drafts", GuidedInspectionDraft),
        ("weather_observations", WeatherObservation),
        ("audit_log", AuditLog),
    ]

    OPTIONAL_MODELS = [
        ("feeding_records", FeedingRecord),
        ("treatment_records", TreatmentRecord),
        ("queen_evaluations", QueenEvaluation),
        ("breeding_plans", BreedingPlan),
    ]

    def _all_models(self):
        rows = list(self.TABLE_MODELS)
        for name, model in self.OPTIONAL_MODELS:
            if model is not None:
                rows.append((name, model))
        return rows

    def _model_to_dict(self, obj):
        return {col.name: getattr(obj, col.name) for col in obj.__table__.columns}

    def _strip_id(self, row):
        row = dict(row)
        row.pop("id", None)
        return row

    def export_json(self):
        EXPORT_DIR.mkdir(exist_ok=True)
        stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        path = EXPORT_DIR / f"aos_data_export_{stamp}.json"

        data = {
            "aos_export_version": "5.0.3",
            "created_at": datetime.now().isoformat(timespec="seconds"),
            "tables": {},
        }

        with session_scope() as s:
            for table_name, model in self._all_models():
                data["tables"][table_name] = [self._model_to_dict(row) for row in s.query(model).all()]

        path.write_text(json.dumps(data, indent=2), encoding="utf-8")
        return path

    def export_sqlite_backup(self):
        EXPORT_DIR.mkdir(exist_ok=True)
        stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        target = EXPORT_DIR / f"aos_sqlite_backup_{stamp}.db"
        if not DB_PATH.exists():
            raise FileNotFoundError("No AOS database found")
        shutil.copy2(DB_PATH, target)
        return target

    def latest_exports(self):
        EXPORT_DIR.mkdir(exist_ok=True)
        files = sorted(EXPORT_DIR.glob("aos_*"), key=lambda p: p.stat().st_mtime, reverse=True)
        return [
            {
                "filename": p.name,
                "path": str(p),
                "size_bytes": p.stat().st_size,
                "modified": datetime.fromtimestamp(p.stat().st_mtime).isoformat(timespec="seconds"),
            }
            for p in files[:50]
        ]

    def import_json(self, source_path, mode="replace"):
        source = Path(source_path)
        if not source.exists():
            raise FileNotFoundError(f"Import file not found: {source}")

        data = json.loads(source.read_text(encoding="utf-8"))
        tables = data.get("tables", {})
        if not isinstance(tables, dict):
            raise ValueError("Invalid AOS JSON export: missing tables")

        # Always create a safety backup before importing.
        BACKUP_DIR.mkdir(exist_ok=True)
        if DB_PATH.exists():
            backup = BACKUP_DIR / f"aos_pre_import_backup_{datetime.now().strftime('%Y%m%d_%H%M%S')}.db"
            shutil.copy2(DB_PATH, backup)

        imported = {}

        with session_scope() as s:
            if mode == "replace":
                # Delete children first, then core tables.
                for table_name, model in reversed(self._all_models()):
                    s.query(model).delete()

            for table_name, model in self._all_models():
                rows = tables.get(table_name, [])
                count = 0
                for row in rows:
                    clean_row = self._strip_id(row)
                    try:
                        s.add(model(**clean_row))
                        count += 1
                    except TypeError:
                        # If an older/newer export has fields this version does not know,
                        # keep only model columns.
                        allowed = {col.name for col in model.__table__.columns}
                        clean_row = {k: v for k, v in clean_row.items() if k in allowed}
                        s.add(model(**clean_row))
                        count += 1
                imported[table_name] = count

            s.commit()

        return imported

    def available_import_files(self):
        IMPORT_DIR.mkdir(exist_ok=True)
        EXPORT_DIR.mkdir(exist_ok=True)
        candidates = list(IMPORT_DIR.glob("*.json")) + list(EXPORT_DIR.glob("aos_data_export_*.json"))
        candidates = sorted(candidates, key=lambda p: p.stat().st_mtime, reverse=True)
        return [
            {
                "filename": p.name,
                "path": str(p),
                "size_bytes": p.stat().st_size,
                "modified": datetime.fromtimestamp(p.stat().st_mtime).isoformat(timespec="seconds"),
            }
            for p in candidates[:50]
        ]
