# AOS 4.0 — Colony State Engine

This release introduces the Colony State Engine as the background source of truth.

## What changed

- Mission Control no longer relies on stale Digital Twin status values.
- Colony cards are generated from the Colony State Engine.
- Status is calculated from latest inspection data.
- After finishing an inspection, Mission Control is recalculated from the saved data.
- A colony inspected today should move out of Overdue and show as Current, unless inspection findings create a new risk.
- Inspector and Colony Workspace now read the same calculated state.

## Engine rules in this release

- Last inspection within 7 days = Current / Healthy.
- Last inspection 8–10 days ago = Due soon / Watch Closely.
- Last inspection over 10 days ago = Overdue / Do Today.
- Queen cells = Swarm risk / Do Today.
- Low stores = Do Today.
- Missing queen and eggs = Watch Closely.

This is the foundation for future weather, forage, queen-line and AI recommendation logic.
