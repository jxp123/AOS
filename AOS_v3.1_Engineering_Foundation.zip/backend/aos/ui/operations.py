from nicegui import ui
from aos.engines.operations import todays_work, shift_briefing
def page():
    w = todays_work()
    ui.label("Operations").classes("text-h5")
    with ui.card().classes("w-full"):
        ui.label(shift_briefing())
    ui.table(columns=[{"name":"code","label":"Code","field":"code"},{"name":"status","label":"Status","field":"status"},{"name":"days_since","label":"Days Since","field":"days_since"},{"name":"reason","label":"Reason","field":"reason"}], rows=w["inspection_queue"], row_key="code").classes("w-full")
