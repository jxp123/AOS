from nicegui import ui
from aos.engines.natural_language import parse_note
def page():
    ui.label("Natural Language").classes("text-h5")
    note = ui.textarea("Inspection note").classes("w-full")
    holder = ui.column().classes("w-full")
    def parse():
        holder.clear()
        data = parse_note(note.value or "")
        with holder:
            ui.table(columns=[{"name":"field","label":"Field","field":"field"},{"name":"value","label":"Value","field":"value"}], rows=[{"field":k,"value":str(v)} for k,v in data.items()], row_key="field").classes("w-full")
    ui.button("Parse", on_click=parse)
