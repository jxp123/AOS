from nicegui import ui
from aos.utils.self_test import run_self_tests, summary
def page():
    ui.label("Tests").classes("text-h5")
    rows = run_self_tests()
    s = summary(rows)
    ui.label(f"PASS={s['pass']} FAIL={s['fail']} TOTAL={s['total']}")
    ui.table(columns=[{"name":"status","label":"Status","field":"status"},{"name":"test","label":"Test","field":"test"},{"name":"message","label":"Message","field":"message"}], rows=rows, row_key="test").classes("w-full")
