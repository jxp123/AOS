from nicegui import ui
from aos.services.repository import Repository
def page():
    repo = Repository()
    ui.label("Records").classes("text-h5")
    ui.table(columns=[{"name":"code","label":"Code","field":"code"},{"name":"name","label":"Name","field":"name"},{"name":"type","label":"Type","field":"type"},{"name":"equipment","label":"Equipment","field":"equipment"},{"name":"objective","label":"Objective","field":"objective"}], rows=repo.list_colonies(), row_key="code").classes("w-full")
