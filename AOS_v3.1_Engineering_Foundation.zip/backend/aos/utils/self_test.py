from sqlalchemy import text
from aos.db.session import init_db, session_scope
from aos.core.bootstrap import boot
from aos.services.repository import Repository
from aos.engines.scheduler import inspection_schedule
from aos.engines.brain import apiary_brain_state
from aos.engines.natural_language import parse_note
def result(test, status, message=""):
    return {"test":test,"status":status,"message":message}
def run_self_tests():
    rows = []
    try:
        boot()
        with session_scope() as s: s.execute(text("SELECT 1"))
        rows.append(result("database","PASS"))
    except Exception as e: rows.append(result("database","FAIL",str(e)))
    try: rows.append(result("repository","PASS",str(len(Repository().list_colonies()))))
    except Exception as e: rows.append(result("repository","FAIL",str(e)))
    try: rows.append(result("scheduler","PASS",str(len(inspection_schedule()))))
    except Exception as e: rows.append(result("scheduler","FAIL",str(e)))
    try: rows.append(result("apiary brain","PASS",str(apiary_brain_state()["apiary_priority_score"])))
    except Exception as e: rows.append(result("apiary brain","FAIL",str(e)))
    try: rows.append(result("natural language","PASS",str(parse_note("Hive 16 queen seen 6 brood 2 stores"))))
    except Exception as e: rows.append(result("natural language","FAIL",str(e)))
    return rows
def summary(rows):
    return {"pass":len([r for r in rows if r["status"]=="PASS"]),"fail":len([r for r in rows if r["status"]=="FAIL"]),"total":len(rows)}
def main():
    rows = run_self_tests()
    for r in rows: print(f"[{r['status']}] {r['test']}: {r['message']}")
    s = summary(rows)
    print(f"PASS={s['pass']} FAIL={s['fail']} TOTAL={s['total']}")
    if s["fail"]: raise SystemExit(1)
if __name__ == "__main__":
    main()
