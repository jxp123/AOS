from aos.db.session import session_scope
from aos.db.models import Colony, Queen, Equipment, Inspection

class Repository:
    def list_colonies(self, active_only=False):
        with session_scope() as s:
            q = s.query(Colony)
            if active_only:
                q = q.filter(Colony.status == "Active")
            return [{"id":c.id,"code":c.code,"name":c.name,"type":c.colony_type,"equipment":c.equipment,"objective":c.objective,"status":c.status,"notes":c.notes or ""} for c in q.order_by(Colony.code).all()]
    def list_apiary_entities(self, active_only=True):
        return self.list_colonies(active_only)
    def list_queens(self):
        with session_scope() as s:
            return [{"code":q.code,"name":q.name,"line":q.line,"current_colony":q.current_colony_code,"status":q.status} for q in s.query(Queen).all()]
    def list_equipment(self):
        with session_scope() as s:
            return [{"code":e.code,"name":e.name,"type":e.type,"location":e.current_location,"compatible":e.compatible_with,"status":e.status} for e in s.query(Equipment).all()]
    def list_inspections(self):
        with session_scope() as s:
            return [{"id":i.id,"date":i.date,"colony":i.colony.code if i.colony else "", "queen_seen":"Yes" if i.queen_seen else "No","eggs_seen":"Yes" if i.eggs_seen else "No","brood_frames":i.brood_frames,"stores_frames":i.stores_frames,"bee_coverage_frames":i.bee_coverage_frames,"notes":i.notes or ""} for i in s.query(Inspection).order_by(Inspection.date.desc(), Inspection.id.desc()).all()]
    def latest_inspection_by_colony(self):
        latest = {}
        for i in self.list_inspections():
            if i["colony"] not in latest:
                latest[i["colony"]] = i
        return latest
    def create_inspection(self, data):
        with session_scope() as s:
            s.add(Inspection(**data))
            s.commit()
