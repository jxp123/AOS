# AOS v3.1 — Engineering Foundation

This release resets AOS into a proper software project structure.

## Run
1. Double-click `Install_AOS.bat`
2. Double-click `Run_AOS.bat`

## Validate
Double-click `Run_Tests.bat`

## Main change
AOS now has:
- structured backend package
- service layer
- engine layer
- UI shell
- release validation script
- GitHub Actions scaffold
- smoke tests

Commit this full release to GitHub as the new baseline.
