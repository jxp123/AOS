# AOS v5.0.1 — Sidebar Navigation Fix

## Fixed

- Navigation appearing at the bottom.
- Main workspace appearing outside the intended shell.
- Assistant panel appearing in the wrong location.
- Navigation buttons not visibly changing the main workspace.

## Cause

The v5.0 shell created the main content and assistant output placeholders before the layout row was created. NiceGUI attached them to the page immediately, so they appeared below the shell rather than inside it.

## Change

The sidebar, main workspace and assistant panel are now created inside one shell container:

- left: navigation
- centre: main workspace
- right: assistant

The buttons now update the central workspace.
