from datetime import date
from nicegui import ui
from aos.core.settings import APP_VERSION
from aos.services.repository import Repository
from aos.engines.colony_state_engine import ColonyStateEngine
from aos.engines.adaptive_inspection_engine import AdaptiveInspectionEngine
from aos.engines.apiary_jobs_engine import ApiaryJobsEngine
from aos.services.colony_profile_service import ColonyProfileService
from aos.services.operations_service import OperationsService
from aos.services.colony_lifecycle_service import ColonyLifecycleService
from aos.services.colony_configuration_service import ColonyConfigurationService
from aos.engines.operations_centre_engine import OperationsCentreEngine
from aos.engines.evidence_based_intelligence_engine import EvidenceBasedIntelligenceEngine
from aos.engines.apiary_intelligence_centre import ApiaryIntelligenceCentre
from aos.engines.colony_intelligence_engine import ColonyIntelligenceEngine

try:
    from aos.engines.digital_twin import apiary_layout, colony_workspace, inspection_focus, confidence_meter, trend_rows
except Exception:
    apiary_layout = colony_workspace = inspection_focus = confidence_meter = trend_rows = None

try:
    from aos.engines.operations_planner import upcoming_jobs
except Exception:
    upcoming_jobs = None

try:
    from aos.engines.intelligence_platform import intelligence_summary
except Exception:
    intelligence_summary = None

from aos.engines.inspection_workspace_v32 import (
    inspection_priorities,
    timeline_items,
    latest_summary,
    stage_inspection,
    save_inspection_plain_english,
)


STATUS = {
    "urgent": {"label": "Urgent", "symbol": "●", "bg": "#fff1f2", "border": "#9f1239", "text": "#881337"},
    "review": {"label": "Review", "symbol": "▲", "bg": "#fff7ed", "border": "#c2410c", "text": "#7c2d12"},
    "ok": {"label": "OK", "symbol": "■", "bg": "#eff6ff", "border": "#1d4ed8", "text": "#1e3a8a"},
    "info": {"label": "Info", "symbol": "◆", "bg": "#f8fafc", "border": "#64748b", "text": "#334155"},
}


def _safe(value, fallback="—"):
    return value if value not in [None, ""] else fallback


def _repo_cards():
    repo = Repository()
    rows = []
    for c in repo.list_apiary_entities(True):
        rows.append({
            "code": c.get("code", ""),
            "name": c.get("name", ""),
            "type": c.get("type", ""),
            "equipment": c.get("equipment", ""),
            "health": 75,
            "status_badge": "■ OK",
            "queen": "",
            "latest_inspection": "",
            "next_action": "Monitor",
            "reason": c.get("objective", ""),
        })
    return rows


def _cards():
    try:
        if apiary_layout:
            layout = apiary_layout()
            cards = layout.get("hives", []) + layout.get("nucs", []) + layout.get("other", [])
            if cards:
                return cards
    except Exception:
        pass
    return _repo_cards()


def _jobs():
    try:
        if upcoming_jobs:
            return upcoming_jobs()
    except Exception:
        pass
    return []


def _risk_count():
    try:
        if intelligence_summary:
            return intelligence_summary().get("high_risk", 0)
    except Exception:
        pass
    return len([c for c in _cards() if _status_key(c) == "urgent"])


def _status_key(card):
    badge = str(card.get("status_badge", ""))
    health = int(card.get("health") or 0)
    if "Overdue" in badge or "No record" in badge or health < 50:
        return "urgent"
    if "Due" in badge or health < 75:
        return "review"
    return "ok"


def _card_style(key):
    s = STATUS[key]
    return f"background:{s['bg']}; border:2px solid {s['border']}; color:{s['text']}; border-radius:14px;"


def _colony_data(code):
    try:
        if colony_workspace:
            data = colony_workspace(code)
            if data:
                try:
                    data["colony"] = ColonyProfileService().merge(code, data.get("colony") or {})
                except Exception:
                    pass
                return data
    except Exception:
        pass
    repo = Repository()
    colony = next((c for c in repo.list_apiary_entities(True) if c.get("code") == code), {})
    try:
        colony = ColonyProfileService().merge(code, colony)
    except Exception:
        pass
    return {
        "colony": colony,
        "card": next((c for c in _cards() if c.get("code") == code), {}),
        "timeline": [],
        "inspections": [],
        "confidence": {"score": 0, "evidence": [], "missing": ["No data loaded"]},
    }


def _focus(code):
    return inspection_priorities(code)


def _focus_items(code):
    try:
        return AdaptiveInspectionEngine().focus(code)
    except Exception:
        return [{"title": item, "reason": "", "severity": "standard"} for item in _focus(code)]


def _confidence(code):
    try:
        if confidence_meter:
            return confidence_meter(code)
    except Exception:
        pass
    return {"score": 0, "evidence": [], "missing": ["No confidence data"]}


def _trends(code):
    try:
        if trend_rows:
            return trend_rows(code)
    except Exception:
        pass
    return []


def render_aos3():
    ui.add_head_html("""
    <style>
      html, body, #__nuxt { height:100%; margin:0; background:#eef2f7; overflow:hidden; }
      .nicegui-content { height:100vh !important; width:100vw !important; padding:0 !important; overflow:hidden !important; }
      .aos3-root {
        height:100vh; width:100vw;
        display:grid; grid-template-rows:56px minmax(0, 1fr);
        gap:10px; padding:10px; box-sizing:border-box; overflow:hidden;
      }
      .aos3-top {
        display:flex; align-items:center; gap:14px; justify-content:space-between;
        background:#ffffff; border:1px solid #cbd5e1; border-radius:16px;
        padding:8px 12px; box-sizing:border-box; min-height:0;
      }
      .aos3-grid {
        min-height:0; min-width:0;
        display:grid; grid-template-columns:240px minmax(0, 1fr) 360px;
        gap:12px; overflow:hidden;
      }
      .aos3-nav, .aos3-main, .aos3-inspector {
        min-height:0; box-sizing:border-box; border-radius:18px; padding:14px; overflow:auto;
      }
      .aos3-nav { background:#111827; color:white; }
      .aos3-main { background:#ffffff; }
      .aos3-inspector { background:#f8fafc; border:1px solid #cbd5e1; }
      .aos3-nav button { width:100%; justify-content:flex-start; margin:4px 0; }
      .aos3-title-row { display:flex; align-items:center; justify-content:space-between; gap:12px; }
      .aos3-feedback { background:#dbeafe; border-left:5px solid #1d4ed8; padding:8px; border-radius:8px; margin:8px 0; }
      .aos3-kpi { min-width:130px; border:1px solid #cbd5e1; border-radius:14px; background:white; }
      .aos3-lanes { display:grid; grid-template-columns:repeat(4, minmax(205px, 1fr)); gap:10px; align-items:start; }
      .task-card { background:#ffffff; border:1px solid #cbd5e1; border-left:5px solid #1d4ed8; border-radius:14px; padding:10px; margin-bottom:8px; }
      .ops-card-urgent { border-left:6px solid #b91c1c !important; }
      .ops-card-watch { border-left:6px solid #d97706 !important; }
      .ops-card-current { border-left:6px solid #15803d !important; }
      .ops-card-neutral { border-left:6px solid #2563eb !important; }
      .aos3-lane { background:#f8fafc; border:1px solid #cbd5e1; border-radius:14px; padding:10px; min-height:250px; }
      .aos3-card { padding:10px; cursor:pointer; margin-bottom:8px; }
      .aos3-card:hover { outline:3px solid #2563eb; }
      .aos3-actionbar { position:sticky; top:0; z-index:5; background:#f8fafc; border:1px solid #cbd5e1; padding:10px; border-radius:14px; margin:8px 0 12px 0; }
      .aos3-actionbar button { min-width:105px; }
      .aos3-empty { background:#f8fafc; border:1px dashed #94a3b8; padding:10px; border-radius:12px; color:#334155; }
      .aos3-section { color:#bfdbfe; font-size:12px; text-transform:uppercase; letter-spacing:.06em; margin-top:14px; }
      .aos3-search { width:340px; }
      .timeline-card { border-left:5px solid #1d4ed8; background:#f8fafc; border-radius:12px; padding:12px; margin:8px 0; }
      .timeline-date { font-weight:700; font-size:16px; }
      .timeline-type { color:#334155; font-size:13px; text-transform:uppercase; letter-spacing:.04em; }
      .inspection-grid { display:grid; grid-template-columns:repeat(3, minmax(170px, 1fr)); gap:10px; }
      .counter-card { border:1px solid #cbd5e1; border-radius:14px; padding:10px; background:#ffffff; }
      .finish-bar { position:sticky; bottom:0; z-index:6; background:#ffffff; border-top:2px solid #cbd5e1; padding:12px; margin-top:12px; }
      .snapshot-card { background:#ffffff; border:1px solid #cbd5e1; border-radius:12px; padding:10px; }
    </style>
    """)

    state = {"selected": None, "last": "AOS 11.0 Colony Configuration & Inspection Integration", "completed_today": set(), "last_saved": {}}
    main = None
    inspector = None

    def selected_code():
        return state.get("selected")


    def is_completed_today(code):
        return code in state.get("completed_today", set())

    def apply_live_status(card):
        card = dict(card or {})
        code = card.get("code")
        if is_completed_today(code):
            card = dict(card)
            card["health"] = max(int(card.get("health") or 0), 80)
            card["status_badge"] = "■ Current"
            card["next_action"] = "Next inspection due later"
            card["latest_inspection"] = str(date.today())
        return card

    def readable_colony_summary(colony, card, code):
        latest = latest_summary(code)
        queen_bits = []
        for key in ["queen", "Queen ID", "queen_id"]:
            if card.get(key):
                queen_bits.append(card.get(key))
        if colony.get("queen_id"):
            queen_bits.append(colony.get("queen_id"))
        return [
            ("Status", _safe(card.get("status_badge"), "Unknown")),
            ("Health", f"{card.get('health', 0)}%"),
            ("Latest inspection", _safe(card.get("latest_inspection"), latest.get("date", "Never"))),
            ("Queen", _safe(card.get("queen") or colony.get("queen_id") or colony.get("queen"), "Not linked")),
            ("Type", _safe(colony.get("type"))),
            ("Equipment", _safe(colony.get("equipment"))),
            ("Objective", _safe(colony.get("objective"))),
        ]

    def notify(message, positive=True):
        state["last"] = message
        ui.notify(message, type="positive" if positive else "warning")
        render_inspector()

    def header(title, purpose=""):
        main.clear()
        with main:
            with ui.row().classes("aos3-title-row w-full"):
                ui.label(title).classes("text-h4")
                ui.label(f"v{APP_VERSION}").classes("text-caption")
            if purpose:
                with ui.expansion("About this workspace", icon="info").classes("w-full"):
                    ui.markdown(purpose)
            with ui.card().classes("aos3-feedback w-full"):
                ui.label(state["last"])

    def render_inspector():
        inspector.clear()
        with inspector:
            ui.label("Inspector").classes("text-h5")
            ui.label(state["last"]).classes("text-caption")
            ui.separator()
            code = selected_code()
            if not code:
                with ui.card().classes("aos3-empty w-full"):
                    ui.label("No colony selected.")
                    ui.label("Click Select on a colony card. This panel updates immediately.")
                return

            data = _colony_data(code)
            colony = data.get("colony") or {}
            card = ColonyStateEngine().state_for(code).to_card()
            conf = data.get("confidence") or _confidence(code)
            latest = latest_summary(code)

            ui.label(f"{code} — {_safe(colony.get('name'))}").classes("text-h6")
            with ui.card().classes("w-full"):
                ui.label(f"Health: {card.get('health', 0)}%")
                ui.label(f"Status: {_safe(card.get('status_badge'), 'Unknown')}")
                ui.label(f"Confidence: {conf.get('score', 0)}%")
                ui.label(f"Queen: {_safe(card.get('queen'), 'Not linked')}")
                ui.label(f"Latest: {_safe(card.get('latest_inspection'), 'Never')}")
            ui.label("Latest activity").classes("text-h6")
            with ui.card().classes("w-full"):
                ui.label(latest.get("date", ""))
                ui.label(latest.get("type", ""))
                ui.label(latest.get("title", ""))
            ui.label("AI focus").classes("text-h6")
            with ui.card().classes("w-full"):
                for item in _focus(code):
                    ui.label(f"☐ {item}")
            ui.label("Quick actions").classes("text-h6")
            with ui.row():
                ui.button("Open", on_click=lambda: stable_call(lambda: open_colony(code)))
                ui.button("Inspect", on_click=lambda: stable_call(lambda: open_inspection_workspace(code)))
            with ui.row():
                ui.button("History", on_click=lambda: stable_call(lambda: open_history(code)))
                ui.button("Trends", on_click=lambda: stable_call(lambda: open_trends(code)))

    def select_colony(code):
        state["selected"] = code
        notify(f"Selected {code}. Inspector updated.")

    def open_inspection_or_scroll(code):
        # If the inspection form is already on the page, scroll to it rather than trying to
        # rebuild the same workspace. This avoids NiceGUI's deleted-parent lifecycle error.
        try:
            ui.run_javascript("""
                const el = document.getElementById('inspection-form-anchor');
                if (el) { el.scrollIntoView({behavior:'smooth', block:'start'}); }
            """)
        except Exception:
            pass
        try:
            # If no form is visible, open the workflow normally.
            if state.get("current_workspace") != f"inspection:{code}":
                open_inspection_workspace(code)
        except Exception as e:
            notify(f"Could not open inspection for {code}: {e}", positive=False)


    def stable_call(fn):
        """Run UI navigation callbacks outside the deleted slot context.

        NiceGUI can raise "parent element this slot belongs to has been deleted"
        when a button callback clears/rebuilds the page from inside the button's
        own parent container. A short timer schedules the navigation after the
        click event has completed.
        """
        try:
            ui.timer(0.05, fn, once=True)
        except Exception as e:
            try:
                notify(f"Navigation failed: {e}", positive=False)
            except Exception:
                print(f"Navigation failed: {e}")

    def actionbar(code):
        with ui.card().classes("aos3-actionbar w-full"):
            with ui.row().classes("w-full"):
                ui.label(f"Actions for {code}").classes("text-h6")
                ui.button("Record Inspection", on_click=lambda: stable_call(lambda: open_inspection_or_scroll(code)))
                ui.button("History", on_click=lambda: stable_call(lambda: open_history(code)))
                ui.button("Trends", on_click=lambda: stable_call(lambda: open_trends(code)))
                ui.button("Operations", on_click=lambda: stable_call(lambda: open_operations(code)))
                ui.button("Configure Hive", on_click=lambda: stable_call(lambda: open_configure_colony(code)))
                ui.button("Edit Colony", on_click=lambda: stable_call(lambda: open_edit_colony(code)))
                ui.button("Mission Control", on_click=lambda: stable_call(open_home))


    def start_inspection_from_task(code):
        if not code:
            notify("No colony selected for inspection.", positive=False)
            return
        try:
            open_inspection_workspace(code)
        except Exception as e:
            notify(f"Could not open inspection for {code}: {e}", positive=False)


    def task_card(job):
        code = job.get("code")
        with ui.card().classes("task-card w-full"):
            ui.label(job.get("title", "Task")).classes("text-h6")
            ui.label(f"Priority: {job.get('priority', '')}")
            ui.label(("Next inspection: " if job.get("priority") == "Completed" else "Due: ") + str(job.get("due", "")))
            if job.get("reason"):
                ui.label(job.get("reason")).style("font-size:12px; color:#334155; margin:6px 0;")
            with ui.row():
                ui.button("Open", on_click=lambda c=code: stable_call(lambda: open_colony(c)))
                ui.button("Inspect", on_click=lambda c=code: stable_call(lambda: start_inspection_from_task(c)))

    def card_widget(card):
        key = _status_key(card)
        s = STATUS[key]
        with ui.card().classes("aos3-card").style(_card_style(key)):
            ui.label(f"{s['symbol']} {card.get('code')}").classes("text-h6")
            ui.label(f"{s['label']} — {_safe(card.get('status_badge'))}")
            ui.label(f"Health: {card.get('health',0)}%")
            ui.label(f"Queen: {_safe(card.get('queen'))}")
            ui.label(f"Next: {_safe(card.get('next_action'), 'Monitor')}")
            if card.get("explain"):
                ui.label(card.get("explain")).style("font-size:12px; color:#334155;")
            with ui.row():
                ui.button("Select", on_click=lambda c=card.get("code"): select_colony(c))
                ui.button("Open", on_click=lambda c=card.get("code"): stable_call(lambda: open_colony(c)))
                ui.button("Inspect", on_click=lambda c=card.get("code"): start_inspection_from_task(c))


    def completed_today_card(code):
        saved = state.get("last_saved", {}).get(code, {})
        next_date = saved.get("next_inspection_date")
        reason = saved.get("next_inspection_reason")
        if not next_date:
            from datetime import timedelta
            next_date = str(date.today() + timedelta(days=7))
            reason = "Routine 7-day inspection interval."
        summary_bits = []
        if saved.get("queen_seen"):
            summary_bits.append("Queen seen.")
        if saved.get("eggs_seen"):
            summary_bits.append("Eggs present.")
        if saved.get("larvae_seen"):
            summary_bits.append("Open brood present.")
        if saved.get("stores_frames") not in [None, ""]:
            summary_bits.append(f"Stores: {saved.get('stores_frames')} frame(s).")
        if saved.get("queen_cells") not in [None, "", 0]:
            summary_bits.append(f"Queen cells: {saved.get('queen_cells')}.")
        summary = " ".join(summary_bits) or "Inspection completed and recorded."
        return {
            "code": code,
            "title": f"{code} inspected ✓",
            "priority": "Completed",
            "due": next_date,
            "reason": f"Next inspection: {next_date}. {reason or ''} Summary: {summary}",
            "action": "Open",
        }

    def open_home():
        state["current_workspace"] = "home"
        header("Mission Control", """
**Purpose**  
Mission Control is now organised around work, not abstract colony status.

**Columns**  
- **Today**: work that should be done today.  
- **This Week**: work becoming due shortly.  
- **Watch List**: colonies that need attention but not necessarily immediate work.  
- **Completed Today**: work you have finished in this session.
""")
        cards = _cards()
        summary = ApiaryJobsEngine().summary()
        lanes = ApiaryJobsEngine().mission_lanes()

        # Add session-completed jobs into the completed lane and remove from active lanes.
        completed_codes = set(state.get("completed_today", set()))
        if completed_codes:
            for lane_name in ["Today", "This Week", "Watch List"]:
                lanes[lane_name] = [j for j in lanes.get(lane_name, []) if j.get("code") not in completed_codes]
            lanes["Completed Today"] = [
                completed_today_card(c)
                for c in sorted(completed_codes)
            ]

        with main:
            with ui.row().classes("w-full"):
                for title, value in [
                    ("Colonies", len(cards)),
                    ("Today", len(lanes.get("Today", []))),
                    ("This Week", len(lanes.get("This Week", []))),
                    ("Watch", len(lanes.get("Watch List", []))),
                    ("Done", len(lanes.get("Completed Today", []))),
                    ("Selected", selected_code() or "None"),
                ]:
                    with ui.card().classes("aos3-kpi"):
                        ui.label(title).classes("text-caption")
                        ui.label(str(value)).classes("text-h5")

            ui.label("Today's Work Board").classes("text-h5")
            with ui.element("div").classes("aos3-lanes"):
                for lane in ["Today", "This Week", "Watch List", "Completed Today"]:
                    with ui.column().classes("aos3-lane"):
                        ui.label(lane).classes("text-h6")
                        jobs = lanes.get(lane, [])
                        if not jobs:
                            with ui.card().classes("aos3-empty w-full"):
                                ui.label("No items.")
                        for job in jobs[:12]:
                            task_card(job)

            with ui.expansion("AI Alerts & Emerging Trends", icon="auto_awesome").classes("w-full"):
                try:
                    from aos.engines.apiary_intelligence_engine import ApiaryIntelligenceEngine
                    apiary = ApiaryIntelligenceEngine().summary()
                    ui.label(apiary.get("summary", "")).classes("text-h6")
                    for insight in apiary.get("insights", []):
                        ui.label(f"• {insight}")
                except Exception as e:
                    ui.label(f"Apiary intelligence unavailable: {e}")

            with ui.expansion("Colony state board", icon="dashboard").classes("w-full"):
                ui.label("This is the background state view from the Colony State Engine. Mission Control above is driven by jobs.")
                state_lanes = ColonyStateEngine().lanes()
                with ui.element("div").classes("aos3-lanes"):
                    for lane, lane_cards in state_lanes.items():
                        with ui.column().classes("aos3-lane"):
                            ui.label(lane).classes("text-h6")
                            if not lane_cards:
                                with ui.card().classes("aos3-empty w-full"):
                                    ui.label("No colonies.")
                            for c in lane_cards[:8]:
                                card_widget(c)

        state["last"] = "Mission Control opened."
        render_inspector()








    def open_colony(code):
        state["selected"] = code
        state["current_workspace"] = f"colony:{code}"
        data = _colony_data(code)
        colony = data.get("colony") or {}
        card = ColonyStateEngine().state_for(code).to_card()
        intel = ColonyIntelligenceEngine().analyse(code).asdict()

        header(f"Colony Intelligence — {code}", """
**Purpose**  
This workspace is an intelligence report. It answers: what is happening, why it is happening, and what AOS recommends next.
""")
        with main:
            actionbar(code)
            with ui.row().classes("w-full"):
                for title, value in [
                    ("Health", f"{intel.get('overall_health', 0)}%"),
                    ("Status", card.get("status_badge", "Unknown")),
                    ("Confidence", f"{intel.get('confidence', 0)}%"),
                    ("Next inspection", intel.get("next_inspection_date", "—")),
                ]:
                    with ui.card().classes("aos3-kpi"):
                        ui.label(title).classes("text-caption")
                        ui.label(str(value)).classes("text-h6")

            with ui.card().classes("w-full"):
                ui.label("Physical Configuration").classes("text-h5")
                render_hive_stack(code)

            with ui.card().classes("w-full"):
                ui.label("AI Assessment").classes("text-h5")
                ui.label(intel.get("executive_summary", ""))
                ui.label(intel.get("current_assessment", "")).style("margin-top:10px;")

            with ui.card().classes("w-full"):
                ui.label("Evidence-Based Recommendation").classes("text-h5")
                rec = EvidenceBasedIntelligenceEngine().primary_recommendation(code)
                if rec:
                    ui.label(rec.get("recommendation", ""))
                    ui.label(f"Confidence: {rec.get('confidence', 0)}%").style("font-weight:600; margin-top:8px;")
                    ui.label(rec.get("reasoning", "")).style("margin-top:8px;")
                    with ui.expansion("Evidence for / against", icon="fact_check").classes("w-full"):
                        ui.label("Evidence for").classes("text-h6")
                        for item in rec.get("evidence_for", []):
                            ui.label(f"• {item}")
                        ui.label("Evidence against").classes("text-h6")
                        for item in rec.get("evidence_against", []):
                            ui.label(f"• {item}")
                else:
                    ui.label("No evidence-based recommendation available yet.")

            with ui.row().classes("w-full"):
                with ui.card().classes("w-full"):
                    ui.label("Recommendations").classes("text-h6")
                    for item in intel.get("recommendations", []):
                        ui.label(f"• {item}")
                with ui.card().classes("w-full"):
                    ui.label("Concerns").classes("text-h6")
                    for item in intel.get("concerns", []):
                        ui.label(f"• {item}")
                with ui.card().classes("w-full"):
                    ui.label("Strengths").classes("text-h6")
                    for item in intel.get("strengths", []):
                        ui.label(f"• {item}")

            with ui.row().classes("w-full"):
                with ui.card().classes("w-full"):
                    ui.label("Trends").classes("text-h6")
                    for item in intel.get("trends", []):
                        ui.label(f"• {item}")
                with ui.card().classes("w-full"):
                    ui.label("Predictions").classes("text-h6")
                    for item in intel.get("predictions", []):
                        ui.label(f"• {item}")

            with ui.expansion("Why?", icon="help").classes("w-full"):
                for key, values in (intel.get("why") or {}).items():
                    ui.label(key.title()).classes("text-h6")
                    for item in values:
                        if item:
                            ui.label(f"• {item}")

            with ui.expansion("Colony personality", icon="psychology").classes("w-full"):
                for item in intel.get("personality", []):
                    ui.label(f"• {item}")

            with ui.expansion("Apiary comparison", icon="compare_arrows").classes("w-full"):
                for item in intel.get("apiary_comparison", []):
                    ui.label(f"• {item}")

            with ui.expansion("History narrative", icon="timeline").classes("w-full"):
                for item in intel.get("history_summary", []):
                    ui.label(item).style("margin:6px 0;")

            with ui.expansion("Full technical colony record", icon="storage").classes("w-full"):
                ui.table(
                    columns=[{"name":"field","label":"Field","field":"field"},{"name":"value","label":"Value","field":"value"}],
                    rows=[{"field":k, "value":str(v)} for k,v in colony.items()],
                    row_key="field",
                ).classes("w-full")

        notify(f"Opened intelligence workspace for {code}.")
    def render_timeline_cards(code, limit=None):
        rows = timeline_items(code)
        if limit:
            rows = rows[:limit]
        if not rows:
            with ui.card().classes("aos3-empty w-full"):
                ui.label("No history yet. Start an inspection to create the first record.")
            return

        for row in rows:
            with ui.card().classes("timeline-card w-full"):
                ui.label(row.get("date", "")).classes("timeline-date")
                ui.label(row.get("type", "")).classes("timeline-type")
                ui.label(row.get("title", "")).classes("text-h6")
                lines = row.get("detail_lines") or []
                if lines:
                    for line in lines:
                        ui.label(line).style("margin: 6px 0;")
                elif row.get("details"):
                    ui.label(row.get("details", ""))
                with ui.row():
                    ui.button("Record Inspection", on_click=lambda c=code: stable_call(lambda: open_inspection_workspace(c)))
                    ui.button("Back to Colony", on_click=lambda c=code: stable_call(lambda: open_colony(c)))

    def open_history(code):
        state["selected"] = code
        header(f"Timeline History — {code}", """
**Purpose**  
Chronological colony history, latest first.

**What changed in v3.2**  
This is now shown as timeline cards rather than a table.
""")
        with main:
            actionbar(code)
            render_timeline_cards(code)
        notify(f"Opened timeline history for {code}.")




    def open_inspection_workspace(code):
        state["selected"] = code
        state["current_workspace"] = f"inspection:{code}"
        state_obj = ColonyStateEngine().state_for(code).asdict()
        focus_items = _focus_items(code)
        questions = AdaptiveInspectionEngine().questions(code)

        header(f"Record Inspection — {code}", """
**Purpose**  
Record an inspection that directly answers the reasons this colony was flagged.

**What changed in v4.2**  
The inspection form adapts to the Colony State Engine. If stores, brood, queen status or swarm risk are concerns, the form asks for those observations directly.
""")

        widgets = {}

        with main:
            actionbar(code)

            with ui.card().classes("w-full"):
                ui.label("Current state before inspection").classes("text-h6")
                with ui.row():
                    for label, value in [
                        ("Status", state_obj.get("status")),
                        ("Lane", state_obj.get("lane")),
                        ("Health", f"{state_obj.get('health')}%"),
                        ("Next action", state_obj.get("next_action")),
                    ]:
                        with ui.card().classes("aos3-kpi"):
                            ui.label(label).classes("text-caption")
                            ui.label(str(value)).classes("text-h6")
                ui.label("Why AOS is asking you to inspect").classes("text-h6")
                ui.label(state_obj.get("explain", ""))

            ui.label("Inspection focus").classes("text-h5")
            with ui.card().classes("w-full"):
                for item in focus_items:
                    sev = item.get("severity", "standard")
                    prefix = "🔴" if sev == "urgent" else ("🟠" if sev == "review" else "🔵")
                    ui.label(f"{prefix} {item.get('title')}").classes("text-h6")
                    ui.label(item.get("reason", "")).style("margin-bottom:8px; color:#334155;")

            ui.html('<div id="inspection-form-anchor"></div>')
            ui.label("Inspection details").classes("text-h5")

            bool_fields = [q for q in questions if q["type"] == "bool"]
            number_fields = [q for q in questions if q["type"] == "number"]
            select_fields = [q for q in questions if q["type"] == "select"]

            with ui.row().classes("w-full"):
                with ui.card().style("min-width:280px; flex:1;"):
                    ui.label("Confirm observations").classes("text-h6")
                    for q in bool_fields:
                        widgets[q["field"]] = ui.checkbox(q["label"], value=q.get("default", False))
                        ui.label(q["reason"]).style("font-size:12px; color:#64748b; margin-bottom:6px;")

                with ui.card().style("min-width:280px; flex:1;"):
                    ui.label("Measure colony strength").classes("text-h6")
                    for q in number_fields:
                        widgets[q["field"]] = ui.number(q["label"], value=q.get("default", 0), min=0, step=0.5).classes("w-full")
                        ui.label(q["reason"]).style("font-size:12px; color:#64748b; margin-bottom:6px;")

                with ui.card().style("min-width:280px; flex:1;"):
                    ui.label("Targeted follow-up").classes("text-h6")
                    if select_fields:
                        for q in select_fields:
                            widgets[q["field"]] = ui.select(q["options"], value=q.get("default"), label=q["label"]).classes("w-full")
                            ui.label(q["reason"]).style("font-size:12px; color:#64748b; margin-bottom:6px;")
                    else:
                        ui.label("No targeted follow-up questions needed.")

            with ui.expansion("Supers / Honey", icon="hive").classes("w-full"):
                ui.label("Optional, but needed for whole-apiary honey production estimates.").style("font-size:12px; color:#64748b;")
                super_count = ui.number("Supers on hive", value=0, min=0, step=1).classes("w-full")
                super_type = ui.select(["shallow", "medium", "deep", "Langstroth shallow", "Langstroth medium", "Langstroth deep"], value="shallow", label="Super type").classes("w-full")
                frames_total = ui.number("Frames in super", value=10, min=1, step=1).classes("w-full")
                frames_drawn = ui.number("Frames drawn/occupied", value=0, min=0, step=0.5).classes("w-full")
                percent_capped = ui.number("% capped", value=0, min=0, max=100, step=5).classes("w-full")
                percent_uncapped = ui.number("% filled but uncapped", value=0, min=0, max=100, step=5).classes("w-full")
                harvest_intended = ui.checkbox("Intended for harvest", value=True)

            super_observation_widgets = []
            feeder_observation_widgets = []
            with ui.expansion("Supers / Honey from Current Configuration", icon="hive").classes("w-full"):
                ui.label("AOS loads the supers currently recorded in this colony configuration. Record each super separately.").style("font-size:12px; color:#64748b;")
                cfg = ColonyConfigurationService().configuration(code)
                supers_cfg = cfg.get("supers", [])
                if supers_cfg:
                    for comp in supers_cfg:
                        with ui.card().classes("w-full").style("border-left:5px solid #ca8a04;"):
                            ui.label((comp.get("asset_label") or "Super") + f" — {comp.get('box_standard','')} {comp.get('box_depth','')} — {comp.get('frame_count') or 0:g} frames").classes("text-h6")
                            fd = ui.number("Frames drawn", value=0, min=0, step=0.5).classes("w-full")
                            fh = ui.number("Frames with nectar/honey", value=0, min=0, step=0.5).classes("w-full")
                            pc = ui.number("% capped", value=0, min=0, max=100, step=5).classes("w-full")
                            pu = ui.number("% uncapped", value=0, min=0, max=100, step=5).classes("w-full")
                            act = ui.select(["Leave", "Remove for harvest", "Move to another colony", "Add another super"], value="Leave", label="Action").classes("w-full")
                            note = ui.input("Super notes").classes("w-full")
                            super_observation_widgets.append((comp, fd, fh, pc, pu, act, note))
                else:
                    ui.label("No supers are recorded in the current configuration.")
                    ui.button("Add / configure supers", on_click=lambda: stable_call(lambda: open_configure_colony(code)))

            with ui.expansion("Feeder / Feed from Current Configuration", icon="local_drink").classes("w-full"):
                feeders_cfg = ColonyConfigurationService().configuration(code).get("feeders", [])
                if feeders_cfg:
                    for comp in feeders_cfg:
                        with ui.card().classes("w-full").style("border-left:5px solid #16a34a;"):
                            ui.label((comp.get("asset_label") or "Feeder") + f" — {comp.get('feed_type') or 'feed type not recorded'}").classes("text-h6")
                            ft = ui.select(["1:1 syrup", "2:1 syrup", "Fondant", "Dry sugar", "Pollen patty", "Protein substitute", "Empty"], value=comp.get("feed_type") or "1:1 syrup", label="Feed type").classes("w-full")
                            rem = ui.number("Estimated remaining", value=float(comp.get("feed_remaining") or 0), min=0, step=0.5).classes("w-full")
                            taking = ui.select(["Yes", "No", "Slowly", "Unknown"], value="Unknown", label="Bees taking feed?").classes("w-full")
                            fnote = ui.input("Feeder notes").classes("w-full")
                            feeder_observation_widgets.append((comp, ft, rem, taking, fnote))
                else:
                    ui.label("No feeder is recorded in the current configuration.")
                    ui.button("Add / configure feeder", on_click=lambda: stable_call(lambda: open_configure_colony(code)))

            with ui.expansion("Operations completed during this inspection", icon="build").classes("w-full"):
                ui.label("Use this after you changed the hive while inspecting: added/removed supers, feeder, queen excluder or other equipment.").style("font-size:12px; color:#64748b;")
                ui.button("Record operation / configure hive stack", on_click=lambda: stable_call(lambda: open_configure_colony(code)))

            photo_note = ui.input("Photo note / reference").classes("w-full")
            notes = ui.textarea(
                "Notes",
                placeholder="Example: calm colony, stores low, added super, queen seen on frame 4.",
            ).classes("w-full")

            result_box = ui.column().classes("w-full")

            def collect_payload():
                payload = {}
                for q in questions:
                    field = q["field"]
                    widget = widgets.get(field)
                    if widget is not None:
                        payload[field] = widget.value

                extra_notes = notes.value or ""
                if photo_note.value:
                    extra_notes = (extra_notes + "\n" if extra_notes else "") + f"Photo note: {photo_note.value}"

                targeted_answers = []
                for q in questions:
                    field = q["field"]
                    if field not in ["queen_seen", "eggs_seen", "larvae_seen", "brood_frames", "stores_frames", "bee_coverage_frames", "queen_cells", "temperament"]:
                        targeted_answers.append(f"{q['label']}: {payload.get(field)}")
                if targeted_answers:
                    extra_notes = (extra_notes + "\n" if extra_notes else "") + "Targeted follow-up: " + "; ".join(targeted_answers)

                payload["inspection_date"] = str(date.today())
                payload["notes"] = extra_notes
                try:
                    payload["super_count"] = super_count.value
                    payload["super_type"] = super_type.value
                    payload["frames_total"] = frames_total.value
                    payload["frames_drawn"] = frames_drawn.value
                    payload["percent_capped"] = percent_capped.value
                    payload["percent_uncapped"] = percent_uncapped.value
                    payload["harvest_intended"] = harvest_intended.value
                except Exception:
                    pass
                try:
                    for comp, fd, fh, pc, pu, act, note in super_observation_widgets:
                        obs = {
                            "frames_drawn": fd.value,
                            "frames_with_honey": fh.value,
                            "percent_capped": pc.value,
                            "percent_uncapped": pu.value,
                            "action": act.value,
                            "condition_notes": note.value,
                        }
                        ColonyConfigurationService().observe_component(code, comp.get("component_id"), obs)
                        ColonyConfigurationService().save_super_observation_to_honey_engine(code, comp, obs)
                    for comp, ft, rem, taking, fnote in feeder_observation_widgets:
                        ColonyConfigurationService().upsert_component(
                            code, "feeder", int(comp.get("position_index") or 1),
                            component_id=comp.get("component_id"),
                            asset_label=comp.get("asset_label") or "Feeder",
                            feed_type=ft.value,
                            feed_remaining=rem.value,
                            notes=fnote.value,
                        )
                        ColonyConfigurationService().observe_component(code, comp.get("component_id"), {
                            "bees_taking_feed": taking.value,
                            "condition_notes": fnote.value,
                            "action": "Observe feeder",
                        })
                except Exception:
                    pass
                payload.setdefault("queen_seen", False)
                payload.setdefault("eggs_seen", False)
                payload.setdefault("larvae_seen", False)
                payload.setdefault("queen_cells", 0)
                payload.setdefault("brood_frames", 0)
                payload.setdefault("stores_frames", 0)
                payload.setdefault("bee_coverage_frames", 0)
                payload.setdefault("temperament", "Unknown")
                return payload

            def show_result(result):
                result_box.clear()
                with result_box:
                    with ui.card().classes("w-full"):
                        if result.get("saved"):
                            ui.label("✓ Inspection recorded").classes("text-h5 text-positive")
                        else:
                            ui.label("Inspection not recorded").classes("text-h5 text-negative")
                        ui.label(result.get("message", ""))
                        if result.get("warnings"):
                            ui.label("AOS noticed these points").classes("text-h6")
                            for w in result["warnings"]:
                                ui.label(f"⚠ {w}")
                        ui.label(result.get("next_step", ""))
                        with ui.row():
                            ui.button("View Mission Control", on_click=lambda: stable_call(open_home))
                            ui.button("View Colony Workspace", on_click=lambda: stable_call(lambda: open_colony(code)))
                            ui.button("View Timeline", on_click=lambda: stable_call(lambda: open_history(code)))

            def finish_inspection():
                result = save_inspection_plain_english(code, collect_payload())
                show_result(result)
                if result.get("saved"):
                    state["selected"] = code
                    state.setdefault("completed_today", set()).add(code)
                    saved_payload = collect_payload()
                    saved_payload["next_inspection_date"] = result.get("next_inspection_date")
                    saved_payload["next_inspection_reason"] = result.get("next_inspection_reason")
                    state.setdefault("last_saved", {})[code] = saved_payload
                    notify(f"Inspection recorded for {code}. Task moved to Completed Today.", positive=True)
                    open_home()
                else:
                    notify("Inspection was not recorded. Please review the message.", positive=False)

            with ui.card().classes("finish-bar w-full"):
                with ui.row():
                    ui.button("Finish Inspection", on_click=finish_inspection, color="positive")
                    ui.button("Cancel / Back to Colony", on_click=lambda: stable_call(lambda: open_colony(code)))

            result_box

        notify(f"Adaptive inspection form opened for {code}.", positive=True)




    def open_new_colony():
        state["current_workspace"] = "new_colony"
        header("Register New Colony / Nuc", """
**Purpose**  
Register a new biological colony in the apiary. This may be a bought nuc, bought full colony, swarm, artificial split, moved colony or other origin.

AOS records the origin, equipment, queen and starting condition so the Intelligence Engine can understand the colony's life story from day one.
""")
        with main:
            with ui.card().classes("w-full"):
                ui.label("1. Identity").classes("text-h5")
                entity_type = ui.select(["Hive", "Nuc"], value="Hive", label="What are you adding?").classes("w-full")
                code = ui.input("Colony code (leave blank to auto-generate)").classes("w-full")
                name = ui.input("Name / label").classes("w-full")
                apiary = ui.input("Apiary / location", value="Main apiary").classes("w-full")

            with ui.card().classes("w-full"):
                ui.label("2. Origin").classes("text-h5")
                origin_type = ui.select(
                    ["Bought nuc", "Bought full colony", "Artificial split", "Swarm", "Moved from another apiary", "Colony united", "Other"],
                    value="Bought nuc",
                    label="Where did it come from?",
                ).classes("w-full")
                parent_colony = ui.input("Parent colony (if split/united)").classes("w-full")
                supplier = ui.input("Supplier / source").classes("w-full")

            with ui.card().classes("w-full"):
                ui.label("3. Equipment").classes("text-h5")
                hive_system = ui.select(["Langstroth", "National", "14x12", "Dadant", "Commercial", "WBC", "Other"], value="Langstroth", label="Hive system").classes("w-full")
                box_type = ui.select(["single brood", "double brood", "nuc box", "brood + super", "other"], value="single brood", label="Box type").classes("w-full")
                brood_boxes = ui.number("Number of brood boxes", value=1, min=0, step=1).classes("w-full")
                supers = ui.number("Number of supers", value=0, min=0, step=1).classes("w-full")
                frames_per_box = ui.number("Frames per box", value=10, min=1, step=1).classes("w-full")
                floor_type = ui.select(["Open mesh", "Solid", "Unknown"], value="Unknown", label="Floor type").classes("w-full")
                roof_type = ui.select(["Standard", "Insulated", "Unknown"], value="Unknown", label="Roof type").classes("w-full")
                feeder_fitted = ui.checkbox("Feeder fitted", value=False)
                queen_excluder = ui.checkbox("Queen excluder fitted", value=False)
                insulation = ui.checkbox("Insulation fitted", value=False)

            with ui.card().classes("w-full"):
                ui.label("4. Queen").classes("text-h5")
                queen_present = ui.checkbox("Queen present / supplied", value=True)
                queen_breed = ui.input("Breed / strain").classes("w-full")
                queen_supplier = ui.input("Queen supplier / breeder").classes("w-full")
                queen_year = ui.input("Queen year").classes("w-full")
                queen_colour = ui.input("Mark colour").classes("w-full")
                queen_marked = ui.checkbox("Marked", value=False)
                queen_clipped = ui.checkbox("Clipped", value=False)

            with ui.card().classes("w-full"):
                ui.label("5. Starting condition").classes("text-h5")
                frames_bees = ui.number("Frames of bees", value=0, min=0, step=0.5).classes("w-full")
                frames_brood = ui.number("Frames of brood", value=0, min=0, step=0.5).classes("w-full")
                frames_stores = ui.number("Frames of stores", value=0, min=0, step=0.5).classes("w-full")
                temperament = ui.select(["Calm", "OK", "Defensive", "Aggressive", "Unknown"], value="Unknown", label="Temperament").classes("w-full")
                notes = ui.textarea("Notes").classes("w-full")

            def save_new_colony():
                values = {
                    "code": code.value,
                    "entity_type": entity_type.value,
                    "name": name.value,
                    "apiary": apiary.value,
                    "origin_type": origin_type.value,
                    "parent_colony": parent_colony.value,
                    "supplier": supplier.value,
                    "hive_system": hive_system.value,
                    "box_type": box_type.value,
                    "brood_boxes": brood_boxes.value,
                    "supers": supers.value,
                    "frames_per_box": frames_per_box.value,
                    "floor_type": floor_type.value,
                    "roof_type": roof_type.value,
                    "feeder_fitted": feeder_fitted.value,
                    "queen_excluder": queen_excluder.value,
                    "insulation": insulation.value,
                    "queen_present": queen_present.value,
                    "queen_breed": queen_breed.value,
                    "queen_supplier": queen_supplier.value,
                    "queen_year": queen_year.value,
                    "queen_colour": queen_colour.value,
                    "queen_marked": queen_marked.value,
                    "queen_clipped": queen_clipped.value,
                    "frames_bees": frames_bees.value,
                    "frames_brood": frames_brood.value,
                    "frames_stores": frames_stores.value,
                    "temperament": temperament.value,
                    "notes": notes.value,
                }
                result = ColonyLifecycleService().register_colony(values)
                new_code = result.get("colony_code") or values.get("code")
                notify(f"Registered new colony {new_code}.", positive=True)
                open_colony(new_code)

            with main:
                with ui.card().classes("finish-bar w-full"):
                    ui.button("Register Colony", on_click=save_new_colony, color="positive")
                    ui.button("Cancel", on_click=open_home)

        notify("New colony wizard opened.", positive=True)


    def operation_card(card):
        code = card.get("code")
        lane = str(card.get("lane") or "").lower()
        status = str(card.get("status") or "").lower()
        css = "ops-card-neutral"
        if "do today" in lane or "overdue" in status or "urgent" in status:
            css = "ops-card-urgent"
        elif "watch" in lane or "review" in status:
            css = "ops-card-watch"
        elif "current" in status or "healthy" in lane:
            css = "ops-card-current"
        with ui.card().classes(f"aos3-colony-card {css}"):
            ui.label(str(code)).classes("text-h5")
            ui.label(f"{card.get('entity_type', 'Hive')} • {card.get('equipment', '')}").style("font-size:12px; color:#475569;")
            ui.label(f"Status: {card.get('status', 'Unknown')}").style("margin-top:8px;")
            ui.label(f"Health: {card.get('health', 0)}%")
            ui.label(f"Queen: {card.get('queen', 'Unknown')}")
            ui.label(f"Last operation: {card.get('last_operation', 'None')}")
            ui.label(f"Suggested: {card.get('suggested_operation', 'Routine monitoring')}").style("font-weight:600; margin-top:6px;")
            if card.get("reason"):
                ui.label(card.get("reason")).style("font-size:12px; color:#475569;")
            with ui.row():
                ui.button("Open", on_click=lambda c=code: stable_call(lambda: open_colony(c)))
                ui.button("Operations", on_click=lambda c=code: stable_call(lambda: open_operations(c)))
                ui.button("Inspect", on_click=lambda c=code: stable_call(lambda: open_inspection_workspace(c)))


    def open_operations_centre():
        state["current_workspace"] = "operations_centre"
        header("Operations Centre", """
**Purpose**  
Choose any active hive or nuc and record a management operation. This page lists the whole apiary, with natural H1, H2, H3 ordering by default.
""")
        centre = OperationsCentreEngine()
        raw = centre.cards()

        with main:
            sort_options = [
                "Apiary order",
                "Colony code",
                "Health lowest first",
                "Health highest first",
                "Status",
                "Suggested operation",
                "Last operation",
            ]

            controls = ui.card().classes("w-full")
            with controls:
                ui.label("Sort and filter").classes("text-h6")
                with ui.row().classes("w-full"):
                    sort_by = ui.select(sort_options, value=state.get("operations_sort", "Apiary order"), label="Sort by").classes("w-64")
                    search = ui.input("Search hives, nucs, queen, equipment, operation").classes("w-96")
                    show_hives = ui.checkbox("Hives", value=state.get("operations_show_hives", True))
                    show_nucs = ui.checkbox("Nucs", value=state.get("operations_show_nucs", True))

            content = ui.column().classes("w-full")

            def render():
                state["operations_sort"] = sort_by.value
                state["operations_show_hives"] = show_hives.value
                state["operations_show_nucs"] = show_nucs.value
                data = centre.cards()
                hives = centre.sort_cards(centre.filter_cards(data.get("hives", []), search.value), sort_by.value)
                nucs = centre.sort_cards(centre.filter_cards(data.get("nucs", []), search.value), sort_by.value)

                content.clear()
                with content:
                    with ui.row().classes("w-full"):
                        with ui.card().classes("aos3-kpi"):
                            ui.label("Hives shown").classes("text-caption")
                            ui.label(str(len(hives) if show_hives.value else 0)).classes("text-h6")
                        with ui.card().classes("aos3-kpi"):
                            ui.label("Nucs shown").classes("text-caption")
                            ui.label(str(len(nucs) if show_nucs.value else 0)).classes("text-h6")
                        with ui.card().classes("aos3-kpi"):
                            ui.label("Sort").classes("text-caption")
                            ui.label(sort_by.value).classes("text-h6")

                    if show_hives.value:
                        with ui.card().classes("w-full"):
                            ui.label(f"Hives ({len(hives)})").classes("text-h4")
                            if hives:
                                with ui.grid(columns=3).classes("w-full"):
                                    for card in hives:
                                        operation_card(card)
                            else:
                                ui.label("No hives match the current filter.")

                    if show_nucs.value:
                        with ui.card().classes("w-full"):
                            ui.label(f"Nucs ({len(nucs)})").classes("text-h4")
                            if nucs:
                                with ui.grid(columns=3).classes("w-full"):
                                    for card in nucs:
                                        operation_card(card)
                            else:
                                ui.label("No nucs match the current filter.")

                    with ui.row():
                        ui.button("Register New Hive / Nuc", on_click=lambda: stable_call(open_new_colony), color="positive")
                        ui.button("Mission Control", on_click=lambda: stable_call(open_home))

            sort_by.on("update:model-value", lambda e: render())
            search.on("update:model-value", lambda e: render())
            show_hives.on("update:model-value", lambda e: render())
            show_nucs.on("update:model-value", lambda e: render())
            render()

        notify("Operations Centre opened.", positive=True)


    def render_hive_stack(code):
        cfg = ColonyConfigurationService().configuration(code)
        ui.label("Current Hive Configuration").classes("text-h5")
        ui.label("Digital twin of the colony's physical stack. Update this when equipment is moved, removed or changed.").style("font-size:12px; color:#64748b;")
        for comp in cfg.get("components", []):
            label = comp.get("asset_label") or comp.get("component_type", "").replace("_", " ").title()
            detail = []
            for key in ["box_standard", "box_depth"]:
                if comp.get(key):
                    detail.append(str(comp.get(key)))
            if comp.get("frame_count"):
                detail.append(f"{comp.get('frame_count'):g} frames")
            if comp.get("feed_type"):
                detail.append(f"Feed: {comp.get('feed_type')}")
            if comp.get("feed_remaining"):
                detail.append(f"Remaining: {comp.get('feed_remaining'):g}")
            with ui.card().classes("w-full").style("border-left:5px solid #2563eb; margin-bottom:4px; padding:8px;"):
                ui.label(label).style("font-weight:700;")
                if detail:
                    ui.label(" • ".join(detail)).style("font-size:12px; color:#475569;")
                if comp.get("notes"):
                    ui.label(str(comp.get("notes"))).style("font-size:12px; color:#64748b;")

    def open_configure_colony(code):
        if not code:
            notify("Select a colony first.", positive=False)
            return
        state["selected"] = code
        header(f"Configure Hive Stack — {code}", """
**Purpose**  
Maintain the current physical configuration of this colony: brood boxes, queen excluder, supers, feeder, dummy board, crownboard, floor, roof and insulation.
""")
        with main:
            actionbar(code)
            with ui.card().classes("w-full"):
                render_hive_stack(code)

            with ui.card().classes("w-full"):
                ui.label("Add or update equipment").classes("text-h5")
                component_type = ui.select(["brood_box", "super", "queen_excluder", "feeder", "dummy_board", "crownboard", "floor", "roof", "insulation"], value="super", label="Component").classes("w-full")
                position_index = ui.number("Position / number", value=1, min=1, step=1).classes("w-full")
                asset_label = ui.input("Asset label / description").classes("w-full")
                box_standard = ui.select(["Langstroth", "National", "14x12", "Dadant", "Commercial", "WBC", "Other", ""], value="Langstroth", label="Box standard").classes("w-full")
                box_depth = ui.select(["shallow", "medium", "deep", "n/a", ""], value="medium", label="Box depth").classes("w-full")
                frame_count = ui.number("Number of frames", value=10, min=0, step=1).classes("w-full")
                feed_type = ui.select(["", "1:1 syrup", "2:1 syrup", "Fondant", "Dry sugar", "Pollen patty", "Protein substitute"], value="", label="Feed type if feeder").classes("w-full")
                feed_amount = ui.number("Feed amount added", value=0, min=0, step=0.5).classes("w-full")
                feed_remaining = ui.number("Feed remaining", value=0, min=0, step=0.5).classes("w-full")
                notes = ui.textarea("Notes").classes("w-full")

                def save_component():
                    cid = ColonyConfigurationService().upsert_component(
                        code, component_type.value, int(position_index.value or 1),
                        asset_label=asset_label.value, box_standard=box_standard.value, box_depth=box_depth.value,
                        frame_count=frame_count.value, feed_type=feed_type.value, feed_amount=feed_amount.value,
                        feed_remaining=feed_remaining.value, notes=notes.value,
                    )
                    try:
                        OperationsService().record_operation(code, "configuration_update", f"{component_type.value.replace('_',' ').title()} updated", f"{cid}: {notes.value}")
                    except Exception:
                        pass
                    notify("Hive configuration updated.", positive=True)
                    stable_call(lambda: open_configure_colony(code))

                ui.button("Save / Update Component", on_click=save_component, color="positive")

            with ui.card().classes("w-full"):
                ui.label("Remove equipment").classes("text-h5")
                cfg = ColonyConfigurationService().configuration(code)
                options = {f"{c.get('component_id')} — {c.get('asset_label') or c.get('component_type')}": c.get("component_id") for c in cfg.get("components", [])}
                remove_select = ui.select(list(options.keys()), label="Component to remove").classes("w-full")
                destination = ui.select(["storage", "harvest", "moved to another colony", "retired"], value="storage", label="Destination / reason").classes("w-full")
                remove_notes = ui.textarea("Removal notes").classes("w-full")

                def remove_selected():
                    if not remove_select.value:
                        notify("Choose a component to remove.", positive=False)
                        return
                    cid = options.get(remove_select.value)
                    ColonyConfigurationService().remove_component(cid, destination.value, remove_notes.value)
                    try:
                        OperationsService().record_operation(code, "configuration_remove", "Equipment removed", f"{cid} removed to {destination.value}. {remove_notes.value}")
                    except Exception:
                        pass
                    notify("Equipment removed.", positive=True)
                    stable_call(lambda: open_configure_colony(code))

                ui.button("Remove Component", on_click=remove_selected, color="negative")

    def open_operations(code):
        if not code:
            notify("Select a colony first.", positive=False)
            return
        state["selected"] = code
        state["current_workspace"] = f"operations:{code}"
        header(f"Operations — {code}", """
**Purpose**  
Record beekeeper actions that are not inspections: queen changes, feeders, supers and equipment operations.
""")
        with main:
            actionbar(code)
            with ui.tabs().classes("w-full") as tabs:
                queen_tab = ui.tab("Queen")
                feeder_tab = ui.tab("Feeder")
                super_tab = ui.tab("Super")
            with ui.tab_panels(tabs, value=queen_tab).classes("w-full"):
                with ui.tab_panel(queen_tab):
                    ui.label("Install bought queen").classes("text-h5")
                    supplier = ui.input("Supplier / breeder").classes("w-full")
                    breed = ui.input("Breed / strain").classes("w-full")
                    queen_line = ui.input("Queen line").classes("w-full")
                    colour = ui.input("Colour / mark").classes("w-full")
                    queen_year = ui.input("Queen year").classes("w-full")
                    method = ui.select(["Caged", "Direct", "Newspaper", "Nuc introduction", "Other"], value="Caged", label="Introduction method").classes("w-full")
                    reason = ui.input("Reason").classes("w-full")
                    marked = ui.checkbox("Marked", value=True)
                    clipped = ui.checkbox("Clipped", value=False)
                    qnotes = ui.textarea("Notes").classes("w-full")
                    def save_queen():
                        OperationsService().install_queen(code, {
                            "supplier": supplier.value,
                            "breed": breed.value,
                            "queen_line": queen_line.value,
                            "colour": colour.value,
                            "queen_year": queen_year.value,
                            "introduction_method": method.value,
                            "reason": reason.value,
                            "marked": marked.value,
                            "clipped": clipped.value,
                            "notes": qnotes.value,
                        })
                        notify(f"Queen operation recorded for {code}.", positive=True)
                        open_colony(code)
                    ui.button("Save Queen Operation", on_click=save_queen, color="positive")

                with ui.tab_panel(feeder_tab):
                    ui.label("Add feeder").classes("text-h5")
                    feeder_type = ui.select(["Rapid feeder", "Contact feeder", "Frame feeder", "Fondant", "Other"], value="Rapid feeder", label="Feeder type").classes("w-full")
                    capacity = ui.input("Capacity / amount").classes("w-full")
                    feed_type = ui.select(["1:1 syrup", "2:1 syrup", "Fondant", "Dry sugar", "Pollen patty", "Protein substitute", "Empty"], value="1:1 syrup", label="Feed type / contents").classes("w-full")
                    feed_remaining = ui.number("Remaining amount", value=0, min=0, step=0.5).classes("w-full")
                    fnotes = ui.textarea("Notes").classes("w-full")
                    def save_feeder():
                        OperationsService().add_feeder(code, {
                            "feeder_type": feeder_type.value,
                            "capacity": capacity.value,
                            "feed_type": feed_type.value,
                            "feed_remaining": feed_remaining.value,
                            "notes": fnotes.value,
                        })
                        notify(f"Feeder added for {code}.", positive=True)
                        open_colony(code)
                    ui.button("Save Feeder Operation", on_click=save_feeder, color="positive")

                with ui.tab_panel(super_tab):
                    ui.label("Add super / honey box").classes("text-h5")
                    ui.label("This is equipment-aware so AOS can estimate honey production later.").style("font-size:12px; color:#64748b;")
                    box_standard = ui.select(["Langstroth", "National", "14x12", "Commercial", "WBC", "Other"], value="Langstroth", label="Box standard").classes("w-full")
                    box_depth = ui.select(["shallow", "medium", "deep"], value="medium", label="Box depth").classes("w-full")
                    frame_count = ui.number("Number of frames fitted", value=10, min=1, step=1).classes("w-full")
                    snotes = ui.textarea("Notes").classes("w-full")
                    def save_super():
                        OperationsService().add_super(code, {
                            "box_standard": box_standard.value,
                            "box_depth": box_depth.value,
                            "frame_count": frame_count.value,
                            "notes": snotes.value,
                        })
                        notify(f"Super added for {code}.", positive=True)
                        open_colony(code)
                    ui.button("Save Super Operation", on_click=save_super, color="positive")
                    ui.button("Configure full hive stack", on_click=lambda: stable_call(lambda: open_configure_colony(code)))

        notify(f"Operations opened for {code}.", positive=True)

    def open_edit_colony(code):
        state["selected"] = code
        data = _colony_data(code)
        colony = data.get("colony") or {}
        header(f"Edit Colony — {code}", """
**Purpose**  
Update practical colony details such as equipment, type and objective.

This edit layer saves your changes as AOS profile overrides without changing the original imported record.
""")
        with main:
            actionbar(code)
            with ui.card().classes("w-full"):
                name = ui.input("Name", value=_safe(colony.get("name"), "")).classes("w-full")
                ctype = ui.input("Type", value=_safe(colony.get("type"), "")).classes("w-full")
                equipment = ui.input("Equipment", value=_safe(colony.get("equipment"), "")).classes("w-full")
                objective = ui.textarea("Objective / management aim", value=_safe(colony.get("objective"), "")).classes("w-full")
                notes = ui.textarea("Profile notes", value=_safe(colony.get("profile_notes"), "")).classes("w-full")

                def save_profile():
                    ColonyProfileService().save(code, {
                        "name": name.value,
                        "type": ctype.value,
                        "equipment": equipment.value,
                        "objective": objective.value,
                        "notes": notes.value,
                    })
                    notify(f"Colony profile updated for {code}.", positive=True)
                    open_colony(code)

                with ui.row():
                    ui.button("Save Colony Details", on_click=save_profile, color="positive")
                    ui.button("Cancel", on_click=lambda: stable_call(lambda: open_colony(code)))

        notify(f"Editing colony details for {code}.", positive=True)

    def open_trends(code):
        state["selected"] = code
        header(f"Trends — {code}", "Trend data only. Actions remain available at the top.")
        with main:
            actionbar(code)
            ui.table(columns=[{"name":"date","label":"Date","field":"date"},{"name":"brood","label":"Brood","field":"brood"},{"name":"stores","label":"Stores","field":"stores"},{"name":"bees","label":"Bees","field":"bees"},{"name":"queen_cells","label":"Q Cells","field":"queen_cells"}],
                     rows=_trends(code), row_key="date").classes("w-full")
        notify(f"Opened trends for {code}.")

    def open_planning():
        header("Planning", "Upcoming jobs and inspection planning.")
        with main:
            jobs = _jobs()
            if jobs:
                ui.table(columns=[{"name":"due","label":"Due","field":"due"},{"name":"colony","label":"Colony","field":"colony"},{"name":"job","label":"Job","field":"job"},{"name":"priority","label":"Priority","field":"priority"}],
                         rows=jobs, row_key="job").classes("w-full")
            else:
                with ui.card().classes("aos3-empty w-full"):
                    ui.label("No jobs generated yet.")
        notify("Planning opened.")


    def open_analysis():
        state["current_workspace"] = "intelligence_centre"
        header("Apiary Intelligence Centre", """
**Purpose**  
This replaces the old Analysis table. It summarises the whole apiary, emerging risks, trends, recommendations and honey production estimates.
""")
        report = ApiaryIntelligenceCentre().report()

        with main:
            with ui.card().classes("w-full"):
                ui.label("Executive Brief").classes("text-h5")
                ui.label(report.get("executive", ""))

            confidence = report.get("confidence", {})
            with ui.row().classes("w-full"):
                for title, value in [
                    ("Overall confidence", confidence.get("overall")),
                    ("Inspection coverage", confidence.get("inspection_coverage")),
                    ("Honey estimate", confidence.get("honey_estimate")),
                ]:
                    with ui.card().classes("aos3-kpi"):
                        ui.label(title).classes("text-caption")
                        ui.label(str(value)).classes("text-h6")

            with ui.row().classes("w-full"):
                with ui.card().classes("w-full"):
                    ui.label("Emerging Risks").classes("text-h6")
                    for item in report.get("emerging_risks", []):
                        ui.label(f"• {item}")
                with ui.card().classes("w-full"):
                    ui.label("Recommendations").classes("text-h6")
                    for item in report.get("recommendations", []):
                        ui.label(f"• {item}")

            with ui.card().classes("w-full"):
                ui.label("Honey Production Estimate").classes("text-h5")
                honey = report.get("honey", {})
                ui.label(honey.get("summary", ""))
                if honey.get("available"):
                    ui.label(f"Extractable now: {honey.get('extractable_low')}–{honey.get('extractable_high')} kg")
                    ui.label(f"Ripening: {honey.get('ripening_low')}–{honey.get('ripening_high')} kg")
                    ui.label("Top contributors").classes("text-h6")
                    for item in honey.get("top_contributors", []):
                        ui.label(f"• {item.get('colony_code')}: {item.get('estimated_extractable_kg_low')}–{item.get('estimated_extractable_kg_high')} kg extractable")
                else:
                    ui.label("Add super records during inspections to activate this estimate.")

            with ui.row().classes("w-full"):
                with ui.card().classes("w-full"):
                    ui.label("Trends").classes("text-h6")
                    for item in report.get("trends", []):
                        ui.label(f"• {item}")
                with ui.card().classes("w-full"):
                    ui.label("Knowledge").classes("text-h6")
                    for item in report.get("knowledge", []):
                        ui.label(f"• {item}")

            with ui.expansion("State evidence table", icon="table_chart").classes("w-full"):
                rows = [
                    {"code": s.get("code"), "health": s.get("health"), "status": s.get("status"), "lane": s.get("lane"), "next": s.get("next_action")}
                    for s in report.get("states", [])
                ]
                ui.table(
                    columns=[
                        {"name":"code","label":"Code","field":"code"},
                        {"name":"health","label":"Health","field":"health"},
                        {"name":"status","label":"Status","field":"status"},
                        {"name":"lane","label":"Lane","field":"lane"},
                        {"name":"next","label":"Next","field":"next"},
                    ],
                    rows=rows,
                    row_key="code",
                ).classes("w-full")
        notify("Apiary Intelligence Centre opened.")

    def search(q):
        query = (q or "").strip().lower()
        if not query:
            notify("Search is empty.", positive=False)
            return
        match = next((c for c in _cards() if query in c.get("code","").lower() or query in c.get("name","").lower()), None)
        if match:
            open_colony(match["code"])
        else:
            header("Search Results", "No match found.")
            with main:
                ui.label(f"No direct colony match for '{q}'.")
                ui.button("Back to Mission Control", on_click=lambda: stable_call(open_home))
            notify(f"Searched for '{q}'.", positive=False)

    with ui.element("div").classes("aos3-root"):
        with ui.element("div").classes("aos3-top"):
            ui.label("🐝 AOS 11.0 Colony Configuration & Inspection Integration").classes("text-h5")
            search_box = ui.input("Search colony...").classes("aos3-search")
            ui.button("Search", on_click=lambda: search(search_box.value))
            ui.label(f"v{APP_VERSION}")

        with ui.element("div").classes("aos3-grid"):
            with ui.column().classes("aos3-nav"):
                ui.label("Workspaces").classes("text-h6")
                ui.button("Home", on_click=lambda: stable_call(open_home))
                ui.button("New Colony", on_click=lambda: stable_call(open_new_colony))
                ui.button("Planning", on_click=lambda: stable_call(open_planning))
                ui.button("Operations", on_click=lambda: stable_call(open_operations_centre))
                ui.button("Intelligence", on_click=lambda: stable_call(open_analysis))
                ui.separator()
                ui.label("Selected Colony").classes("aos3-section")
                ui.button("Open selected", on_click=lambda: open_colony(selected_code()) if selected_code() else notify("No colony selected.", False))
                ui.button("Inspect selected", on_click=lambda: open_inspection_workspace(selected_code()) if selected_code() else notify("No colony selected.", False))
                ui.button("History selected", on_click=lambda: open_history(selected_code()) if selected_code() else notify("No colony selected.", False))
                ui.separator()
                ui.label("Legend").classes("aos3-section")
                for key, s in STATUS.items():
                    ui.label(f"{s['symbol']} {s['label']}").style(f"background:{s['bg']}; color:{s['text']}; padding:4px; border-radius:6px;")

            with ui.column().classes("aos3-main") as main_holder:
                main = ui.column().classes("w-full")

            with ui.column().classes("aos3-inspector") as inspector_holder:
                inspector = ui.column().classes("w-full")

    render_inspector()
    open_home()
