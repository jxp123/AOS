# AOS Professional 11.0 — Operations & Colony Lifecycle

## Purpose

This release removes the developer build step. You no longer need to run `build_setup_with_inno`.

## Install

Run:

`INSTALL_AOS.bat`

## Included

- AOS application
- persistent data location
- automatic pre-upgrade database backup
- desktop shortcut
- portable runner
- data preservation guidance

## Limitation

This is not a compiled `.exe` installer. It is the safest usable installer package available from this environment.
