# AOS 3.6 — apply_live_status Hotfix

Fixes the 500 server error:

NameError: name 'apply_live_status' is not defined

## Cause
The live-status helper was introduced inside the desktop render function, but the module-level card-loading function tried to call it before it existed in that scope.

## Fix
Card loading no longer depends on the render-local live-status helper. The live status is still applied inside the active desktop session where the state exists.
