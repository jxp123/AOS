from nicegui import ui
from aos.core.settings import APP_VERSION
from aos.engines.apiary_assistant import assistant_answer
import importlib
import traceback

NAV_GROUPS = [
    ("Daily Work", [
        ("Dashboard", "aos.ui.v5_dashboard", "page"),
        ("Finance Manager", "aos.ui.finance_manager", "page"),
        ("Multi-Apiary", "aos.ui.multi_apiary", "page"),
        ("Advanced Queen Breeding", "aos.ui.advanced_queen_breeding", "page"),
        ("Production Manager", "aos.ui.production_manager", "page"),
        ("Photo Intelligence", "aos.ui.photo_intelligence", "page"),
        ("AI Apiary Manager", "aos.ui.ai_apiary_manager", "page"),
        ("Complete Apiary Manager", "aos.ui.complete_apiary_manager", "page"),
        ("Predictive Engine", "aos.ui.predictive_engine_v72", "page"),
        ("Analytics & Trends", "aos.ui.analytics_trends", "page"),
        ("Digital Apiary", "aos.ui.digital_apiary_v70", "page"),
        ("Inspection Assistant", "aos.ui.inspection_assistant_v65", "page"),
        ("Colony Workspace", "aos.ui.colony_workspace_v64", "page"),
        ("Intelligence Platform", "aos.ui.intelligence_platform", "page"),
        ("Smart Apiary", "aos.ui.smart_apiary", "page"),
        ("Field Operations", "aos.ui.field_operations", "page"),
        ("Beekeeper Workspace", "aos.ui.beekeeper_workspace", "page"),
        ("Operations Centre", "aos.ui.operations_centre", "page"),
        ("Digital Twin", "aos.ui.digital_twin", "page"),
        ("Today", "aos.ui.daily_operations", "page"),
        ("Inspection Workbench", "aos.ui.workbench", "page"),
        ("Field Inspection Mode", "aos.ui.field_mode", "page"),
        ("Inspection Wizard", "aos.ui.inspection_wizard", "page"),
        ("Inspection Scheduler", "aos.ui.scheduler", "page"),
    ]),
    ("Colony Management", [
        ("Colonies / Records", "aos.ui.records", "page"),
        ("Queens", "aos.ui.breeding_studio", "page"),
        ("Timelines", "aos.ui.timelines", "page"),
    ]),
    ("Hive Health", [
        ("Feeding / Treatments", "aos.ui.feeding_treatments", "page"),
        ("Alerts", "aos.ui.alerts", "page"),
    ]),
    ("Intelligence", [
        ("Apiary Brain", "aos.ui.brain", "page"),
        ("Apiary Assistant", "aos.ui.apiary_assistant", "page"),
        ("Operations Log", "aos.ui.operations_log", "page"),
    ]),
    ("Administration", [
        ("Data Safety", "aos.ui.data_safety", "page"),
        ("Upgrade Manager", "aos.ui.upgrade_manager", "page"),
        ("System Health", "aos.ui.system_health", "page"),
        ("Database", "aos.ui.database_unification", "page"),
        ("Tests / Exports", "aos.ui.tests", "page"),
    ]),
]

def _render_error(title, error):
    ui.label("AOS page error").classes("text-h5 text-negative")
    ui.label(f"{title} failed to load.").classes("text-negative")
    ui.label(str(error)).classes("text-negative")
    ui.textarea("Diagnostic traceback", value=traceback.format_exc()).props("readonly autogrow").classes("w-full")
    print(f"AOS PAGE ERROR — {title}: {error}")
    print(traceback.format_exc())

def render_modern_app():
    ui.add_head_html("""
    <style>
      html, body { background: #f6f7f9; }
      .aos-shell { width: 100%; display: flex; flex-direction: row; gap: 14px; align-items: stretch; flex-wrap: nowrap; }
      .aos-sidebar { background: #102033; color: white; min-height: 86vh; border-radius: 14px; padding: 12px; width: 250px; min-width: 250px; max-width: 250px; }
      .aos-main { background: white; border-radius: 14px; padding: 18px; min-height: 86vh; flex: 1 1 auto; min-width: 520px; overflow-x: auto; }
      .aos-assistant { background: #f9fafb; border-radius: 14px; padding: 14px; min-height: 86vh; border: 1px solid #e5e7eb; width: 330px; min-width: 330px; max-width: 330px; }
      .aos-nav-button { width: 100%; justify-content: flex-start; margin-bottom: 4px; }
      .aos-section-title { color: #a8bdd8; font-size: 12px; text-transform: uppercase; letter-spacing: 0.04em; margin-top: 14px; margin-bottom: 4px; }
      .aos-card { border: 1px solid #e5e7eb; border-radius: 12px; padding: 12px; background: #ffffff; }
      @media (max-width: 1200px) {
        .aos-shell { flex-direction: column; }
        .aos-sidebar, .aos-assistant { width: 100%; min-width: 100%; max-width: 100%; min-height: auto; }
        .aos-main { min-width: 100%; }
      }
    </style>
    """)

    ui.label("🐝 Apiary Operating System").classes("text-h4")
    ui.label(f"v{APP_VERSION} Operations Centre UI").classes("text-subtitle1")

    state = {"content": None, "assistant_output": None}

    def load_page(title, module_name, function_name):
        content = state["content"]
        if content is None:
            return
        content.clear()
        with content:
            try:
                ui.label(title).classes("text-h5")
                module = importlib.import_module(module_name)
                page_func = getattr(module, function_name)
                page_func()
            except Exception as e:
                _render_error(title, e)

    def ask_assistant(question):
        assistant_output = state["assistant_output"]
        if assistant_output is None:
            return
        assistant_output.clear()
        result = assistant_answer(question)
        with assistant_output:
            ui.label("Answer").classes("text-subtitle1")
            ui.textarea(value=result["answer"]).props("readonly autogrow").classes("w-full")
            ui.label(f"Confidence: {result['confidence']}")
            ui.label(f"Source: {result['source']}")

    with ui.element("div").classes("aos-shell"):
        with ui.column().classes("aos-sidebar"):
            ui.label("Navigation").classes("text-h6")
            for group, pages in NAV_GROUPS:
                ui.label(group).classes("aos-section-title")
                for title, module_name, function_name in pages:
                    ui.button(
                        title,
                        on_click=lambda t=title, m=module_name, f=function_name: load_page(t, m, f),
                    ).classes("aos-nav-button")

        with ui.column().classes("aos-main"):
            state["content"] = ui.column().classes("w-full")

        with ui.column().classes("aos-assistant"):
            ui.label("Apiary Assistant").classes("text-h6")
            q = ui.textarea("Ask AOS", placeholder="What should I inspect today?").classes("w-full")
            with ui.row():
                ui.button("Ask", on_click=lambda: ask_assistant(q.value or "summary"))
                ui.button("Today", on_click=lambda: ask_assistant("What should I inspect today?"))
            with ui.row():
                ui.button("Risks", on_click=lambda: ask_assistant("Which colonies worry you?"))
                ui.button("Queens", on_click=lambda: ask_assistant("Which queens should I breed from?"))
            state["assistant_output"] = ui.column().classes("w-full")

    load_page("Dashboard", "aos.ui.v5_dashboard", "page")
    ask_assistant("summary")
