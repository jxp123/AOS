# AOS 5.0 — Task-Centric Mission Control

This release changes Mission Control from a colony-state board to a work board.

## Fixed

- Inspect buttons on Mission Control task cards now open the inspection workspace.
- Mission Control no longer relies on the old Do Today / Watch Closely / Healthy / Upcoming logic as the primary board.
- H17/H19/H6-style due jobs now appear in the work board according to task timing.
- Completed inspections move to Completed Today in the current session.
- Colony State Board is still available inside an expandable background section.

## New Mission Control columns

- Today
- This Week
- Watch List
- Completed Today

## Logic

Colony State Engine still calculates colony state.
Apiary Jobs Engine converts state into practical work.
Mission Control displays work, not just status.
