from __future__ import annotations

from datetime import date, timedelta
from typing import Any, Dict, List

from aos.engines.colony_state_engine import ColonyStateEngine


class ApiaryJobsEngine:
    """Converts colony state into practical work columns for Mission Control."""

    def __init__(self):
        self.state_engine = ColonyStateEngine()

    def _job(self, code: str, title: str, lane: str, priority: str, reason: str, due: str = None, action: str = "Inspect") -> Dict[str, Any]:
        return {
            "code": code,
            "title": title,
            "lane": lane,
            "priority": priority,
            "reason": reason,
            "due": due or str(date.today()),
            "action": action,
        }

    def jobs(self) -> List[Dict[str, Any]]:
        jobs: List[Dict[str, Any]] = []
        for state in self.state_engine.all_states():
            s = state.asdict()
            code = s["code"]

            if s["status"] in ["Overdue", "No inspection record", "Swarm risk"]:
                jobs.append(self._job(
                    code,
                    f"Inspect {code}",
                    "Today",
                    "Urgent",
                    s.get("explain") or s.get("next_action"),
                    action="Inspect",
                ))
                continue

            if s["next_action"] == "Check stores / feed":
                jobs.append(self._job(
                    code,
                    f"Check stores / feed {code}",
                    "Today",
                    "Urgent",
                    s.get("explain") or "Stores appear low.",
                    action="Inspect",
                ))
                continue

            if s["lane"] == "Watch Closely":
                jobs.append(self._job(
                    code,
                    f"Review {code}",
                    "Watch List",
                    "Review",
                    s.get("explain") or "Colony needs attention.",
                    action="Open",
                ))
                continue

            days = s.get("days_since_inspection")
            if days is not None:
                remaining = max(0, 7 - int(days))
                if remaining <= 2:
                    jobs.append(self._job(
                        code,
                        f"Inspection due soon: {code}",
                        "This Week",
                        "Soon",
                        s.get("explain") or f"Next inspection in {remaining} day(s).",
                        due=str(date.today() + timedelta(days=remaining)),
                        action="Open",
                    ))

        return jobs

    def mission_lanes(self) -> Dict[str, List[Dict[str, Any]]]:
        lanes = {"Today": [], "This Week": [], "Watch List": [], "Completed Today": []}
        for j in self.jobs():
            lanes.setdefault(j["lane"], []).append(j)
        return lanes

    def summary(self) -> Dict[str, Any]:
        lanes = self.mission_lanes()
        return {
            "today": len(lanes.get("Today", [])),
            "this_week": len(lanes.get("This Week", [])),
            "watch": len(lanes.get("Watch List", [])),
            "completed": len(lanes.get("Completed Today", [])),
            "total_jobs": sum(len(v) for v in lanes.values()),
        }
