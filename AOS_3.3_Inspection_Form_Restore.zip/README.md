# AOS 3.3 — Inspection Form Restore

This release fixes the blank Inspection Workspace issue in AOS 3.2.

## Fixed

- Inspect now opens a visible inspection form.
- The form includes:
  - today's priorities checklist
  - queen seen
  - eggs seen
  - larvae / open brood seen
  - brood frames
  - stores frames
  - bee coverage frames
  - queen cells
  - temperament
  - notes
  - photo note/reference
- Review Inspection checks consistency warnings.
- Finish Inspection stages the inspection draft for review.
- The form is rendered directly inside the centre workspace to avoid the blank-screen issue.

## Important

Finish Inspection stages a draft using the existing AOS inspection service. It does not silently overwrite data.
