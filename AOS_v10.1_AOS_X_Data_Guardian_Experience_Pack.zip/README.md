# AOS v10.1 — AOS X Data Guardian Experience Pack

This release packages the next-stage AOS X concepts into an installable milestone.

## Works out of the box

- AOS X dashboard.
- Morning briefing.
- Talk to AOS X.
- Top risks.
- Jobs and inventory summary.
- Data Guardian page.
- Guardian backup package.
- Backup verification.
- JSON export.
- Rollback candidate list.
- Restore selected backup.
- `Create_Guardian_Package.bat`.

## Meaning of architectural foundation

The software opens and works. It does not require AI training before it is usable.

However, some advanced features are **rule-based first**:
- recommendations use thresholds, inspection records and risk scores;
- “AI” responses are local database reasoning, not a trained external model;
- photo intelligence and computer vision require a future image-analysis model to diagnose images.

AOS will become more useful as you add more real inspection history because it has more of your own apiary data to reason from.
