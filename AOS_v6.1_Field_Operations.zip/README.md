# AOS v6.1 — Field Operations

Adds route-first field operations and inspection focus for each stop.
