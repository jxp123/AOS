from nicegui import ui
from aos.core.settings import APP_VERSION
from aos.services.repository import Repository

try:
    from aos.engines.digital_twin import apiary_layout, colony_workspace, inspection_focus, confidence_meter, trend_rows
except Exception:
    apiary_layout = colony_workspace = inspection_focus = confidence_meter = trend_rows = None

try:
    from aos.engines.operations_planner import upcoming_jobs
except Exception:
    upcoming_jobs = None

try:
    from aos.engines.intelligence_platform import intelligence_summary
except Exception:
    intelligence_summary = None


STATUS = {
    "urgent": {"label": "Urgent", "symbol": "●", "bg": "#fff1f2", "border": "#9f1239", "text": "#881337"},
    "review": {"label": "Review", "symbol": "▲", "bg": "#fff7ed", "border": "#c2410c", "text": "#7c2d12"},
    "ok": {"label": "OK", "symbol": "■", "bg": "#eff6ff", "border": "#1d4ed8", "text": "#1e3a8a"},
    "info": {"label": "Info", "symbol": "◆", "bg": "#f8fafc", "border": "#64748b", "text": "#334155"},
}


def _safe(value, fallback="—"):
    return value if value not in [None, ""] else fallback


def _repo_cards():
    repo = Repository()
    rows = []
    for c in repo.list_apiary_entities(True):
        rows.append({
            "code": c.get("code", ""),
            "name": c.get("name", ""),
            "type": c.get("type", ""),
            "equipment": c.get("equipment", ""),
            "health": 75,
            "status_badge": "■ OK",
            "queen": "",
            "latest_inspection": "",
            "next_action": "Monitor",
            "reason": c.get("objective", ""),
        })
    return rows


def _cards():
    try:
        if apiary_layout:
            layout = apiary_layout()
            cards = layout.get("hives", []) + layout.get("nucs", []) + layout.get("other", [])
            if cards:
                return cards
    except Exception:
        pass
    return _repo_cards()


def _jobs():
    try:
        if upcoming_jobs:
            return upcoming_jobs()
    except Exception:
        pass
    return []


def _risk_count():
    try:
        if intelligence_summary:
            return intelligence_summary().get("high_risk", 0)
    except Exception:
        pass
    return len([c for c in _cards() if _status_key(c) == "urgent"])


def _status_key(card):
    badge = str(card.get("status_badge", ""))
    health = int(card.get("health") or 0)
    if "Overdue" in badge or "No record" in badge or health < 50:
        return "urgent"
    if "Due" in badge or health < 75:
        return "review"
    return "ok"


def _card_style(key):
    s = STATUS[key]
    return f"background:{s['bg']}; border:2px solid {s['border']}; color:{s['text']}; border-radius:14px;"


def _colony_data(code):
    try:
        if colony_workspace:
            data = colony_workspace(code)
            if data:
                return data
    except Exception:
        pass
    repo = Repository()
    colony = next((c for c in repo.list_apiary_entities(True) if c.get("code") == code), {})
    return {
        "colony": colony,
        "card": next((c for c in _cards() if c.get("code") == code), {}),
        "timeline": [],
        "inspections": [],
        "confidence": {"score": 0, "evidence": [], "missing": ["No data loaded"]},
    }


def _focus(code):
    try:
        if inspection_focus:
            return inspection_focus(code)
    except Exception:
        pass
    return ["Review colony record.", "Check queen, brood, stores and space."]


def _confidence(code):
    try:
        if confidence_meter:
            return confidence_meter(code)
    except Exception:
        pass
    return {"score": 0, "evidence": [], "missing": ["No confidence data"]}


def _trends(code):
    try:
        if trend_rows:
            return trend_rows(code)
    except Exception:
        pass
    return []


def render_aos3():
    ui.add_head_html("""
    <style>
      html, body, #__nuxt { height:100%; margin:0; background:#eef2f7; overflow:hidden; }
      .nicegui-content { height:100vh !important; width:100vw !important; padding:0 !important; overflow:hidden !important; }
      .aos3-root {
        height:100vh; width:100vw;
        display:grid; grid-template-rows:56px minmax(0, 1fr);
        gap:10px; padding:10px; box-sizing:border-box; overflow:hidden;
      }
      .aos3-top {
        display:flex; align-items:center; gap:14px; justify-content:space-between;
        background:#ffffff; border:1px solid #cbd5e1; border-radius:16px;
        padding:8px 12px; box-sizing:border-box; min-height:0;
      }
      .aos3-grid {
        min-height:0; min-width:0;
        display:grid; grid-template-columns:240px minmax(0, 1fr) 360px;
        gap:12px; overflow:hidden;
      }
      .aos3-nav, .aos3-main, .aos3-inspector {
        min-height:0; box-sizing:border-box; border-radius:18px; padding:14px; overflow:auto;
      }
      .aos3-nav { background:#111827; color:white; }
      .aos3-main { background:#ffffff; }
      .aos3-inspector { background:#f8fafc; border:1px solid #cbd5e1; }
      .aos3-nav button { width:100%; justify-content:flex-start; margin:4px 0; }
      .aos3-title-row { display:flex; align-items:center; justify-content:space-between; gap:12px; }
      .aos3-feedback { background:#dbeafe; border-left:5px solid #1d4ed8; padding:8px; border-radius:8px; margin:8px 0; }
      .aos3-kpi { min-width:130px; border:1px solid #cbd5e1; border-radius:14px; background:white; }
      .aos3-lanes { display:grid; grid-template-columns:repeat(4, minmax(205px, 1fr)); gap:10px; align-items:start; }
      .aos3-lane { background:#f8fafc; border:1px solid #cbd5e1; border-radius:14px; padding:10px; min-height:250px; }
      .aos3-card { padding:10px; cursor:pointer; margin-bottom:8px; }
      .aos3-card:hover { outline:3px solid #2563eb; }
      .aos3-actionbar { position:sticky; top:0; z-index:5; background:#f8fafc; border:1px solid #cbd5e1; padding:10px; border-radius:14px; margin:8px 0 12px 0; }
      .aos3-actionbar button { min-width:105px; }
      .aos3-empty { background:#f8fafc; border:1px dashed #94a3b8; padding:10px; border-radius:12px; color:#334155; }
      .aos3-section { color:#bfdbfe; font-size:12px; text-transform:uppercase; letter-spacing:.06em; margin-top:14px; }
      .aos3-search { width:340px; }
    </style>
    """)

    state = {"selected": None, "last": "AOS 3.1 loaded. Menu, Mission Control and Inspector are now fixed in three panes."}

    main = None
    inspector = None

    def selected_code():
        return state.get("selected")

    def notify(message, positive=True):
        state["last"] = message
        ui.notify(message, type="positive" if positive else "warning")
        render_inspector()

    def header(title, purpose=""):
        main.clear()
        with main:
            with ui.row().classes("aos3-title-row w-full"):
                ui.label(title).classes("text-h4")
                ui.label(f"v{APP_VERSION}").classes("text-caption")
            if purpose:
                with ui.expansion("About this workspace", icon="info").classes("w-full"):
                    ui.markdown(purpose)
            with ui.card().classes("aos3-feedback w-full"):
                ui.label(state["last"])

    def render_inspector():
        inspector.clear()
        with inspector:
            ui.label("Inspector").classes("text-h5")
            ui.label(state["last"]).classes("text-caption")
            ui.separator()
            code = selected_code()
            if not code:
                with ui.card().classes("aos3-empty w-full"):
                    ui.label("No colony selected.")
                    ui.label("Click Select on a colony card. This panel updates immediately.")
                ui.label("Rules").classes("text-h6")
                ui.label("Select updates this fixed right panel.")
                ui.label("Open changes the centre workspace.")
                ui.label("Home returns the centre workspace to Mission Control.")
                return
            data = _colony_data(code)
            colony = data.get("colony") or {}
            card = data.get("card") or {}
            conf = data.get("confidence") or _confidence(code)
            ui.label(f"{code} — {_safe(colony.get('name'))}").classes("text-h6")
            with ui.card().classes("w-full"):
                ui.label(f"Health: {card.get('health', 0)}%")
                ui.label(f"Status: {_safe(card.get('status_badge'), 'Unknown')}")
                ui.label(f"Confidence: {conf.get('score', 0)}%")
                ui.label(f"Queen: {_safe(card.get('queen'), 'Not linked')}")
                ui.label(f"Latest: {_safe(card.get('latest_inspection'), 'Never')}")
            ui.label("AI focus").classes("text-h6")
            with ui.card().classes("w-full"):
                for item in _focus(code):
                    ui.label(f"• {item}")
            ui.label("Quick actions").classes("text-h6")
            with ui.row():
                ui.button("Open", on_click=lambda: open_colony(code))
                ui.button("Inspect", on_click=lambda: open_inspection(code))
            with ui.row():
                ui.button("History", on_click=lambda: open_history(code))
                ui.button("Trends", on_click=lambda: open_trends(code))

    def select_colony(code):
        state["selected"] = code
        notify(f"Selected {code}. The fixed Inspector on the right has updated.")

    def actionbar(code):
        with ui.card().classes("aos3-actionbar w-full"):
            with ui.row().classes("w-full"):
                ui.label(f"Actions for {code}").classes("text-h6")
                ui.button("Inspect", on_click=lambda: open_inspection(code))
                ui.button("History", on_click=lambda: open_history(code))
                ui.button("Trends", on_click=lambda: open_trends(code))
                ui.button("Mission Control", on_click=open_home)

    def card_widget(card):
        key = _status_key(card)
        s = STATUS[key]
        with ui.card().classes("aos3-card").style(_card_style(key)):
            ui.label(f"{s['symbol']} {card.get('code')}").classes("text-h6")
            ui.label(f"{s['label']} — {_safe(card.get('status_badge'))}")
            ui.label(f"Health: {card.get('health',0)}%")
            ui.label(f"Queen: {_safe(card.get('queen'))}")
            ui.label(f"Next: {_safe(card.get('next_action'), 'Monitor')}")
            with ui.row():
                ui.button("Select", on_click=lambda c=card.get("code"): select_colony(c))
                ui.button("Open", on_click=lambda c=card.get("code"): open_colony(c))

    def open_home():
        header("Mission Control", """
**Purpose**  
See today's operational position without page-level scrolling.

**How it works**  
The centre workspace is divided into four lanes. The menu remains fixed on the left. The Inspector remains fixed on the right.

**What you can do**  
Select a colony, open its workspace, or start inspection preparation.
""")
        cards = _cards()
        jobs = _jobs()
        lanes = {
            "Do Today": [c for c in cards if _status_key(c) == "urgent"],
            "Watch Closely": [c for c in cards if _status_key(c) == "review"],
            "Healthy": [c for c in cards if _status_key(c) == "ok"],
            "Upcoming": [],
        }
        with main:
            with ui.row().classes("w-full"):
                for title, value in [("Colonies", len(cards)), ("High-risk", _risk_count()), ("Jobs", len(jobs)), ("Selected", selected_code() or "None")]:
                    with ui.card().classes("aos3-kpi"):
                        ui.label(title).classes("text-caption")
                        ui.label(str(value)).classes("text-h5")
            ui.label("Operational Board").classes("text-h5")
            with ui.element("div").classes("aos3-lanes"):
                for lane, lane_cards in lanes.items():
                    with ui.column().classes("aos3-lane"):
                        ui.label(lane).classes("text-h6")
                        if not lane_cards:
                            with ui.card().classes("aos3-empty w-full"):
                                ui.label("No colonies.")
                        for c in lane_cards[:10]:
                            card_widget(c)
            ui.label("Today's Jobs").classes("text-h5")
            if jobs:
                ui.table(
                    columns=[
                        {"name":"due","label":"Due","field":"due"},
                        {"name":"colony","label":"Colony","field":"colony"},
                        {"name":"job","label":"Job","field":"job"},
                        {"name":"priority","label":"Priority","field":"priority"},
                    ],
                    rows=jobs[:8],
                    row_key="job",
                ).classes("w-full")
            else:
                with ui.card().classes("aos3-empty w-full"):
                    ui.label("No jobs generated yet.")
        state["last"] = "Mission Control opened."
        render_inspector()

    def open_colony(code):
        state["selected"] = code
        data = _colony_data(code)
        colony = data.get("colony") or {}
        card = data.get("card") or {}
        conf = data.get("confidence") or _confidence(code)
        header(f"Colony Workspace — {code}", """
**Purpose**  
Work with one colony without losing context.

**What changed in v3.1**  
The menu and Inspector are fixed. Quick actions stay at the top of the centre workspace.
""")
        with main:
            actionbar(code)
            with ui.row().classes("w-full"):
                for title, value in [
                    ("Health", f"{card.get('health',0)}%"),
                    ("Status", _safe(card.get("status_badge"), "Unknown")),
                    ("Confidence", f"{conf.get('score',0)}%"),
                    ("Latest", _safe(card.get("latest_inspection"), "Never")),
                ]:
                    with ui.card().classes("aos3-kpi"):
                        ui.label(title).classes("text-caption")
                        ui.label(str(value)).classes("text-h6")
            with ui.row().classes("w-full"):
                with ui.card().classes("w-full"):
                    ui.label("Current focus").classes("text-h6")
                    for item in _focus(code):
                        ui.label(f"• {item}")
                with ui.card().classes("w-full"):
                    ui.label("Colony record").classes("text-h6")
                    ui.label(f"Name: {_safe(colony.get('name'))}")
                    ui.label(f"Type: {_safe(colony.get('type'))}")
                    ui.label(f"Equipment: {_safe(colony.get('equipment'))}")
                    ui.label(f"Objective: {_safe(colony.get('objective'))}")
            with ui.tabs().classes("w-full") as tabs:
                overview = ui.tab("Overview")
                timeline = ui.tab("Timeline")
                inspections = ui.tab("Inspections")
                trends = ui.tab("Trends")
                confidence = ui.tab("Confidence")
            with ui.tab_panels(tabs, value=overview).classes("w-full"):
                with ui.tab_panel(overview):
                    ui.table(columns=[{"name":"field","label":"Field","field":"field"},{"name":"value","label":"Value","field":"value"}],
                             rows=[{"field":k, "value":str(v)} for k,v in colony.items()], row_key="field").classes("w-full")
                with ui.tab_panel(timeline):
                    ui.table(columns=[{"name":"date","label":"Date","field":"date"},{"name":"type","label":"Type","field":"type"},{"name":"title","label":"Title","field":"title"},{"name":"details","label":"Details","field":"details"}],
                             rows=data.get("timeline", []), row_key="title").classes("w-full")
                with ui.tab_panel(inspections):
                    ui.table(columns=[{"name":"date","label":"Date","field":"date"},{"name":"queen_seen","label":"Queen","field":"queen_seen"},{"name":"eggs_seen","label":"Eggs","field":"eggs_seen"},{"name":"brood_frames","label":"Brood","field":"brood_frames"},{"name":"stores_frames","label":"Stores","field":"stores_frames"},{"name":"notes","label":"Notes","field":"notes"}],
                             rows=data.get("inspections", []), row_key="id").classes("w-full")
                with ui.tab_panel(trends):
                    ui.table(columns=[{"name":"date","label":"Date","field":"date"},{"name":"brood","label":"Brood","field":"brood"},{"name":"stores","label":"Stores","field":"stores"},{"name":"bees","label":"Bees","field":"bees"},{"name":"queen_cells","label":"Q Cells","field":"queen_cells"}],
                             rows=_trends(code), row_key="date").classes("w-full")
                with ui.tab_panel(confidence):
                    ui.label(f"Confidence: {conf.get('score',0)}%").classes("text-h6")
                    with ui.row():
                        with ui.card():
                            ui.label("Evidence")
                            for e in conf.get("evidence", []): ui.label(f"✓ {e}")
                        with ui.card():
                            ui.label("Missing / weaker evidence")
                            for e in conf.get("missing", []): ui.label(f"• {e}")
        notify(f"Opened {code}. Quick actions are at the top of the centre workspace.")

    def open_inspection(code):
        state["selected"] = code
        header(f"Inspection Preparation — {code}", "Quick inspection focus. Use this before opening the hive.")
        with main:
            actionbar(code)
            with ui.card().classes("w-full"):
                ui.label("Inspection focus").classes("text-h6")
                for item in _focus(code):
                    ui.label(f"✓ {item}")
        notify(f"Opened inspection preparation for {code}.")

    def open_history(code):
        state["selected"] = code
        data = _colony_data(code)
        header(f"History — {code}", "Timeline only. Actions remain available at the top.")
        with main:
            actionbar(code)
            ui.table(columns=[{"name":"date","label":"Date","field":"date"},{"name":"type","label":"Type","field":"type"},{"name":"title","label":"Title","field":"title"},{"name":"details","label":"Details","field":"details"}],
                     rows=data.get("timeline", []), row_key="title").classes("w-full")
        notify(f"Opened history for {code}.")

    def open_trends(code):
        state["selected"] = code
        header(f"Trends — {code}", "Trend data only. Actions remain available at the top.")
        with main:
            actionbar(code)
            ui.table(columns=[{"name":"date","label":"Date","field":"date"},{"name":"brood","label":"Brood","field":"brood"},{"name":"stores","label":"Stores","field":"stores"},{"name":"bees","label":"Bees","field":"bees"},{"name":"queen_cells","label":"Q Cells","field":"queen_cells"}],
                     rows=_trends(code), row_key="date").classes("w-full")
        notify(f"Opened trends for {code}.")

    def open_planning():
        header("Planning", "Upcoming jobs and inspection planning.")
        with main:
            jobs = _jobs()
            if jobs:
                ui.table(columns=[{"name":"due","label":"Due","field":"due"},{"name":"colony","label":"Colony","field":"colony"},{"name":"job","label":"Job","field":"job"},{"name":"priority","label":"Priority","field":"priority"}],
                         rows=jobs, row_key="job").classes("w-full")
            else:
                with ui.card().classes("aos3-empty w-full"):
                    ui.label("No jobs generated yet.")
        notify("Planning opened.")

    def open_analysis():
        header("Analysis", "Risk and summary view.")
        with main:
            cards = _cards()
            rows = [{"code": c.get("code"), "health": c.get("health"), "status": c.get("status_badge"), "next": c.get("next_action")} for c in cards]
            ui.table(columns=[{"name":"code","label":"Code","field":"code"},{"name":"health","label":"Health","field":"health"},{"name":"status","label":"Status","field":"status"},{"name":"next","label":"Next","field":"next"}],
                     rows=rows, row_key="code").classes("w-full")
        notify("Analysis opened.")

    def search(q):
        query = (q or "").strip().lower()
        if not query:
            notify("Search is empty.", positive=False)
            return
        match = next((c for c in _cards() if query in c.get("code","").lower() or query in c.get("name","").lower()), None)
        if match:
            open_colony(match["code"])
        else:
            header("Search Results", "No match found.")
            with main:
                ui.label(f"No direct colony match for '{q}'.")
                ui.button("Back to Mission Control", on_click=open_home)
            notify(f"Searched for '{q}'.", positive=False)

    with ui.element("div").classes("aos3-root"):
        with ui.element("div").classes("aos3-top"):
            ui.label("🐝 AOS 3.1 Desktop Framework").classes("text-h5")
            search_box = ui.input("Search colony...").classes("aos3-search")
            ui.button("Search", on_click=lambda: search(search_box.value))
            ui.label(f"v{APP_VERSION}")

        with ui.element("div").classes("aos3-grid"):
            with ui.column().classes("aos3-nav"):
                ui.label("Workspaces").classes("text-h6")
                ui.button("Home", on_click=open_home)
                ui.button("Planning", on_click=open_planning)
                ui.button("Analysis", on_click=open_analysis)
                ui.separator()
                ui.label("Selected Colony").classes("aos3-section")
                ui.button("Open selected", on_click=lambda: open_colony(selected_code()) if selected_code() else notify("No colony selected.", False))
                ui.button("Inspect selected", on_click=lambda: open_inspection(selected_code()) if selected_code() else notify("No colony selected.", False))
                ui.button("History selected", on_click=lambda: open_history(selected_code()) if selected_code() else notify("No colony selected.", False))
                ui.separator()
                ui.label("Legend").classes("aos3-section")
                for key, s in STATUS.items():
                    ui.label(f"{s['symbol']} {s['label']}").style(f"background:{s['bg']}; color:{s['text']}; padding:4px; border-radius:6px;")

            with ui.column().classes("aos3-main") as main_holder:
                main = ui.column().classes("w-full")

            with ui.column().classes("aos3-inspector") as inspector_holder:
                inspector = ui.column().classes("w-full")

    render_inspector()
    open_home()
