# AOS 3.1 — Desktop Framework Layout Fix

This fixes the core layout issue in AOS 3.0.

## Fixed

- Menu is now created inside the fixed left pane.
- Mission Control is now created inside the fixed centre pane.
- Inspector is now created inside the fixed right pane.
- The centre pane scrolls independently.
- The Inspector no longer appears below Mission Control.
- The whole browser page no longer scrolls as a stacked page.

## Why this was needed

AOS 3.0 created dynamic content before the three-pane shell existed. NiceGUI placed that content at the page root, so the intended desktop layout did not actually contain the menu, workspace and inspector.

AOS 3.1 creates the dynamic containers inside their correct panes.
