from __future__ import annotations

import re
import sqlite3
from dataclasses import dataclass, asdict
from datetime import date, timedelta
from pathlib import Path
from typing import Any, Dict, List

from aos.core.settings import DB_PATH
from aos.engines.colony_state_engine import ColonyStateEngine

try:
    from aos.engines.inspection_workspace_v32 import timeline_items
except Exception:
    timeline_items = None


@dataclass
class EvidenceRecommendation:
    code: str
    recommendation_type: str
    title: str
    recommendation: str
    confidence: int
    evidence_for: List[str]
    evidence_against: List[str]
    reasoning: str
    creates_inspection_job: bool
    creates_operation_job: bool
    next_inspection_date: str

    def asdict(self) -> Dict[str, Any]:
        return asdict(self)


class EvidenceBasedIntelligenceEngine:
    """AOS 10.0 evidence-based reasoning layer.

    Purpose:
    - use structured fields and free-text notes
    - avoid same-day reinspection after an inspection has just completed
    - turn follow-up needs into operations, not inspection jobs
    - explain recommendations transparently
    """

    def __init__(self):
        self.state_engine = ColonyStateEngine()
        self.db_path = DB_PATH

    def _timeline(self, code: str) -> List[Dict[str, Any]]:
        try:
            return timeline_items(code) if timeline_items else []
        except Exception:
            return []

    def _latest_notes(self, code: str) -> str:
        text_parts: List[str] = []
        for item in self._timeline(code)[:8]:
            details = " ".join(str(v) for v in item.values() if v)
            text_parts.append(details)
        return " ".join(text_parts).lower()

    def _latest_committed_inspection(self, code: str) -> Dict[str, Any]:
        try:
            with sqlite3.connect(self.db_path) as con:
                con.row_factory = sqlite3.Row
                row = con.execute("""
                    SELECT *
                    FROM aos_committed_inspections
                    WHERE colony_code=?
                    ORDER BY inspection_date DESC, id DESC
                    LIMIT 1
                """, (code,)).fetchone()
            return dict(row) if row else {}
        except Exception:
            return {}

    def inspected_today(self, code: str) -> bool:
        latest = self._latest_committed_inspection(code)
        return str(latest.get("inspection_date") or "") == str(date.today())

    def _note_flags(self, code: str) -> Dict[str, bool]:
        notes = self._latest_notes(code)
        return {
            "feeder_present": bool(re.search(r"\b(feeder|rapid feeder|contact feeder|frame feeder|fondant)\b", notes)),
            "not_taking_feed": bool(re.search(r"(not|aren't|are not|isn't|is not|refus|ignore|not using|not taking).{0,40}(feed|syrup|feeder|fondant)", notes)),
            "taking_feed": bool(re.search(r"(taking|using|emptying|finished|consumed).{0,40}(feed|syrup|feeder|fondant)", notes)),
            "queen_seen_in_notes": "queen seen" in notes or "saw queen" in notes,
            "eggs_seen_in_notes": "eggs" in notes and not re.search(r"no eggs|eggs not|not seen eggs", notes),
            "low_stores_in_notes": bool(re.search(r"low stores|stores low|light stores|short of stores|0\.5 frame", notes)),
        }

    def recommend_for_colony(self, code: str) -> List[EvidenceRecommendation]:
        state = self.state_engine.state_for(code).asdict()
        latest = self._latest_committed_inspection(code)
        flags = self._note_flags(code)
        inspected_today = self.inspected_today(code)

        recs: List[EvidenceRecommendation] = []
        today = date.today()

        def make(
            rtype: str,
            title: str,
            recommendation: str,
            confidence: int,
            evidence_for: List[str],
            evidence_against: List[str],
            reasoning: str,
            operation: bool,
            inspection_days: int = 7,
        ):
            # AOS rule: after inspection today, do not create a further same-day inspection.
            next_date = today + timedelta(days=max(1 if inspected_today else 0, min(inspection_days, 7)))
            recs.append(EvidenceRecommendation(
                code=code,
                recommendation_type=rtype,
                title=title,
                recommendation=recommendation,
                confidence=max(0, min(100, confidence)),
                evidence_for=evidence_for,
                evidence_against=evidence_against,
                reasoning=reasoning,
                creates_inspection_job=False if inspected_today else (rtype == "inspection"),
                creates_operation_job=operation,
                next_inspection_date=str(next_date),
            ))

        # Feeding/store reasoning
        stores_low = (
            state.get("starvation_risk") == "High"
            or str(state.get("next_action") or "").lower().startswith("check stores")
            or flags["low_stores_in_notes"]
        )
        if stores_low:
            evidence_for = []
            evidence_against = []
            if state.get("starvation_risk") == "High":
                evidence_for.append("Colony State Engine flags high starvation/store risk.")
            if flags["low_stores_in_notes"]:
                evidence_for.append("Inspection notes mention low/light stores.")
            if flags["feeder_present"]:
                evidence_against.append("Inspection notes indicate a feeder is already present.")
            if flags["not_taking_feed"]:
                evidence_against.append("Inspection notes indicate bees are not taking/using the feed.")

            if flags["feeder_present"] and flags["not_taking_feed"]:
                make(
                    "stores",
                    "Monitor stores rather than schedule another inspection today",
                    "Do not create a same-day inspection. Reassess stores at the next scheduled inspection and consider checking feeder/forage context.",
                    78,
                    evidence_for,
                    evidence_against,
                    "Stores appear low, but the notes say a feeder is already fitted and bees are not using it. This weakens a simple 'feed now' recommendation.",
                    operation=False,
                    inspection_days=3,
                )
            else:
                make(
                    "operation",
                    "Create feeding operation",
                    "Create an operation to check feed level or provide feed; do not create another inspection job for today.",
                    82,
                    evidence_for,
                    evidence_against,
                    "Low stores are better handled as a feeding operation after an inspection has been completed.",
                    operation=True,
                    inspection_days=3,
                )

        # Queen uncertainty
        queen_uncertain = state.get("queen_status") == "Unconfirmed"
        if queen_uncertain and not (flags["queen_seen_in_notes"] or flags["eggs_seen_in_notes"]):
            make(
                "queen",
                "Queen status follow-up",
                "Confirm queen status at the next inspection window; avoid same-day reinspection unless the beekeeper explicitly chooses it.",
                70,
                ["Queen status is currently unconfirmed."],
                [],
                "Queen uncertainty normally requires follow-up, but once an inspection is completed the next check should be scheduled, not immediately repeated.",
                operation=False,
                inspection_days=3,
            )

        if not recs and state.get("status") == "Current":
            make(
                "routine",
                "Routine monitoring",
                "No additional same-day work is recommended.",
                86,
                ["Colony is current after the latest assessment."],
                [],
                "The inspection job is complete and no separate operation is justified by the evidence.",
                operation=False,
                inspection_days=7,
            )

        return recs

    def primary_recommendation(self, code: str) -> Dict[str, Any]:
        recs = self.recommend_for_colony(code)
        if not recs:
            return {}
        recs = sorted(recs, key=lambda r: r.confidence, reverse=True)
        return recs[0].asdict()

    def operation_jobs(self) -> List[Dict[str, Any]]:
        jobs: List[Dict[str, Any]] = []
        for s in self.state_engine.all_states():
            code = s.code
            for rec in self.recommend_for_colony(code):
                if rec.creates_operation_job:
                    jobs.append({
                        "code": code,
                        "title": rec.title,
                        "priority": "Operation",
                        "due": str(date.today()),
                        "reason": rec.reasoning,
                        "recommendation": rec.recommendation,
                    })
        return jobs
