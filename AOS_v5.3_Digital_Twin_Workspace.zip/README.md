# AOS v5.3 — Digital Twin Workspace

## Added

- Digital Twin page.
- Apiary layout grouped into Hives, Nucs and Other.
- Clickable colony workspace.
- Colony workspace tabs:
  - Overview
  - Timeline
  - Inspections
  - Trends
  - Confidence
- Confidence meter.
- Smart inspection focus.
- Upgrade Manager.
- Pre-upgrade package:
  - SQLite backup
  - JSON export
  - health check

Open **Daily Work → Digital Twin** to view the live apiary.
