# AOS 2.0 — Desktop Transformation Phase 1

This is the first implementation release of the AOS 2.0 design direction.

## Implemented

- Mission Control as the default home screen.
- Four-lane operational board:
  - Do Today
  - Watch Closely
  - Healthy
  - Upcoming
- Stable three-panel desktop layout:
  - left navigation
  - central workspace
  - right Inspector
- Colony-centric workflow.
- Open buttons now open visible colony workspaces.
- Select buttons visibly update the Inspector.
- Home always returns to Mission Control.
- Visible feedback after every action.
- Colour-blind-safe status system:
  - symbol + label + colour
- Guidance panels explaining purpose, logic and outcomes.

## Recommended use

Start here for the AOS 2.0 generation.
