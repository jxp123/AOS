from nicegui import ui
from aos.core.settings import APP_VERSION
from aos.engines.aos_x import aos_x_dashboard
from aos.engines.digital_twin import apiary_layout, colony_workspace, inspection_focus, confidence_meter, trend_rows
from aos.engines.operations_planner import upcoming_jobs
from aos.engines.intelligence_platform import intelligence_summary
from aos.engines.inventory_manager import inventory_rows
from aos.services.repository import Repository

STATUS = {
    "urgent": {"label": "Urgent", "symbol": "●", "bg": "#fff1f2", "border": "#9f1239", "text": "#881337"},
    "review": {"label": "Review", "symbol": "▲", "bg": "#fff7ed", "border": "#c2410c", "text": "#7c2d12"},
    "ok": {"label": "OK", "symbol": "■", "bg": "#eff6ff", "border": "#1d4ed8", "text": "#1e3a8a"},
    "info": {"label": "Info", "symbol": "◆", "bg": "#f8fafc", "border": "#64748b", "text": "#334155"},
}

def _status_key(card):
    badge = card.get("status_badge", "")
    health = int(card.get("health") or 0)
    if "Overdue" in badge or "No record" in badge or health < 50:
        return "urgent"
    if "Due" in badge or health < 75:
        return "review"
    return "ok"

def _card_style(key):
    s = STATUS[key]
    return f"background:{s['bg']}; border:2px solid {s['border']}; color:{s['text']}; border-radius:14px;"

def render_aos2():
    ui.add_head_html("""
    <style>
      html, body { background:#eef2f7; overflow-x:hidden; }
      .aos2-top { height:54px; display:flex; align-items:center; gap:14px; justify-content:space-between; margin-bottom:10px; }
      .aos2-shell { display:grid; grid-template-columns: 238px minmax(760px, 1fr) 360px; gap:14px; min-height:88vh; }
      .aos2-nav { background:#111827; color:white; border-radius:18px; padding:14px; }
      .aos2-main { background:white; border-radius:18px; padding:18px; max-height:88vh; overflow:auto; }
      .aos2-inspector { background:#f8fafc; border:1px solid #cbd5e1; border-radius:18px; padding:14px; max-height:88vh; overflow:auto; }
      .aos2-nav button { width:100%; justify-content:flex-start; margin:4px 0; }
      .aos2-kpi { min-width:165px; border:1px solid #cbd5e1; border-radius:14px; background:white; }
      .aos2-card { min-width:215px; max-width:240px; min-height:180px; padding:10px; cursor:pointer; }
      .aos2-card:hover { outline:3px solid #2563eb; }
      .aos2-banner { background:#dbeafe; border-left:5px solid #1d4ed8; padding:8px; border-radius:8px; }
      .aos2-section { color:#bfdbfe; font-size:12px; text-transform:uppercase; letter-spacing:.06em; margin-top:14px; }
      @media(max-width:1300px){ .aos2-shell { grid-template-columns: 220px 1fr; } .aos2-inspector { grid-column: 1 / span 2; max-height:none; } }
    </style>
    """)

    state = {"selected": None, "last": "AOS 2.0 ready. Mission Control loaded."}
    main = ui.column().classes("w-full")
    inspector = ui.column().classes("w-full")

    def set_feedback(message):
        state["last"] = message
        refresh_inspector()

    def workspace_header(title, purpose="", logic="", outcomes=""):
        main.clear()
        with main:
            ui.label(title).classes("text-h4")
            with ui.expansion("About this workspace", icon="info").classes("w-full"):
                if purpose: ui.markdown(f"**Purpose**\n\n{purpose}")
                if logic: ui.markdown(f"**How it works**\n\n{logic}")
                if outcomes: ui.markdown(f"**What you can achieve**\n\n{outcomes}")
            with ui.card().classes("aos2-banner w-full"):
                ui.label(state["last"])

    def refresh_inspector():
        inspector.clear()
        with inspector:
            ui.label("Inspector").classes("text-h5")
            ui.label(state["last"]).classes("text-caption")
            ui.separator()
            if not state["selected"]:
                ui.label("No colony selected").classes("text-h6")
                ui.label("Select any colony card. The inspector will update immediately.")
                ui.label("Interaction rules").classes("text-h6")
                ui.label("Open = opens a workspace.")
                ui.label("Select = updates the inspector.")
                ui.label("Home = returns to Mission Control.")
                return
            code = state["selected"]
            data = colony_workspace(code)
            colony = data.get("colony") or {}
            card = data.get("card") or {}
            conf = confidence_meter(code)
            ui.label(f"{code} — {colony.get('name','')}").classes("text-h6")
            with ui.card().classes("w-full"):
                ui.label(f"Health: {card.get('health', 0)}%")
                ui.label(f"Status: {card.get('status_badge', 'Unknown')}")
                ui.label(f"Confidence: {conf.get('score',0)}%")
                ui.label(f"Queen: {card.get('queen') or 'Not linked'}")
                ui.label(f"Latest inspection: {card.get('latest_inspection','Never')}")
            ui.label("AI focus").classes("text-h6")
            with ui.card().classes("w-full"):
                for item in inspection_focus(code):
                    ui.label(f"• {item}")
            ui.label("Quick actions").classes("text-h6")
            with ui.row():
                ui.button("Open", on_click=lambda: open_colony(code))
                ui.button("Inspect", on_click=lambda: open_inspection(code))
            with ui.row():
                ui.button("History", on_click=lambda: open_history(code))
                ui.button("Trends", on_click=lambda: open_trends(code))

    def select_colony(code):
        state["selected"] = code
        set_feedback(f"Selected {code}. Inspector updated.")

    def colony_card(card):
        key = _status_key(card)
        s = STATUS[key]
        with ui.card().classes("aos2-card").style(_card_style(key)):
            ui.label(f"{s['symbol']} {card['code']}").classes("text-h6")
            ui.label(f"{s['label']} — {card.get('status_badge','')}")
            ui.label(f"Health: {card.get('health',0)}%")
            ui.label(f"Queen: {card.get('queen') or '—'}")
            ui.label(f"Next: {card.get('next_action','Monitor')}")
            with ui.row():
                ui.button("Select", on_click=lambda c=card["code"]: select_colony(c))
                ui.button("Open", on_click=lambda c=card["code"]: open_colony(c))

    def open_home():
        workspace_header(
            "Mission Control",
            "The default starting point for managing the apiary.",
            "Colonies are grouped by operational status. Status is shown by text, symbol and colour.",
            "Identify today's priorities, select a colony, open its workspace, or plan the visit."
        )
        data = aos_x_dashboard()
        intel = intelligence_summary()
        jobs = upcoming_jobs()
        layout = apiary_layout()
        with main:
            with ui.row().classes("w-full"):
                for title, value in [
                    ("High-risk", intel["high_risk"]),
                    ("Jobs", len(jobs)),
                    ("Hives", len(layout["hives"])),
                    ("Nucs", len(layout["nucs"])),
                    ("Inventory", len(data["inventory"])),
                ]:
                    with ui.card().classes("aos2-kpi"):
                        ui.label(title).classes("text-caption")
                        ui.label(str(value)).classes("text-h5")
            ui.label("Operational Board").classes("text-h5")
            lanes = [
                ("Do Today", [c for c in layout["hives"] + layout["nucs"] + layout["other"] if _status_key(c) == "urgent"]),
                ("Watch Closely", [c for c in layout["hives"] + layout["nucs"] + layout["other"] if _status_key(c) == "review"]),
                ("Healthy", [c for c in layout["hives"] + layout["nucs"] + layout["other"] if _status_key(c) == "ok"]),
                ("Upcoming", []),
            ]
            with ui.row().classes("w-full").style("align-items:flex-start;"):
                for lane, cards in lanes:
                    with ui.column().style("min-width:250px; flex:1;"):
                        ui.label(lane).classes("text-h6")
                        if not cards:
                            with ui.card().classes("w-full"):
                                ui.label("No colonies in this lane.")
                        for c in cards[:12]:
                            colony_card(c)
            ui.label("Today's Jobs").classes("text-h5")
            ui.table(
                columns=[
                    {"name":"due","label":"Due","field":"due"},
                    {"name":"colony","label":"Colony","field":"colony"},
                    {"name":"job","label":"Job","field":"job"},
                    {"name":"priority","label":"Priority","field":"priority"},
                ],
                rows=jobs[:10],
                row_key="job",
            ).classes("w-full")
        set_feedback("Mission Control opened.")

    def open_colony(code):
        state["selected"] = code
        workspace_header(
            f"Colony Workspace — {code}",
            "Everything about the selected colony in one place.",
            "AOS combines colony record, inspection history, timeline, confidence and trend evidence.",
            "Review the colony, understand its condition, and choose the next practical action."
        )
        data = colony_workspace(code)
        colony = data.get("colony") or {}
        card = data.get("card") or {}
        conf = data.get("confidence") or {}
        with main:
            with ui.row().classes("w-full"):
                for title, value in [
                    ("Health", f"{card.get('health',0)}%"),
                    ("Status", card.get("status_badge","Unknown")),
                    ("Confidence", f"{conf.get('score',0)}%"),
                    ("Latest", card.get("latest_inspection","Never")),
                ]:
                    with ui.card().classes("aos2-kpi"):
                        ui.label(title).classes("text-caption")
                        ui.label(str(value)).classes("text-h6")
            with ui.tabs().classes("w-full") as tabs:
                overview = ui.tab("Overview")
                timeline = ui.tab("Timeline")
                inspections = ui.tab("Inspections")
                trends = ui.tab("Trends")
                confidence = ui.tab("Confidence")
            with ui.tab_panels(tabs, value=overview).classes("w-full"):
                with ui.tab_panel(overview):
                    ui.table(
                        columns=[{"name":"field","label":"Field","field":"field"},{"name":"value","label":"Value","field":"value"}],
                        rows=[{"field":k, "value":str(v)} for k,v in colony.items()],
                        row_key="field",
                    ).classes("w-full")
                with ui.tab_panel(timeline):
                    ui.table(
                        columns=[{"name":"date","label":"Date","field":"date"},{"name":"type","label":"Type","field":"type"},{"name":"title","label":"Title","field":"title"},{"name":"details","label":"Details","field":"details"}],
                        rows=data.get("timeline", []),
                        row_key="title",
                    ).classes("w-full")
                with ui.tab_panel(inspections):
                    ui.table(
                        columns=[{"name":"date","label":"Date","field":"date"},{"name":"queen_seen","label":"Queen","field":"queen_seen"},{"name":"eggs_seen","label":"Eggs","field":"eggs_seen"},{"name":"brood_frames","label":"Brood","field":"brood_frames"},{"name":"stores_frames","label":"Stores","field":"stores_frames"},{"name":"notes","label":"Notes","field":"notes"}],
                        rows=data.get("inspections", []),
                        row_key="id",
                    ).classes("w-full")
                with ui.tab_panel(trends):
                    ui.table(
                        columns=[{"name":"date","label":"Date","field":"date"},{"name":"brood","label":"Brood","field":"brood"},{"name":"stores","label":"Stores","field":"stores"},{"name":"bees","label":"Bees","field":"bees"},{"name":"queen_cells","label":"Q Cells","field":"queen_cells"}],
                        rows=trend_rows(code),
                        row_key="date",
                    ).classes("w-full")
                with ui.tab_panel(confidence):
                    ui.label(f"Confidence: {conf.get('score',0)}%").classes("text-h6")
                    with ui.row():
                        with ui.card():
                            ui.label("Evidence")
                            for e in conf.get("evidence", []): ui.label(f"✓ {e}")
                        with ui.card():
                            ui.label("Missing / weaker evidence")
                            for e in conf.get("missing", []): ui.label(f"• {e}")
        set_feedback(f"Opened colony workspace for {code}.")

    def open_inspection(code):
        state["selected"] = code
        workspace_header(
            f"Inspection Preparation — {code}",
            "Prepare before opening the colony.",
            "AOS highlights what should be checked from current confidence, risk and latest history.",
            "Use this to focus the inspection before recording data in the inspection workflow."
        )
        with main:
            with ui.card().classes("w-full"):
                ui.label("Inspection focus").classes("text-h6")
                for item in inspection_focus(code):
                    ui.label(f"✓ {item}")
            ui.label("Next step: record the inspection using Field Inspection Mode or Inspection Assistant.").classes("text-subtitle1")
        set_feedback(f"Inspection preparation opened for {code}.")

    def open_history(code):
        state["selected"] = code
        data = colony_workspace(code)
        workspace_header(f"History — {code}", "Review colony timeline.", "", "Understand what has changed over time.")
        with main:
            ui.table(
                columns=[{"name":"date","label":"Date","field":"date"},{"name":"type","label":"Type","field":"type"},{"name":"title","label":"Title","field":"title"},{"name":"details","label":"Details","field":"details"}],
                rows=data.get("timeline", []),
                row_key="title",
            ).classes("w-full")
        set_feedback(f"Opened history for {code}.")

    def open_trends(code):
        state["selected"] = code
        workspace_header(f"Trends — {code}", "Review colony trend evidence.", "", "Spot brood, stores or population changes.")
        with main:
            ui.table(
                columns=[{"name":"date","label":"Date","field":"date"},{"name":"brood","label":"Brood","field":"brood"},{"name":"stores","label":"Stores","field":"stores"},{"name":"bees","label":"Bees","field":"bees"},{"name":"queen_cells","label":"Q Cells","field":"queen_cells"}],
                rows=trend_rows(code),
                row_key="date",
            ).classes("w-full")
        set_feedback(f"Opened trends for {code}.")

    def open_planning():
        workspace_header("Planning Workspace", "Plan inspections, seasonal tasks and upcoming work.", "", "Prepare the next apiary visit.")
        with main:
            ui.table(
                columns=[{"name":"due","label":"Due","field":"due"},{"name":"colony","label":"Colony","field":"colony"},{"name":"job","label":"Job","field":"job"},{"name":"priority","label":"Priority","field":"priority"}],
                rows=upcoming_jobs(),
                row_key="job",
            ).classes("w-full")
        set_feedback("Planning Workspace opened.")

    def open_analysis():
        workspace_header("Analysis Workspace", "Understand risk and trends.", "", "Use evidence to prioritise work.")
        data = aos_x_dashboard()
        with main:
            ui.table(
                columns=[{"name":"code","label":"Code","field":"code"},{"name":"swarm_prediction","label":"Swarm","field":"swarm_prediction"},{"name":"queen_failure_prediction","label":"Queen Failure","field":"queen_failure_prediction"},{"name":"starvation_prediction","label":"Starvation","field":"starvation_prediction"},{"name":"recommendation","label":"Recommendation","field":"recommendation"}],
                rows=data["top_risks"],
                row_key="code",
            ).classes("w-full")
        set_feedback("Analysis Workspace opened.")

    def open_inventory():
        workspace_header("Inventory Workspace", "Review equipment and consumables.", "", "Know what to prepare or buy.")
        with main:
            ui.table(
                columns=[{"name":"item","label":"Item","field":"item"},{"name":"type","label":"Type","field":"type"},{"name":"location","label":"Location","field":"location"},{"name":"status","label":"Status","field":"status"},{"name":"reorder","label":"Reorder","field":"reorder"}],
                rows=inventory_rows(),
                row_key="item",
            ).classes("w-full")
        set_feedback("Inventory Workspace opened.")

    def search(query):
        q = (query or "").strip().lower()
        if not q:
            set_feedback("Search is empty.")
            return
        repo = Repository()
        match = next((c for c in repo.list_apiary_entities(True) if q in c["code"].lower() or q in c["name"].lower()), None)
        if match:
            open_colony(match["code"])
        else:
            workspace_header("Search Results", "Search across current AOS records.", "", "Find a colony by code or name.")
            with main:
                ui.label(f"No direct colony match for: {query}")
            set_feedback(f"Searched for '{query}'.")

    refresh_inspector()

    with ui.row().classes("aos2-top w-full"):
        ui.label("🐝 AOS 2.0 Desktop Transformation").classes("text-h4")
        search_box = ui.input("Search colony, queen, action...")
        ui.button("Search", on_click=lambda: search(search_box.value))
        ui.label(f"v{APP_VERSION}")

    with ui.element("div").classes("aos2-shell"):
        with ui.column().classes("aos2-nav"):
            ui.label("Workspaces").classes("text-h6")
            ui.button("Home", on_click=open_home)
            ui.button("Planning", on_click=open_planning)
            ui.button("Analysis", on_click=open_analysis)
            ui.button("Inventory", on_click=open_inventory)
            ui.separator()
            ui.label("Selected Colony").classes("aos2-section")
            ui.button("Open selected", on_click=lambda: open_colony(state["selected"]) if state["selected"] else set_feedback("No colony selected."))
            ui.button("Inspect selected", on_click=lambda: open_inspection(state["selected"]) if state["selected"] else set_feedback("No colony selected."))
            ui.button("History selected", on_click=lambda: open_history(state["selected"]) if state["selected"] else set_feedback("No colony selected."))
            ui.separator()
            ui.label("Legend").classes("aos2-section")
            for key, s in STATUS.items():
                ui.label(f"{s['symbol']} {s['label']}").style(f"background:{s['bg']}; color:{s['text']}; padding:4px; border-radius:6px;")

        with ui.column().classes("aos2-main"):
            main

        with ui.column().classes("aos2-inspector"):
            inspector

    open_home()
