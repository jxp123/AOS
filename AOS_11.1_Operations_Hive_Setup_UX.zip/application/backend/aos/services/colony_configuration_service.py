from __future__ import annotations
import sqlite3
from datetime import date, datetime
from pathlib import Path
from typing import Any, Dict
from aos.core.settings import DB_PATH

class ColonyConfigurationService:
    """Current physical configuration / digital twin for a colony."""
    def __init__(self):
        self.db_path = DB_PATH

    def ensure_schema(self) -> None:
        Path(self.db_path).parent.mkdir(parents=True, exist_ok=True)
        with sqlite3.connect(self.db_path) as con:
            con.execute("""
                CREATE TABLE IF NOT EXISTS aos_colony_components (
                    component_id TEXT PRIMARY KEY,
                    colony_code TEXT NOT NULL,
                    component_type TEXT NOT NULL,
                    position_index INTEGER DEFAULT 0,
                    status TEXT DEFAULT 'installed',
                    box_standard TEXT,
                    box_depth TEXT,
                    frame_count REAL DEFAULT 0,
                    asset_label TEXT,
                    feed_type TEXT,
                    feed_amount REAL DEFAULT 0,
                    feed_remaining REAL DEFAULT 0,
                    notes TEXT,
                    installed_date TEXT,
                    removed_date TEXT,
                    updated_at TEXT NOT NULL
                )
            """)
            con.execute("""
                CREATE TABLE IF NOT EXISTS aos_component_observations (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    component_id TEXT NOT NULL,
                    colony_code TEXT NOT NULL,
                    observation_date TEXT NOT NULL,
                    frames_drawn REAL DEFAULT 0,
                    frames_with_honey REAL DEFAULT 0,
                    percent_capped REAL DEFAULT 0,
                    percent_uncapped REAL DEFAULT 0,
                    bees_taking_feed TEXT,
                    condition_notes TEXT,
                    action TEXT,
                    created_at TEXT NOT NULL
                )
            """)
            con.execute("""
                CREATE TABLE IF NOT EXISTS aos_equipment_inventory (
                    asset_id TEXT PRIMARY KEY,
                    asset_type TEXT NOT NULL,
                    asset_label TEXT,
                    box_standard TEXT,
                    box_depth TEXT,
                    frame_count REAL DEFAULT 0,
                    current_location TEXT DEFAULT 'storage',
                    status TEXT DEFAULT 'available',
                    notes TEXT,
                    updated_at TEXT NOT NULL
                )
            """)
            con.commit()

    def _component_id(self, code: str, ctype: str, index: int) -> str:
        return f"{code}:{ctype}:{index}"

    def seed_default_if_empty(self, code: str, hive_system: str = "Langstroth", frames: int = 10) -> None:
        self.ensure_schema()
        with sqlite3.connect(self.db_path) as con:
            existing = con.execute("SELECT COUNT(*) FROM aos_colony_components WHERE colony_code=? AND status='installed'", (code,)).fetchone()[0]
        if existing:
            return
        self.upsert_component(code, "floor", 1, box_standard=hive_system, asset_label="Floor", notes="Default floor")
        self.upsert_component(code, "brood_box", 1, box_standard=hive_system, box_depth="deep", frame_count=frames, asset_label="Brood box 1")
        self.upsert_component(code, "crownboard", 1, asset_label="Crownboard")
        self.upsert_component(code, "roof", 1, asset_label="Roof")

    def upsert_component(self, code: str, component_type: str, position_index: int = 1, **values: Any) -> str:
        self.ensure_schema()
        cid = values.get("component_id") or self._component_id(code, component_type, int(position_index or 1))
        now = datetime.now().isoformat(timespec="seconds")
        with sqlite3.connect(self.db_path) as con:
            con.execute("""
                INSERT INTO aos_colony_components (
                    component_id, colony_code, component_type, position_index, status,
                    box_standard, box_depth, frame_count, asset_label, feed_type,
                    feed_amount, feed_remaining, notes, installed_date, removed_date, updated_at
                )
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(component_id) DO UPDATE SET
                    status=excluded.status,
                    box_standard=excluded.box_standard,
                    box_depth=excluded.box_depth,
                    frame_count=excluded.frame_count,
                    asset_label=excluded.asset_label,
                    feed_type=excluded.feed_type,
                    feed_amount=excluded.feed_amount,
                    feed_remaining=excluded.feed_remaining,
                    notes=excluded.notes,
                    installed_date=COALESCE(aos_colony_components.installed_date, excluded.installed_date),
                    removed_date=excluded.removed_date,
                    updated_at=excluded.updated_at
            """, (
                cid, code, component_type, int(position_index or 1), values.get("status") or "installed",
                values.get("box_standard") or "", values.get("box_depth") or "", float(values.get("frame_count") or 0),
                values.get("asset_label") or "", values.get("feed_type") or "", float(values.get("feed_amount") or 0),
                float(values.get("feed_remaining") or 0), values.get("notes") or "", values.get("installed_date") or str(date.today()),
                values.get("removed_date") or "", now
            ))
            con.commit()
        return cid

    def remove_component(self, component_id: str, destination: str = "storage", notes: str = "") -> None:
        self.ensure_schema()
        now = datetime.now().isoformat(timespec="seconds")
        with sqlite3.connect(self.db_path) as con:
            con.execute("""
                UPDATE aos_colony_components
                SET status=?, removed_date=?, notes=TRIM(COALESCE(notes,'') || CHAR(10) || ?), updated_at=?
                WHERE component_id=?
            """, (f"removed:{destination}", str(date.today()), notes, now, component_id))
            con.commit()

    def configuration(self, code: str) -> Dict[str, Any]:
        self.ensure_schema()
        self.seed_default_if_empty(code)
        with sqlite3.connect(self.db_path) as con:
            con.row_factory = sqlite3.Row
            rows = con.execute("""
                SELECT * FROM aos_colony_components
                WHERE colony_code=? AND status='installed'
                ORDER BY CASE component_type
                    WHEN 'roof' THEN 1 WHEN 'insulation' THEN 2 WHEN 'crownboard' THEN 3
                    WHEN 'feeder' THEN 4 WHEN 'super' THEN 5 WHEN 'queen_excluder' THEN 6
                    WHEN 'brood_box' THEN 7 WHEN 'dummy_board' THEN 8 WHEN 'floor' THEN 9 ELSE 20 END,
                    position_index DESC
            """, (code,)).fetchall()
        components = [dict(r) for r in rows]
        return {"code": code, "components": components, "supers": [c for c in components if c.get("component_type") == "super"], "feeders": [c for c in components if c.get("component_type") == "feeder"], "brood_boxes": [c for c in components if c.get("component_type") == "brood_box"]}

    def observe_component(self, code: str, component_id: str, values: Dict[str, Any]) -> None:
        self.ensure_schema()
        with sqlite3.connect(self.db_path) as con:
            con.execute("""
                INSERT INTO aos_component_observations (
                    component_id, colony_code, observation_date, frames_drawn, frames_with_honey,
                    percent_capped, percent_uncapped, bees_taking_feed, condition_notes, action, created_at
                )
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (component_id, code, str(date.today()), float(values.get("frames_drawn") or 0), float(values.get("frames_with_honey") or 0), float(values.get("percent_capped") or 0), float(values.get("percent_uncapped") or 0), values.get("bees_taking_feed") or "", values.get("condition_notes") or "", values.get("action") or "Leave", datetime.now().isoformat(timespec="seconds")))
            con.commit()

    def save_super_observation_to_honey_engine(self, code: str, component: Dict[str, Any], values: Dict[str, Any]) -> None:
        self.ensure_schema()
        with sqlite3.connect(self.db_path) as con:
            con.execute("""
                CREATE TABLE IF NOT EXISTS aos_super_records (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    colony_code TEXT NOT NULL,
                    record_date TEXT NOT NULL,
                    super_type TEXT DEFAULT 'shallow',
                    frames_total REAL DEFAULT 10,
                    frames_drawn REAL DEFAULT 0,
                    percent_capped REAL DEFAULT 0,
                    percent_uncapped REAL DEFAULT 0,
                    intended_for_harvest INTEGER DEFAULT 1,
                    notes TEXT
                )
            """)
            super_type = " ".join(x for x in [component.get("box_standard"), component.get("box_depth")] if x)
            con.execute("""
                INSERT INTO aos_super_records (
                    colony_code, record_date, super_type, frames_total, frames_drawn,
                    percent_capped, percent_uncapped, intended_for_harvest, notes
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (code, str(date.today()), super_type or "super", float(component.get("frame_count") or 10), float(values.get("frames_drawn") or 0), float(values.get("percent_capped") or 0), float(values.get("percent_uncapped") or 0), 1, f"Component {component.get('component_id')}: {values.get('condition_notes') or ''}"))
            con.commit()

    def component_options(self, component_type: str) -> Dict[str, Any]:
        """Return equipment-type-specific fields for the UI.

        The UI uses this so adding a feeder asks feeder questions,
        adding a super asks super questions, etc.
        """
        component_type = (component_type or "").lower()
        if component_type == "feeder":
            return {
                "box_standard": False,
                "box_depth": False,
                "frames": False,
                "feed": True,
                "labels": {
                    "asset": "Feeder type / asset label",
                    "notes": "Feeder notes",
                },
                "asset_examples": ["Abelo Ashforth poly feeder", "Rapid feeder", "Contact feeder", "Frame feeder", "Fondant eke"],
            }
        if component_type == "super":
            return {
                "box_standard": True,
                "box_depth": True,
                "frames": True,
                "feed": False,
                "labels": {
                    "asset": "Super label",
                    "notes": "Super notes",
                },
            }
        if component_type == "brood_box":
            return {
                "box_standard": True,
                "box_depth": True,
                "frames": True,
                "feed": False,
                "labels": {
                    "asset": "Brood box label",
                    "notes": "Brood box notes",
                },
            }
        if component_type in {"floor", "roof", "crownboard", "queen_excluder", "dummy_board", "insulation"}:
            return {
                "box_standard": component_type in {"floor"},
                "box_depth": False,
                "frames": False,
                "feed": False,
                "labels": {
                    "asset": component_type.replace("_", " ").title() + " type",
                    "notes": component_type.replace("_", " ").title() + " notes",
                },
            }
        return {"box_standard": True, "box_depth": True, "frames": True, "feed": False, "labels": {"asset": "Asset label", "notes": "Notes"}}

