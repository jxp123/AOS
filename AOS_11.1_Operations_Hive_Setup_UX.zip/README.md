# AOS Professional 11.1 — Windows Setup Project

This package prepares AOS for a real Windows `Setup.exe`.

## What is included

- Full AOS application folder
- Inno Setup installer script
- NSIS installer script alternative
- PowerShell build script
- Windows run launcher
- Installation guide
- Upgrade guide
- Release notes

## Important

This package contains the installer project. To produce the actual `.exe`, build it on Windows using Inno Setup 6.

## Build the setup.exe

1. Install **Inno Setup 6**.
2. Extract this ZIP.
3. Run:

`build_setup_with_inno.bat`

4. The compiled installer will be created in:

`dist\AOS_Professional_8.6_Setup.exe`

## Data preservation

The installer stores user data in:

`%LOCALAPPDATA%\AOS\data\aos.db`

Application files are installed to:

`%LOCALAPPDATA%\AOS\Application`

Before upgrade, the installer backs up the existing database to:

`%LOCALAPPDATA%\AOS\backups`
