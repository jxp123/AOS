# AOS 7.1 — Intelligent Inspection Workflow

## Fixed

- Removed the workflow confusion around Start Inspection.
- The action is now labelled **Record Inspection**.
- If already on the inspection screen, Record Inspection scrolls to the inspection form instead of rebuilding the page.
- This avoids the NiceGUI deleted-parent lifecycle error.

## Completed Today

Completed Today cards now show:

- colony inspected
- next recommended inspection date
- explanation for the revisit interval
- short summary of the inspection

The next inspection defaults to 7 days, but AOS shortens it when inspection findings suggest earlier follow-up. It is never longer than 7 days.

## Next inspection rules

- Routine: 7 days
- Queen or eggs not confirmed: 3 days
- Low stores: 3 days
- Queen cells / swarm action: 2 days
- Disease concern: 2 days
- Poor/patchy brood: 4 days
