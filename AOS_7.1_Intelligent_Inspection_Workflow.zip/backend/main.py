from nicegui import ui
from aos.core.bootstrap import boot
from aos.ui.aos3_desktop import render_aos3
from aos.ui.diagnostics import diagnostic_rows
from aos.services.data_portability_service import DataPortabilityService
from aos.services.professional_baseline_service import ProfessionalBaselineService

boot()

@ui.page("/")
def index():
    render_aos3()

@ui.page("/export-data")
def data_export_page():
    ui.label("AOS Data Export").classes("text-h4")
    try:
        json_path = DataPortabilityService().export_json()
        db_path = DataPortabilityService().export_sqlite_backup()
        ui.label(f"JSON export created: {json_path}")
        ui.label(f"SQLite backup created: {db_path}")
    except Exception as e:
        ui.label(str(e)).classes("text-negative")


@ui.page("/healthcheck")
def healthcheck():
    ui.label("AOS 7.0 Professional Baseline Healthcheck").classes("text-h4")
    result = ProfessionalBaselineService().healthcheck()
    ui.label(f"Score: {result['score']}%").classes("text-h5")
    ui.table(
        columns=[
            {"name":"name","label":"Check","field":"name"},
            {"name":"status","label":"Status","field":"status"},
            {"name":"detail","label":"Detail","field":"detail"},
        ],
        rows=result["checks"],
        row_key="name",
    ).classes("w-full")

@ui.page("/diag")
def diag():
    ui.label("AOS Diagnostics").classes("text-h4")
    ui.table(
        columns=[
            {"name":"item","label":"Item","field":"item"},
            {"name":"value","label":"Value","field":"value"},
        ],
        rows=diagnostic_rows(),
        row_key="item",
    ).classes("w-full")

ui.run(title="AOS 7.0 Professional Edition", host="127.0.0.1", port=8000, reload=False)
