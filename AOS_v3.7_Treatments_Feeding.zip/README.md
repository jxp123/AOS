# AOS v3.7 — Treatments and Feeding

## Added

- Feeding / Treatments tab.
- Feeding record entry.
- Treatment record entry.
- Treatment follow-up alerts.
- Feeding review alerts for nucs/recovering colonies.
- Daily Operations includes feeding/treatment alerts.
- Excel export includes Feedings and Treatments.
- AI export includes feeding/treatment data.
- Self-test includes feeding/treatment engine.

## Use

Open **Feeding / Treatments** to record syrup, fondant, treatment actions, varroa checks and follow-up dates.
