@echo off
cd /d "%~dp0"
if not exist logs mkdir logs
if not exist .venv call Install_AOS.bat
if exist data\aos.db (
  if not exist backups mkdir backups
  copy data\aos.db backups\aos_pre_start_backup.db >nul
)
call .venv\Scripts\activate.bat
set PYTHONPATH=%CD%\backend
start "" http://127.0.0.1:8000
python backend\main.py > logs\aos_run.log 2>&1
pause
