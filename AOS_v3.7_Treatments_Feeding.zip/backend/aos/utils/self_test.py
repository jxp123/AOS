from sqlalchemy import text
from aos.db.session import session_scope
from aos.core.bootstrap import boot
from aos.services.repository import Repository
from aos.services.draft_service import DraftService
from aos.engines.scheduler import inspection_schedule
from aos.engines.brain import apiary_brain_state
from aos.engines.operations import todays_work
from aos.engines.workbench import workbench_rows
from aos.engines.daily_operations import daily_dashboard
from aos.engines.timelines import timeline_summary
from aos.engines.feeding_treatment_engine import feeding_treatment_summary
from aos.engines.natural_language import parse_note

def result(test,status,message=''): return {'test':test,'status':status,'message':message}
def run_self_tests():
    rows=[]
    try:
        boot();
        with session_scope() as s: s.execute(text('SELECT 1'))
        rows.append(result('database','PASS'))
    except Exception as e: rows.append(result('database','FAIL',str(e)))
    repo=Repository(); checks=[('colonies',lambda:len(repo.list_colonies())),('queens',lambda:len(repo.list_queens())),('equipment',lambda:len(repo.list_equipment())),('inspections',lambda:len(repo.list_inspections())),('weather',lambda:len(repo.list_weather())),('scheduler',lambda:len(inspection_schedule())),('apiary brain',lambda:apiary_brain_state()['apiary_priority_score']),('operations',lambda:todays_work()['estimated_duration']),('natural language',lambda:parse_note('Hive 16 queen seen 6 brood 2 stores')['colony_code']),('draft service',lambda:DraftService().validate({'colony_id':1,'inspection_date':'2026-07-03'})['status'])]
    for name,fn in checks:
        try: rows.append(result(name,'PASS',str(fn())))
        except Exception as e: rows.append(result(name,'FAIL',str(e)))
    return rows
def summary(rows): return {'pass':len([r for r in rows if r['status']=='PASS']),'fail':len([r for r in rows if r['status']=='FAIL']),'total':len(rows)}
def main():
    rows=run_self_tests()
    for r in rows: print(f"[{r['status']}] {r['test']}: {r['message']}")
    s=summary(rows); print(f"PASS={s['pass']} FAIL={s['fail']} TOTAL={s['total']}")
    if s['fail']: raise SystemExit(1)
if __name__=='__main__': main()
