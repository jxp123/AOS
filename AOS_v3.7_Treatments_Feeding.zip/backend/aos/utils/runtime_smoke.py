PAGES = [
    ("Apiary Brain", "aos.ui.brain", "page"),
    ("Daily Operations", "aos.ui.daily_operations", "page"),
    ("Operations", "aos.ui.operations", "page"),
    ("Inspection Workbench", "aos.ui.workbench", "page"),
    ("Inspection Wizard", "aos.ui.inspection_wizard", "page"),
    ("Inspection Scheduler", "aos.ui.scheduler", "page"),
    ("Natural Language", "aos.ui.natural_language", "page"),
    ("Guided Inspection", "aos.ui.guided", "page"),
    ("Records", "aos.ui.records", "page"),
    ("Timelines", "aos.ui.timelines", "page"),
    ("Alerts", "aos.ui.alerts", "page"),
    ("Operations Log", "aos.ui.operations_log", "page"),
    ("Tests", "aos.ui.tests", "page"),
]

def run_runtime_smoke():
    import importlib
    from nicegui import ui
    from aos.core.bootstrap import boot

    boot()
    results = []
    for name, module_name, function_name in PAGES:
        try:
            module = importlib.import_module(module_name)
            page_func = getattr(module, function_name)
            with ui.card():
                page_func()
            results.append({"page": name, "status": "PASS", "message": ""})
        except Exception as e:
            results.append({"page": name, "status": "FAIL", "message": repr(e)})
    return results

def main():
    rows = run_runtime_smoke()
    for row in rows:
        print(f"[{row['status']}] {row['page']}: {row['message']}")
    if any(r["status"] == "FAIL" for r in rows):
        raise SystemExit(1)

if __name__ == "__main__":
    main()
