from nicegui import ui
from aos.core.bootstrap import boot
from aos.ui.shell import render_app
boot()
@ui.page("/")
def index():
    render_app()
ui.run(title="AOS", host="127.0.0.1", port=8000, reload=False)
