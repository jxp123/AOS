import py_compile
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
BACKEND = ROOT / "backend"
sys.path.insert(0, str(BACKEND))

errors = []
for p in BACKEND.rglob("*.py"):
    try:
        py_compile.compile(str(p), doraise=True)
    except Exception as e:
        errors.append((str(p.relative_to(ROOT)), str(e)))

if errors:
    for err in errors:
        print("COMPILE FAIL", err)
    raise SystemExit(1)

from aos.core.bootstrap import boot
from aos.utils.self_test import run_self_tests, summary

boot()

print("SELF TEST")
rows = run_self_tests()
for r in rows:
    print(f"[{r['status']}] {r['test']}: {r['message']}")
s = summary(rows)
if s["fail"]:
    raise SystemExit(1)

print("RUNTIME PAGE SMOKE")
try:
    from aos.utils.runtime_smoke import run_runtime_smoke
    page_rows = run_runtime_smoke()
    for r in page_rows:
        print(f"[{r['status']}] {r['page']}: {r['message']}")
    if any(r["status"] == "FAIL" for r in page_rows):
        raise SystemExit(1)
except ModuleNotFoundError as e:
    print(f"SKIPPED runtime page smoke: missing dependency {e}. Run Install_AOS.bat first for full verification.")

print("VALIDATION PASSED")
