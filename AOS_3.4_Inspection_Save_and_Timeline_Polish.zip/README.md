# AOS 3.4 — Inspection Save & Timeline Polish

This release fixes the inspection-completion workflow and improves history readability.

## Fixed

- Removed confusing draft-focused language from the visible workflow.
- Finish Inspection now gives plain-English confirmation.
- The user sees “Inspection recorded” rather than internal draft terminology.
- The workflow now returns to the Colony Workspace after a successful finish.
- History/timeline cards now start with the date.
- Each inspection detail appears on its own line/paragraph for readability.
- Timeline entries are latest first.
- Removed the separate Review Inspection decision from the main workflow.

## Note

Internally AOS may still use the existing staged-inspection service for safety, but the user-facing language now treats the completed action as an inspection being recorded.
