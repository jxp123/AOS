# AOS 3.2 — Inspection Workspace

## User feedback addressed

- History layout should be improved.
- History should be organised by inspection date, latest on top.
- Inspect button should record an inspection, not only show inspection focus.

## Resolution

- Added timeline-card history view.
- Added Inspection Workspace.
- Added Start Inspection action.
- Added Finish Inspection action that stages a draft.
- Added consistency warnings and review output.
