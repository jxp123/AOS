# AOS 2.4 — Inspection Experience

## Added
- Inspection session plan.
- Adaptive checklist integration.
- Consistency warning review.
- Evidence quality scoring and field recommendation output.
