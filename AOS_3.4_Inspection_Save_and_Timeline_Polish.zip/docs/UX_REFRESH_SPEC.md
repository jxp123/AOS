# AOS v10.2 UX Refresh

## Core improvements
- Single page heading
- Collapsible 'About this page'
- Purpose, logic and outcomes guidance
- Sticky action bar
- KPI cards
- Progressive disclosure
- Reduced scrolling
- WCAG accessibility improvements
- Responsive layouts
