# AOS 2.3 — Colony Workspace

## Added
- Colony Workspace v2 engine.
- Unified colony summary.
- Risk, confidence, trend and focus data merged for each colony.
