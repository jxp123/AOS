# AOS v11.0 Professional Edition

## Goal
Make AOS feel like a coherent professional product rather than a collection of modules.

## Included
- Professional application shell.
- Persistent left navigation.
- Command palette framework.
- Professional Home page.
- Reduced duplicate headings through the new design system.
- Right-hand assistant/help panel.
- Responsive shell layout.
- Clearer daily action and risk presentation.

## UX principles
- One clear title per screen.
- Guidance available on demand.
- Key actions visible early.
- Navigation remains stable.
- Data-heavy views remain available but are secondary to decision views.
