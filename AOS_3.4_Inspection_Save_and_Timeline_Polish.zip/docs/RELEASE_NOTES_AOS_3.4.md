# AOS 3.4 — Inspection Save & Timeline Polish

## User feedback addressed

- History needed clearer date-first layout.
- Each inspection needed separate paragraphs/lines.
- It was unclear whether Finish Inspection saved anything.
- Draft terminology was confusing.
- The next step after saving was unclear.

## Resolution

- Timeline cards now render date first.
- Details are split into separate lines.
- Finish Inspection is now the single primary action.
- Plain-English success/failure messages replace internal draft language.
- Successful finish returns to Colony Workspace.
