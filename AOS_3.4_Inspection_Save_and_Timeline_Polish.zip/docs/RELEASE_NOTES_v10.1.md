# AOS v10.1 — AOS X Data Guardian Experience Pack

## Added
- AOS X unified page.
- Data Guardian.
- Backup verification.
- Portable export.
- Rollback/restore workflow.
- Guardian batch launcher.
