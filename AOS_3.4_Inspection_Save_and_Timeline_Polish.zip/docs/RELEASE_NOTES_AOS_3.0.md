# AOS 3.0 — Desktop Framework

## User-reported problems addressed

- Inspector not visibly on the right.
- Select appeared to do nothing.
- Mission Control appeared too far down.
- Quick actions appeared too low.
- Colony Workspace opened with tables first.
- Data sometimes did not appear.

## Implementation response

- Rebuilt root app as fixed-height viewport.
- Three-pane grid is now permanent.
- Removed responsive rule that pushed Inspector below the page.
- Added repository fallback for colony cards.
- Moved actions and summaries above detailed tables.
