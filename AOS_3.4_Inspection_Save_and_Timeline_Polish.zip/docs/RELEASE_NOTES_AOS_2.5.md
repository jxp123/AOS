# AOS 2.5 — Analytics & Explainable AI

## Added
- Explainable recommendation engine.
- Confidence scores.
- Evidence and uncertainty lists.
- Explanation records for all colonies.
