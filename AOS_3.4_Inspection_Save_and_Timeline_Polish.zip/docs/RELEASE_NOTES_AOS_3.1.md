# AOS 3.1 — Desktop Framework Layout Fix

## User-reported problem

Menu and Inspector were not visible in the fixed three-column layout. Mission Control appeared as a normal full-page screen.

## Cause

Dynamic content containers were instantiated before the desktop shell, so NiceGUI rendered them outside the shell.

## Fix

Dynamic content containers are now created inside:
- left navigation pane
- centre workspace pane
- right Inspector pane
