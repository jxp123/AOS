# AOS v12.0 Desktop Workspace Edition

## Design validation

This release is optimised for PC desktop use, especially 1920×1080 and larger.

## Key changes

- Stable three-column desktop layout:
  - left: fixed navigation
  - centre: main workspace
  - right: contextual inspector
- Command palette removed from the visible page.
- Search moved to the top bar.
- Home button always opens Home.
- Digital Twin button opens the Home/Digital Twin board.
- Planning, Analysis and Inventory buttons open visible workspaces.
- Open buttons open colony workspaces.
- Select buttons update the right inspector.
- Visible feedback box confirms what just happened after each click.
- Colour-blind-safe design:
  - status is shown by text and symbols, not colour alone;
  - blue/orange/red palette with labels;
  - symbols: square/triangle/circle/diamond.

## Interaction rules

- If a button says Open, it opens a workspace.
- If a button says Select, it updates the inspector and confirms the selection.
- Navigation is persistent and does not move.
- Main workspace changes are visible immediately.
- Inspector changes are visible immediately.
