# AOS 3.3 — Inspection Form Restore

## User-reported issue

The Inspect button opened an Inspection Workspace title, but the inspection form and recording logic were missing.

## Cause

The previous implementation mixed dynamic containers and rendered part of the inspection workflow outside the centre workspace lifecycle.

## Fix

The entire inspection form is now rendered directly inside the centre workspace after the workspace header is created.
