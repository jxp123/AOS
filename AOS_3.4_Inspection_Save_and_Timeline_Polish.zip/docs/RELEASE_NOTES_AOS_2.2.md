# AOS 2.2 — Mission Control

## Added
- Mission Control engine.
- Four-lane board data:
  - Do Today
  - Watch Closely
  - Healthy
  - Upcoming
- Integrated briefing, jobs and equipment checklist data.
