# AOS 2.1 — Desktop Shell

## Implemented
- Desktop shell retained as application default.
- Stable left navigation.
- Persistent right Inspector.
- Search in top bar.
- Visible action feedback.
- Colour-blind-safe symbols and labels.
- Home opens Mission Control.

## Validation expectation
Use this as the base for all AOS 2.x releases.
