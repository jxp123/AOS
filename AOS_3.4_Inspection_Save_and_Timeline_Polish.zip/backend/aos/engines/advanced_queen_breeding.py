from aos.services.repository import Repository
from aos.engines.breeding_engine import breeding_studio_summary

def queen_family_tree():
    queens = Repository().list_queens()
    return [{"queen":q.get("code",""), "line":q.get("line",""), "source":q.get("source",""), "current_colony":q.get("current_colony",""), "daughters":"record daughters here"} for q in queens]

def breeder_ranking():
    return breeding_studio_summary().get("scores", [])

def mating_records_template():
    return [
        {"record":"Mating nuc", "status":"Framework"},
        {"record":"Drone line", "status":"Framework"},
        {"record":"Daughter queen tracking", "status":"Framework"},
        {"record":"Overwintering success", "status":"Data-driven once recorded"},
    ]
