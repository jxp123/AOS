from aos.services.repository import Repository

def _n(v):
    try: return float(v or 0)
    except Exception: return 0.0

def colony_analytics():
    repo = Repository()
    rows = []
    for c in repo.list_apiary_entities(True):
        inspections = [i for i in repo.list_inspections() if i.get("colony") == c["code"]]
        brood = [_n(i.get("brood_frames")) for i in inspections if _n(i.get("brood_frames")) > 0]
        stores = [_n(i.get("stores_frames")) for i in inspections if _n(i.get("stores_frames")) > 0]
        rows.append({
            "code": c["code"],
            "inspections": len(inspections),
            "avg_brood": round(sum(brood)/len(brood), 1) if brood else 0,
            "avg_stores": round(sum(stores)/len(stores), 1) if stores else 0,
            "queen_cell_events": len([i for i in inspections if _n(i.get("queen_cells")) > 0]),
            "latest": inspections[0].get("date","Never") if inspections else "Never",
        })
    rows.sort(key=lambda r: r["avg_brood"], reverse=True)
    return rows

def apiary_metrics():
    rows = colony_analytics()
    return {
        "colonies": len(rows),
        "total_inspections": sum(r["inspections"] for r in rows),
        "queen_cell_events": sum(r["queen_cell_events"] for r in rows),
        "best_brood": rows[0]["code"] if rows else "",
        "rows": rows,
    }
