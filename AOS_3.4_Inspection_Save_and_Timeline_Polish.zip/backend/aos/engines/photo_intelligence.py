from datetime import datetime
from pathlib import Path
from aos.core.settings import ROOT_DIR
PHOTO_DIR = ROOT_DIR / "photos"

def ensure_photo_dir():
    PHOTO_DIR.mkdir(exist_ok=True)
    return PHOTO_DIR

def photo_index():
    ensure_photo_dir()
    rows = []
    for p in PHOTO_DIR.glob("*"):
        if p.suffix.lower() in [".jpg",".jpeg",".png",".webp"]:
            rows.append({"filename": p.name, "path": str(p), "size_bytes": p.stat().st_size, "modified": datetime.fromtimestamp(p.stat().st_mtime).isoformat(timespec="seconds"), "tags": "untagged"})
    return rows

def analysis_capabilities():
    return [
        {"capability":"Photo storage", "status":"Active"},
        {"capability":"Manual tagging", "status":"Framework"},
        {"capability":"Brood pattern AI", "status":"Future model required"},
        {"capability":"Queen-cell detection", "status":"Future model required"},
        {"capability":"Disease visual triage", "status":"Future model required"},
    ]
