from aos.engines.ai_apiary_manager import answer_query, daily_ai_briefing
from aos.engines.intelligence_platform import intelligence_summary
from aos.engines.operations_planner import upcoming_jobs
from aos.engines.inventory_manager import inventory_rows

def morning_briefing():
    intel = intelligence_summary()
    jobs = upcoming_jobs()
    inventory = inventory_rows()
    return {
        "summary": f"{intel['high_risk']} high-risk colonies. {len(jobs)} upcoming jobs. Inventory review available.",
        "top_risks": intel["risks"][:8],
        "jobs": jobs[:10],
        "inventory": inventory[:10],
        "recommended_prompt": "What should I do this weekend?"
    }

def unified_answer(prompt):
    if "weekend" in (prompt or "").lower():
        b = morning_briefing()
        lines = [b["summary"], "Jobs:"]
        lines += [f"{j['due']} — {j['colony']}: {j['job']} ({j['priority']})" for j in b["jobs"]]
        return "\n".join(lines)
    return answer_query(prompt)
