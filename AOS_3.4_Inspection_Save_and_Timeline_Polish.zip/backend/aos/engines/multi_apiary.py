from aos.services.repository import Repository

def sites():
    return [{"site_code":"MAIN", "name":"Main Apiary", "colonies":len(Repository().list_apiary_entities(True)), "status":"Active"}]

def cross_apiary_summary():
    return {"sites":len(sites()), "total_colonies":sum(s["colonies"] for s in sites()), "notes":"Multi-apiary data model foundation is active."}
