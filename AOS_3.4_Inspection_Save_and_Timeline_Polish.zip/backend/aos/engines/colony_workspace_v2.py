from aos.engines.digital_twin import colony_workspace, confidence_meter, trend_rows, inspection_focus
from aos.engines.intelligence_platform import predictive_risk_rows

def full_colony_workspace(code):
    data = colony_workspace(code)
    risks = {r["code"]: r for r in predictive_risk_rows()}
    data["risk"] = risks.get(code, {})
    data["confidence"] = confidence_meter(code)
    data["trends"] = trend_rows(code)
    data["focus"] = inspection_focus(code)
    return data

def workspace_summary(code):
    data = full_colony_workspace(code)
    colony = data.get("colony") or {}
    card = data.get("card") or {}
    risk = data.get("risk") or {}
    return {
        "code": code,
        "name": colony.get("name", ""),
        "health": card.get("health", 0),
        "status": card.get("status_badge", ""),
        "confidence": data.get("confidence", {}).get("score", 0),
        "swarm": risk.get("swarm_prediction", 0),
        "queen_failure": risk.get("queen_failure_prediction", 0),
        "starvation": risk.get("starvation_prediction", 0),
        "focus": " ".join(data.get("focus", [])),
    }
