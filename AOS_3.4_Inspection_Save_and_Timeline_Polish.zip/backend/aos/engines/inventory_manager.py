from aos.services.repository import Repository

def inventory_rows():
    equipment = Repository().list_equipment()
    rows = [{"item":e.get("code",""), "type":e.get("type",""), "location":e.get("current_location",""), "status":e.get("status",""), "reorder":"Review"} for e in equipment]
    rows += [
        {"item":"Sugar", "type":"Consumable", "location":"Stores", "status":"Unknown", "reorder":"Set stock level"},
        {"item":"Frames", "type":"Consumable", "location":"Stores", "status":"Unknown", "reorder":"Set stock level"},
        {"item":"Varroa treatment", "type":"Treatment", "location":"Stores", "status":"Unknown", "reorder":"Check expiry"},
    ]
    return rows
