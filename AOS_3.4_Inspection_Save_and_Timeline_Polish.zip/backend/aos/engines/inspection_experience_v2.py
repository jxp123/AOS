from datetime import date
from aos.engines.inspection_assistant import adaptive_checklist, consistency_warnings
from aos.services.field_inspection_service import FieldInspectionService

def inspection_session_plan(code):
    return {
        "code": code,
        "date": str(date.today()),
        "checklist": adaptive_checklist(code),
        "target_time": "Under 2 minutes for a routine inspection",
        "capture_modes": ["large controls", "minimal typing", "notes", "photos framework"],
    }

def review_inspection_payload(payload):
    warnings = consistency_warnings(payload)
    quality = FieldInspectionService().inspection_quality(payload)
    recommendation = FieldInspectionService().field_recommendation(payload)
    return {
        "warnings": warnings,
        "quality": quality,
        "recommendation": recommendation,
        "can_stage": True,
    }
