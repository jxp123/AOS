def finance_categories():
    return [
        {"category":"Equipment", "income":0, "expenses":0, "status":"Ready for entry"},
        {"category":"Queens", "income":0, "expenses":0, "status":"Ready for entry"},
        {"category":"Feed", "income":0, "expenses":0, "status":"Ready for entry"},
        {"category":"Honey sales", "income":0, "expenses":0, "status":"Ready for entry"},
    ]

def finance_summary():
    rows = finance_categories()
    return {"income":sum(r["income"] for r in rows), "expenses":sum(r["expenses"] for r in rows), "profit":sum(r["income"]-r["expenses"] for r in rows), "rows":rows}
