from aos.engines.intelligence_platform import predictive_risk_rows

def explain_recommendation(code):
    risk = next((r for r in predictive_risk_rows() if r["code"] == code), None)
    if not risk:
        return {"code": code, "recommendation": "Monitor", "confidence": 30, "evidence": ["Insufficient data"], "uncertainty": ["No current risk record"]}
    values = [
        ("Swarm", risk.get("swarm_prediction", 0)),
        ("Queen failure", risk.get("queen_failure_prediction", 0)),
        ("Starvation", risk.get("starvation_prediction", 0)),
        ("Disease", risk.get("disease_prediction", 0)),
    ]
    top = max(values, key=lambda x: x[1])
    confidence = min(95, max(35, top[1]))
    evidence = [
        f"{top[0]} risk is currently {top[1]}%.",
        f"Recommendation: {risk.get('recommendation','Monitor')}.",
        f"Colony memory: {risk.get('memory','No memory profile yet')}.",
    ]
    uncertainty = []
    if confidence < 60:
        uncertainty.append("Recommendation confidence is moderate because evidence is incomplete.")
    if not uncertainty:
        uncertainty.append("Evidence is sufficient for an operational recommendation.")
    return {
        "code": code,
        "recommendation": risk.get("recommendation", "Monitor"),
        "confidence": confidence,
        "evidence": evidence,
        "uncertainty": uncertainty,
    }

def explain_all():
    return [explain_recommendation(r["code"]) for r in predictive_risk_rows()]
