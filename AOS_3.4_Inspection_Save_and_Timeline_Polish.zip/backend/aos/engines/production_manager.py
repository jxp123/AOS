from aos.services.repository import Repository

def harvest_readiness():
    rows = []
    for c in Repository().list_apiary_entities(True):
        notes = (c.get("notes") or "").lower()
        score = 0
        if "super" in notes: score += 40
        if "honey" in notes: score += 30
        if c.get("type") == "Hive": score += 20
        rows.append({"code":c["code"], "name":c["name"], "readiness_score":min(100,score), "production_note":"Review supers and capping before harvest."})
    return sorted(rows, key=lambda r:r["readiness_score"], reverse=True)

def batch_templates():
    return [
        {"workflow":"Harvest batch", "status":"Ready", "fields":"date, source colonies, supers, extracted weight"},
        {"workflow":"Jar inventory", "status":"Ready", "fields":"jar size, quantity, batch, label"},
        {"workflow":"Yield report", "status":"Ready", "fields":"colony, weight, notes"},
    ]
