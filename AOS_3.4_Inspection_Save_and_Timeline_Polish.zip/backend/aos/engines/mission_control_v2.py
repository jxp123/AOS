from aos.engines.aos_x import aos_x_dashboard
from aos.engines.digital_twin import apiary_layout
from aos.engines.operations_planner import upcoming_jobs
from aos.engines.intelligence_platform import intelligence_summary
from aos.engines.inventory_manager import inventory_rows

def _status_key(card):
    badge = card.get("status_badge", "")
    health = int(card.get("health") or 0)
    if "Overdue" in badge or "No record" in badge or health < 50:
        return "do_today"
    if "Due" in badge or health < 75:
        return "watch"
    return "healthy"

def mission_control_board():
    layout = apiary_layout()
    cards = layout["hives"] + layout["nucs"] + layout["other"]
    lanes = {"do_today": [], "watch": [], "healthy": [], "upcoming": []}
    for c in cards:
        lanes[_status_key(c)].append(c)
    data = aos_x_dashboard()
    intel = intelligence_summary()
    jobs = upcoming_jobs()
    equipment = inventory_rows()[:8]
    return {
        "briefing": data.get("headline", ""),
        "high_risk": intel.get("high_risk", 0),
        "jobs": jobs,
        "equipment": equipment,
        "lanes": lanes,
        "counts": {k: len(v) for k, v in lanes.items()},
    }
