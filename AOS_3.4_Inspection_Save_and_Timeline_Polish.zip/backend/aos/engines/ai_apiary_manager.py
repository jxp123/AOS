from aos.engines.intelligence_platform import intelligence_summary
from aos.engines.analytics_trends import apiary_metrics
from aos.engines.feeding_treatment_engine import feeding_treatment_summary
from aos.engines.breeding_engine import breeding_studio_summary
from aos.services.repository import Repository

def answer_query(question):
    q = (question or "").lower()
    repo = Repository()
    if "inspect" in q or "today" in q:
        risks = intelligence_summary()["risks"][:8]
        return "Inspection priorities:\n" + "\n".join([f"{r['code']}: {r['recommendation']} | swarm {r['swarm_prediction']}%, queen {r['queen_failure_prediction']}%, starvation {r['starvation_prediction']}%" for r in risks])
    if "queen" in q:
        b = breeding_studio_summary()
        return f"Queen summary: {b['queen_count']} queens, {b['prime_candidates']} prime candidates, {b['possible_candidates']} possible candidates."
    if "feed" in q or "treatment" in q:
        f = feeding_treatment_summary()
        return f"Feeding/treatments: {f['feeding_count']} feeding records, {f['treatment_count']} treatment records, {f['follow_up_count']} follow-ups due."
    if "compare" in q:
        return "Use Colony Workspace or Analytics & Trends to compare brood, stores, queen-cell history and inspection frequency."
    m = apiary_metrics()
    return f"Apiary summary: {m['colonies']} colonies/nucs, {m['total_inspections']} inspections, {m['queen_cell_events']} queen-cell events. Best brood performer: {m['best_brood']}."

def daily_ai_briefing():
    s = intelligence_summary()
    return {
        "headline": f"{s['high_risk']} colonies currently need elevated attention.",
        "priorities": s["risks"][:5],
        "seasonal": s["seasonal"],
        "resources": s["resources"],
        "suggested_question": "Which colonies need inspecting today?"
    }
