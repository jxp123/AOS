from datetime import date, timedelta
from aos.engines.intelligence_platform import seasonal_planner
from aos.engines.operations_centre import colony_cards

def annual_plan():
    return [{"period":"Current month", "task":r["seasonal_task"], "status":r["status"]} for r in seasonal_planner()]

def upcoming_jobs():
    jobs = []
    for c in colony_cards():
        if c.get("status_badge","").startswith(("🔴","🟡")):
            jobs.append({"due":str(date.today()), "colony":c["code"], "job":"Inspection", "priority":c["status_badge"]})
    jobs.append({"due":str(date.today()+timedelta(days=7)), "colony":"Apiary", "job":"Review resources", "priority":"🟡 Planned"})
    return jobs
