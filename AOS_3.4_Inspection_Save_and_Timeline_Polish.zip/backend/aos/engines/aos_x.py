from aos.engines.ai_beekeeping_assistant import morning_briefing, unified_answer
from aos.engines.intelligence_platform import intelligence_summary
from aos.engines.operations_planner import upcoming_jobs
from aos.engines.inventory_manager import inventory_rows
from aos.engines.digital_twin import apiary_layout

def aos_x_dashboard():
    briefing = morning_briefing()
    intel = intelligence_summary()
    layout = apiary_layout()
    return {
        "headline": briefing["summary"],
        "top_risks": briefing["top_risks"],
        "jobs": upcoming_jobs(),
        "inventory": inventory_rows(),
        "hives": layout["hives"],
        "nucs": layout["nucs"],
        "high_risk": intel["high_risk"],
        "assistant_prompt": "What should I do this weekend?",
    }

def ask_aos_x(prompt):
    return unified_answer(prompt)
