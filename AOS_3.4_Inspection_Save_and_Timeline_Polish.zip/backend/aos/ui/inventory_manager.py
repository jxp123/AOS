from nicegui import ui
from aos.engines.inventory_manager import inventory_rows

def page():
    ui.label("Inventory Manager").classes("text-h5")
    ui.table(columns=[{"name":"item","label":"Item","field":"item"},{"name":"type","label":"Type","field":"type"},{"name":"location","label":"Location","field":"location"},{"name":"status","label":"Status","field":"status"},{"name":"reorder","label":"Reorder","field":"reorder"}], rows=inventory_rows(), row_key="item").classes("w-full")
