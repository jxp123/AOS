from nicegui import ui
from aos.engines.analytics_trends import apiary_metrics
from aos.engines.intelligence_platform import intelligence_summary
from aos.engines.feeding_treatment_engine import feeding_treatment_summary
from aos.engines.breeding_engine import breeding_studio_summary

def page():
    ui.label("Complete Apiary Manager").classes("text-h5")
    ui.label("Executive overview of colony, queen, risk, treatment and production readiness.").classes("text-subtitle1")
    a = apiary_metrics()
    i = intelligence_summary()
    f = feeding_treatment_summary()
    b = breeding_studio_summary()
    with ui.row():
        for title,value in [
            ("Colonies", a["colonies"]),
            ("Inspections", a["total_inspections"]),
            ("High-risk colonies", i["high_risk"]),
            ("Treatment follow-ups", f["follow_up_count"]),
            ("Prime queens", b["prime_candidates"]),
        ]:
            with ui.card():
                ui.label(title); ui.label(str(value)).classes("text-h5")
    ui.label("Management summary").classes("text-h6")
    with ui.card().classes("w-full"):
        ui.label("AOS is now structured as a full apiary-management platform: daily work, colony workspace, field operations, analytics, predictions and data safety.")
    ui.label("Top risks").classes("text-h6")
    ui.table(columns=[
        {"name":"code","label":"Code","field":"code"},
        {"name":"swarm_prediction","label":"Swarm","field":"swarm_prediction"},
        {"name":"queen_failure_prediction","label":"Queen Failure","field":"queen_failure_prediction"},
        {"name":"starvation_prediction","label":"Starvation","field":"starvation_prediction"},
        {"name":"recommendation","label":"Recommendation","field":"recommendation"},
    ], rows=i["risks"][:12], row_key="code").classes("w-full")
