from nicegui import ui
from aos.engines.intelligence_platform import predictive_risk_rows, resource_forecast, seasonal_planner

def page():
    ui.label("Predictive Engine").classes("text-h5")
    ui.label("Forward-looking colony risk, seasonal work and resource planning.").classes("text-subtitle1")
    ui.label("Predicted risks").classes("text-h6")
    ui.table(columns=[
        {"name":"code","label":"Code","field":"code"},
        {"name":"swarm_prediction","label":"Swarm","field":"swarm_prediction"},
        {"name":"queen_failure_prediction","label":"Queen Failure","field":"queen_failure_prediction"},
        {"name":"starvation_prediction","label":"Starvation","field":"starvation_prediction"},
        {"name":"disease_prediction","label":"Disease","field":"disease_prediction"},
        {"name":"recommendation","label":"Recommendation","field":"recommendation"},
    ], rows=predictive_risk_rows(), row_key="code").classes("w-full")
    ui.label("Seasonal planner").classes("text-h6")
    ui.table(columns=[{"name":"seasonal_task","label":"Task","field":"seasonal_task"},{"name":"status","label":"Status","field":"status"}], rows=seasonal_planner(), row_key="seasonal_task").classes("w-full")
    ui.label("Resources").classes("text-h6")
    ui.table(columns=[{"name":"resource","label":"Resource","field":"resource"},{"name":"forecast","label":"Forecast","field":"forecast"},{"name":"reason","label":"Reason","field":"reason"}], rows=resource_forecast(), row_key="resource").classes("w-full")
