from nicegui import ui
from aos.engines.production_manager import harvest_readiness, batch_templates

def page():
    ui.label("Production Manager").classes("text-h5")
    ui.label("Honey production, harvest readiness and batch-management foundation.").classes("text-subtitle1")
    ui.label("Harvest readiness").classes("text-h6")
    ui.table(columns=[{"name":"code","label":"Code","field":"code"},{"name":"name","label":"Name","field":"name"},{"name":"readiness_score","label":"Readiness","field":"readiness_score"},{"name":"production_note","label":"Note","field":"production_note"}], rows=harvest_readiness(), row_key="code").classes("w-full")
    ui.label("Production workflows").classes("text-h6")
    ui.table(columns=[{"name":"workflow","label":"Workflow","field":"workflow"},{"name":"status","label":"Status","field":"status"},{"name":"fields","label":"Fields","field":"fields"}], rows=batch_templates(), row_key="workflow").classes("w-full")
