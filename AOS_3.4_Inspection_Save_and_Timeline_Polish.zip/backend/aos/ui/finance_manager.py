from nicegui import ui
from aos.engines.finance_manager import finance_summary

def page():
    ui.label("Finance Manager").classes("text-h5")
    s = finance_summary()
    with ui.row():
        for title, value in [("Income",s["income"]),("Expenses",s["expenses"]),("Profit",s["profit"])]:
            with ui.card():
                ui.label(title); ui.label(str(value)).classes("text-h5")
    ui.table(columns=[{"name":"category","label":"Category","field":"category"},{"name":"income","label":"Income","field":"income"},{"name":"expenses","label":"Expenses","field":"expenses"},{"name":"status","label":"Status","field":"status"}], rows=s["rows"], row_key="category").classes("w-full")
