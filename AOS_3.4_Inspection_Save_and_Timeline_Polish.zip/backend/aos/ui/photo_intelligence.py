from nicegui import ui
from aos.engines.photo_intelligence import photo_index, analysis_capabilities, ensure_photo_dir

def page():
    ui.label("Photo Intelligence").classes("text-h5")
    ui.label("Foundation for inspection photos and future image analysis.").classes("text-subtitle1")
    ui.label(f"Photo folder: {ensure_photo_dir()}")
    ui.label("Capabilities").classes("text-h6")
    ui.table(columns=[{"name":"capability","label":"Capability","field":"capability"},{"name":"status","label":"Status","field":"status"}], rows=analysis_capabilities(), row_key="capability").classes("w-full")
    ui.label("Photo index").classes("text-h6")
    ui.table(columns=[{"name":"filename","label":"Filename","field":"filename"},{"name":"size_bytes","label":"Size","field":"size_bytes"},{"name":"modified","label":"Modified","field":"modified"},{"name":"tags","label":"Tags","field":"tags"}], rows=photo_index(), row_key="path").classes("w-full")
