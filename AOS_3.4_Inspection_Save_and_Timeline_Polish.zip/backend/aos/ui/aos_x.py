from nicegui import ui
from aos.engines.aos_x import aos_x_dashboard, ask_aos_x

def _card(title, value, detail=""):
    with ui.card().style("min-width:190px;"):
        ui.label(title).classes("text-subtitle2")
        ui.label(str(value)).classes("text-h5")
        if detail:
            ui.label(detail).classes("text-caption")

def page():
    ui.label("AOS X").classes("text-h4")
    ui.label("Experience pack: unified assistant, digital twin summary, jobs, inventory and Data Guardian readiness.").classes("text-subtitle1")

    data = aos_x_dashboard()
    with ui.card().classes("w-full"):
        ui.label("Morning briefing").classes("text-h6")
        ui.label(data["headline"])

    with ui.row():
        _card("High-risk colonies", data["high_risk"])
        _card("Jobs", len(data["jobs"]))
        _card("Inventory lines", len(data["inventory"]))
        _card("Hives", len(data["hives"]))
        _card("Nucs", len(data["nucs"]))

    ui.label("Top risks").classes("text-h6")
    ui.table(
        columns=[
            {"name":"code","label":"Code","field":"code"},
            {"name":"swarm_prediction","label":"Swarm","field":"swarm_prediction"},
            {"name":"queen_failure_prediction","label":"Queen Failure","field":"queen_failure_prediction"},
            {"name":"starvation_prediction","label":"Starvation","field":"starvation_prediction"},
            {"name":"recommendation","label":"Recommendation","field":"recommendation"},
        ],
        rows=data["top_risks"],
        row_key="code",
    ).classes("w-full")

    ui.label("Talk to AOS X").classes("text-h6")
    q = ui.textarea("Question", value=data["assistant_prompt"]).classes("w-full")
    out = ui.column().classes("w-full")

    def ask():
        out.clear()
        with out:
            ui.textarea(value=ask_aos_x(q.value)).props("readonly autogrow").classes("w-full")

    ui.button("Ask", on_click=ask)
    ask()
