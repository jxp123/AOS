from nicegui import ui
from aos.engines.operations_planner import annual_plan, upcoming_jobs

def page():
    ui.label("Operations Planner").classes("text-h5")
    ui.label("Annual planner, upcoming jobs and recurring operations foundation.").classes("text-subtitle1")
    ui.label("Upcoming jobs").classes("text-h6")
    ui.table(columns=[{"name":"due","label":"Due","field":"due"},{"name":"colony","label":"Colony","field":"colony"},{"name":"job","label":"Job","field":"job"},{"name":"priority","label":"Priority","field":"priority"}], rows=upcoming_jobs(), row_key="due").classes("w-full")
    ui.label("Annual plan").classes("text-h6")
    ui.table(columns=[{"name":"period","label":"Period","field":"period"},{"name":"task","label":"Task","field":"task"},{"name":"status","label":"Status","field":"status"}], rows=annual_plan(), row_key="task").classes("w-full")
