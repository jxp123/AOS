from nicegui import ui
from aos.engines.advanced_queen_breeding import queen_family_tree, breeder_ranking, mating_records_template

def page():
    ui.label("Advanced Queen Breeding").classes("text-h5")
    ui.label("Pedigree, daughter tracking and breeding-rank workspace.").classes("text-subtitle1")
    ui.label("Breeder ranking").classes("text-h6")
    ui.table(columns=[{"name":"queen_code","label":"Queen","field":"queen_code"},{"name":"line","label":"Line","field":"line"},{"name":"breeding_score","label":"Score","field":"breeding_score"},{"name":"recommendation","label":"Recommendation","field":"recommendation"}], rows=breeder_ranking(), row_key="queen_code").classes("w-full")
    ui.label("Family tree").classes("text-h6")
    ui.table(columns=[{"name":"queen","label":"Queen","field":"queen"},{"name":"line","label":"Line","field":"line"},{"name":"source","label":"Source","field":"source"},{"name":"current_colony","label":"Colony","field":"current_colony"},{"name":"daughters","label":"Daughters","field":"daughters"}], rows=queen_family_tree(), row_key="queen").classes("w-full")
    ui.label("Mating records").classes("text-h6")
    ui.table(columns=[{"name":"record","label":"Record","field":"record"},{"name":"status","label":"Status","field":"status"}], rows=mating_records_template(), row_key="record").classes("w-full")
