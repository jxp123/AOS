from nicegui import ui
from aos.engines.ai_beekeeping_assistant import morning_briefing, unified_answer

def page():
    ui.label("AI Beekeeping Assistant").classes("text-h5")
    ui.label("Unified v10 assistant: morning briefing, risks, jobs, inventory and natural-language query.").classes("text-subtitle1")
    b = morning_briefing()
    with ui.card().classes("w-full"):
        ui.label("Morning briefing").classes("text-h6")
        ui.label(b["summary"])
    ui.label("Top risks").classes("text-h6")
    ui.table(columns=[{"name":"code","label":"Code","field":"code"},{"name":"swarm_prediction","label":"Swarm","field":"swarm_prediction"},{"name":"queen_failure_prediction","label":"Queen Failure","field":"queen_failure_prediction"},{"name":"starvation_prediction","label":"Starvation","field":"starvation_prediction"},{"name":"recommendation","label":"Recommendation","field":"recommendation"}], rows=b["top_risks"], row_key="code").classes("w-full")
    q = ui.textarea("Ask AOS", value=b["recommended_prompt"]).classes("w-full")
    out = ui.column().classes("w-full")
    def ask():
        out.clear()
        with out:
            ui.textarea(value=unified_answer(q.value)).props("readonly autogrow").classes("w-full")
    ui.button("Ask Assistant", on_click=ask)
    ask()
