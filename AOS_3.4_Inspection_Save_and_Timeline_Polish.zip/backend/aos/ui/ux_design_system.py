from nicegui import ui
def page_header(title,purpose="",logic="",achieve=""):
    ui.label(title).classes("text-h4")
    with ui.expansion("About this page",icon="info").classes("w-full"):
        if purpose: ui.markdown("**Purpose**\n\n"+purpose)
        if logic: ui.markdown("**How it works**\n\n"+logic)
        if achieve: ui.markdown("**What you can achieve**\n\n"+achieve)
def action_bar(actions):
    with ui.row().classes("w-full"):
        for a in actions: ui.button(a)
def kpi_card(title,value):
    with ui.card().style("min-width:180px"):
        ui.label(title).classes("text-caption")
        ui.label(str(value)).classes("text-h5")
