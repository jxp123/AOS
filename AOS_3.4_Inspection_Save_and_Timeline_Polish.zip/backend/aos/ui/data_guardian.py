from nicegui import ui
from aos.services.data_guardian_service import DataGuardianService

def page():
    ui.label("Data Guardian").classes("text-h5")
    ui.label("Backup, verify, export and rollback protection before upgrades.").classes("text-subtitle1")

    service = DataGuardianService()
    result_holder = ui.column().classes("w-full")
    restore_holder = ui.column().classes("w-full")

    def run_guardian():
        result_holder.clear()
        package = service.create_guardian_package()
        with result_holder:
            ui.label(f"Overall: {package['overall']}").classes("text-h6")
            ui.table(
                columns=[
                    {"name":"step","label":"Step","field":"step"},
                    {"name":"status","label":"Status","field":"status"},
                    {"name":"detail","label":"Detail","field":"detail"},
                ],
                rows=package["results"],
                row_key="step",
            ).classes("w-full")
        refresh_backups()

    def refresh_backups():
        restore_holder.clear()
        with restore_holder:
            ui.label("Rollback candidates").classes("text-h6")
            table = ui.table(
                columns=[
                    {"name":"filename","label":"Filename","field":"filename"},
                    {"name":"size_bytes","label":"Size","field":"size_bytes"},
                    {"name":"modified","label":"Modified","field":"modified"},
                    {"name":"path","label":"Path","field":"path"},
                ],
                rows=service.rollback_candidates(),
                row_key="path",
                selection="single",
            ).classes("w-full")

            def restore_selected():
                if not table.selected:
                    ui.notify("Select a backup first", type="warning")
                    return
                try:
                    result = service.restore_backup(table.selected[0]["path"])
                    ui.notify("Restore completed", type="positive")
                    result_holder.clear()
                    with result_holder:
                        ui.label("Restore completed").classes("text-positive text-h6")
                        ui.label(f"Restored from: {result['restored_from']}")
                        ui.label(f"Safety backup: {result['safety_backup']}")
                except Exception as e:
                    ui.notify(str(e), type="negative")

            ui.button("Restore Selected Backup", color="red", on_click=restore_selected)

    ui.button("Create Guardian Package", on_click=run_guardian)
    result_holder
    refresh_backups()
