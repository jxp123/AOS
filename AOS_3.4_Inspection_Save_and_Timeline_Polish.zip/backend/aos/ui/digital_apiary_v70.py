from nicegui import ui
from aos.engines.digital_twin import apiary_layout

def page():
    ui.label("Digital Apiary").classes("text-h5")
    ui.label("Visual operational layout of the apiary. This release introduces saved layout placeholders and richer visual cards.").classes("text-subtitle1")
    layout = apiary_layout()
    for section in ["hives", "nucs", "other"]:
        ui.label(section.title()).classes("text-h6")
        with ui.row().classes("w-full"):
            for c in layout.get(section, []):
                with ui.card().style("width:240px; min-height:170px; border:2px solid #9ca3af;"):
                    ui.label(c["code"]).classes("text-h5")
                    ui.label(c.get("status_badge",""))
                    ui.label(f"Health: {c.get('health',0)}%")
                    ui.label(f"Queen: {c.get('queen') or '—'}")
                    ui.label(f"Supers / action: {c.get('next_action','')}")
                    ui.label("Photo/document slots: ready")
    ui.label("Future layout editor").classes("text-h6")
    ui.label("The next step is drag-and-drop positioning and saved apiary layouts.")
