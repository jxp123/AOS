from nicegui import ui
from aos.ui.ux_design_system import page_header, kpi_card
from aos.engines.aos_x import aos_x_dashboard
from aos.engines.intelligence_platform import intelligence_summary
from aos.engines.operations_planner import upcoming_jobs

def page():
    page_header(
        "Professional Home",
        purpose="A single polished starting point for daily apiary management.",
        logic="This page pulls together AOS X, intelligence, jobs, risks and inventory signals.",
        achieve="Decide what to inspect, what to prepare and where to go next without opening multiple screens."
    )

    data = aos_x_dashboard()
    intel = intelligence_summary()
    jobs = upcoming_jobs()

    with ui.row().classes("w-full"):
        kpi_card("High-risk colonies", intel["high_risk"])
        kpi_card("Today's jobs", len(jobs))
        kpi_card("Hives", len(data["hives"]))
        kpi_card("Nucs", len(data["nucs"]))
        kpi_card("Inventory lines", len(data["inventory"]))

    ui.label("Priority actions").classes("text-h6")
    ui.table(
        columns=[
            {"name":"due","label":"Due","field":"due"},
            {"name":"colony","label":"Colony","field":"colony"},
            {"name":"job","label":"Job","field":"job"},
            {"name":"priority","label":"Priority","field":"priority"},
        ],
        rows=jobs[:10],
        row_key="job",
    ).classes("w-full")

    ui.label("Top risks").classes("text-h6")
    ui.table(
        columns=[
            {"name":"code","label":"Code","field":"code"},
            {"name":"swarm_prediction","label":"Swarm","field":"swarm_prediction"},
            {"name":"queen_failure_prediction","label":"Queen Failure","field":"queen_failure_prediction"},
            {"name":"starvation_prediction","label":"Starvation","field":"starvation_prediction"},
            {"name":"recommendation","label":"Recommendation","field":"recommendation"},
        ],
        rows=data["top_risks"],
        row_key="code",
    ).classes("w-full")
