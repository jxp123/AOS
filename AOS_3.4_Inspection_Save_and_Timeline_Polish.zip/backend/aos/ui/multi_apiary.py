from nicegui import ui
from aos.engines.multi_apiary import sites, cross_apiary_summary

def page():
    ui.label("Multi-Apiary").classes("text-h5")
    s = cross_apiary_summary()
    with ui.card():
        ui.label(f"Sites: {s['sites']} | Colonies: {s['total_colonies']}")
    ui.table(columns=[{"name":"site_code","label":"Site","field":"site_code"},{"name":"name","label":"Name","field":"name"},{"name":"colonies","label":"Colonies","field":"colonies"},{"name":"status","label":"Status","field":"status"}], rows=sites(), row_key="site_code").classes("w-full")
