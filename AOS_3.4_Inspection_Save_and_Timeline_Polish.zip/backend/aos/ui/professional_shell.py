from nicegui import ui
from aos.core.settings import APP_VERSION
import importlib
import traceback

PROFESSIONAL_NAV = [
    ("🏠", "Home", "aos.ui.professional_home", "page"),
    ("📍", "Today's Mission", "aos.ui.operations_centre", "page"),
    ("🐝", "Digital Twin", "aos.ui.digital_twin", "page"),
    ("🧠", "AOS X", "aos.ui.aos_x", "page"),
    ("📝", "Inspection Assistant", "aos.ui.inspection_assistant_v65", "page"),
    ("📊", "Analytics", "aos.ui.analytics_trends", "page"),
    ("👑", "Queens", "aos.ui.advanced_queen_breeding", "page"),
    ("🍯", "Production", "aos.ui.production_manager", "page"),
    ("📦", "Inventory", "aos.ui.inventory_manager", "page"),
    ("🛡", "Data Guardian", "aos.ui.data_guardian", "page"),
]

def render_professional_app():
    ui.add_head_html("""
    <style>
      body { background:#f4f6f8; }
      .pro-shell { display:flex; gap:14px; min-height:88vh; }
      .pro-nav { width:260px; background:#0f172a; color:white; border-radius:18px; padding:14px; }
      .pro-main { flex:1; background:white; border-radius:18px; padding:20px; overflow-x:auto; }
      .pro-assistant { width:320px; background:#f8fafc; border:1px solid #e2e8f0; border-radius:18px; padding:14px; }
      .pro-nav button { width:100%; justify-content:flex-start; margin-bottom:6px; }
      .pro-title { font-size:22px; font-weight:700; margin-bottom:8px; }
      .pro-chip { background:#e2e8f0; padding:5px 9px; border-radius:999px; font-size:12px; }
      @media(max-width:1200px){ .pro-shell{flex-direction:column;} .pro-nav,.pro-assistant{width:100%;} }
    </style>
    """)

    content = ui.column().classes("w-full")
    assistant = ui.column().classes("w-full")

    def load(title, module_name, fn_name):
        content.clear()
        with content:
            try:
                module = importlib.import_module(module_name)
                fn = getattr(module, fn_name)
                fn()
            except Exception as e:
                ui.label("Page error").classes("text-h5 text-negative")
                ui.label(f"{title} failed to load.").classes("text-negative")
                ui.textarea(value=traceback.format_exc()).props("readonly autogrow").classes("w-full")

    def command_search():
        assistant.clear()
        with assistant:
            ui.label("Command Palette").classes("text-h6")
            ui.label("Quick actions")
            for icon, title, module, fn in PROFESSIONAL_NAV[:8]:
                ui.button(f"{icon} {title}", on_click=lambda t=title,m=module,f=fn: load(t,m,f)).classes("w-full")

    with ui.row().classes("w-full").style("align-items:center; justify-content:space-between;"):
        ui.label("🐝 AOS Professional Edition").classes("text-h4")
        ui.label(f"v{APP_VERSION}").classes("pro-chip")

    with ui.element("div").classes("pro-shell"):
        with ui.column().classes("pro-nav"):
            ui.label("Navigation").classes("pro-title")
            for icon, title, module, fn in PROFESSIONAL_NAV:
                ui.button(f"{icon} {title}", on_click=lambda t=title,m=module,f=fn: load(t,m,f))
            ui.separator()
            ui.button("⌘ Command Palette", on_click=command_search)

        with ui.column().classes("pro-main"):
            content

        with ui.column().classes("pro-assistant"):
            ui.label("Assistant / Help").classes("text-h6")
            ui.label("Use the command palette or open a workspace. Guidance panels explain the logic on each page.")
            assistant

    load("Home", "aos.ui.professional_home", "page")
    command_search()
