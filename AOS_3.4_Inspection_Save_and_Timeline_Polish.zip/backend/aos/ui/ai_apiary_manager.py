from nicegui import ui
from aos.engines.ai_apiary_manager import answer_query, daily_ai_briefing

def page():
    ui.label("AI Apiary Manager").classes("text-h5")
    ui.label("Conversational manager using your AOS database and rule-based reasoning.").classes("text-subtitle1")
    b = daily_ai_briefing()
    with ui.card().classes("w-full"):
        ui.label("Morning briefing").classes("text-h6")
        ui.label(b["headline"])
    q = ui.textarea("Ask AOS", value=b["suggested_question"]).classes("w-full")
    out = ui.column().classes("w-full")
    def ask():
        out.clear()
        with out:
            ui.textarea(value=answer_query(q.value)).props("readonly autogrow").classes("w-full")
    with ui.row():
        ui.button("Ask", on_click=ask)
        ui.button("Inspection priorities", on_click=lambda: (q.set_value("Which colonies need inspecting today?"), ask()))
        ui.button("Queen summary", on_click=lambda: (q.set_value("Which queens are best?"), ask()))
        ui.button("Feeding/treatments", on_click=lambda: (q.set_value("What feeding or treatment follow-ups are due?"), ask()))
    ask()
