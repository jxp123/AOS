from nicegui import ui
from aos.core.settings import APP_VERSION
from aos.engines.aos_x import aos_x_dashboard, ask_aos_x
from aos.engines.digital_twin import apiary_layout, colony_workspace, inspection_focus, confidence_meter, trend_rows
from aos.engines.operations_planner import upcoming_jobs
from aos.engines.intelligence_platform import intelligence_summary
from aos.engines.inventory_manager import inventory_rows
from aos.services.repository import Repository
import traceback

# Desktop-first, colour-blind-safe palette:
# blue = information, orange = attention, red/purple = urgent, green used only with text labels.
STATUS = {
    "urgent": {"label": "Urgent", "bg": "#fef2f2", "border": "#991b1b", "text": "#7f1d1d", "symbol": "●"},
    "review": {"label": "Review", "bg": "#fff7ed", "border": "#c2410c", "text": "#7c2d12", "symbol": "▲"},
    "ok": {"label": "OK", "bg": "#eff6ff", "border": "#1d4ed8", "text": "#1e3a8a", "symbol": "■"},
    "info": {"label": "Info", "bg": "#f8fafc", "border": "#64748b", "text": "#334155", "symbol": "◆"},
}

def _status_key(card):
    badge = card.get("status_badge", "")
    if "Overdue" in badge or "No record" in badge or card.get("health", 100) < 50:
        return "urgent"
    if "Due" in badge or card.get("health", 100) < 75:
        return "review"
    return "ok"

def _status_style(key):
    s = STATUS[key]
    return f"background:{s['bg']}; border:2px solid {s['border']}; color:{s['text']};"

def render_desktop_workspace():
    ui.add_head_html("""
    <style>
      html, body { background:#eef2f7; overflow-x:hidden; }
      .dw-shell { display:grid; grid-template-columns: 245px minmax(720px, 1fr) 355px; gap:14px; min-height:88vh; }
      .dw-left { background:#111827; color:white; border-radius:16px; padding:14px; }
      .dw-main { background:#ffffff; border-radius:16px; padding:18px; overflow:auto; max-height:88vh; }
      .dw-right { background:#f8fafc; border:1px solid #cbd5e1; border-radius:16px; padding:14px; overflow:auto; max-height:88vh; }
      .dw-nav-btn { width:100%; justify-content:flex-start; margin:4px 0; }
      .dw-section { color:#bfdbfe; font-size:12px; text-transform:uppercase; letter-spacing:.06em; margin-top:14px; }
      .dw-card { border-radius:14px; padding:12px; margin:6px; min-width:205px; max-width:230px; cursor:pointer; }
      .dw-card:hover { outline:3px solid #2563eb; }
      .dw-kpi { min-width:160px; border:1px solid #cbd5e1; border-radius:12px; background:white; }
      .dw-action { min-width:120px; }
      .dw-topbar { display:flex; align-items:center; justify-content:space-between; gap:12px; margin-bottom:12px; }
      .dw-search { width:360px; }
      .dw-feedback { background:#dbeafe; border-left:5px solid #1d4ed8; padding:8px; border-radius:8px; }
      @media(max-width:1300px){
        .dw-shell { grid-template-columns: 220px 1fr; }
        .dw-right { grid-column:1 / span 2; max-height:none; }
      }
    </style>
    """)

    state = {"selected": None, "workspace": "Home", "last_action": "Ready."}

    main = ui.column().classes("w-full")
    inspector = ui.column().classes("w-full")

    def feedback(message):
        state["last_action"] = message
        refresh_inspector()

    def clear_main(title, explanation=""):
        main.clear()
        with main:
            with ui.row().classes("dw-topbar w-full"):
                ui.label(title).classes("text-h4")
                ui.label(f"v{APP_VERSION}").classes("text-caption")
            if explanation:
                with ui.expansion("About this workspace", icon="info").classes("w-full"):
                    ui.markdown(explanation)
            with ui.card().classes("dw-feedback w-full"):
                ui.label(state["last_action"])

    def refresh_inspector():
        inspector.clear()
        with inspector:
            ui.label("Inspector").classes("text-h5")
            ui.label(state["last_action"]).classes("text-caption")
            if not state["selected"]:
                ui.separator()
                ui.label("No colony selected").classes("text-h6")
                ui.label("Click a colony card in Home or Digital Twin. The inspector will show health, risks and quick actions here.")
                ui.separator()
                ui.label("Quick help").classes("text-h6")
                ui.label("Home always returns to the main dashboard. Every Open button updates either the main workspace or this inspector.")
                return

            code = state["selected"]
            data = colony_workspace(code)
            colony = data.get("colony") or {}
            card = data.get("card") or {}
            conf = confidence_meter(code)
            ui.label(f"{code} — {colony.get('name','')}").classes("text-h6")
            with ui.card().classes("w-full"):
                ui.label(f"Health: {card.get('health',0)}%")
                ui.label(f"Status: {card.get('status_badge','Unknown')}")
                ui.label(f"Confidence: {conf.get('score',0)}%")
                ui.label(f"Queen: {card.get('queen') or 'Not linked'}")
                ui.label(f"Latest: {card.get('latest_inspection','Never')}")
            ui.label("AI summary").classes("text-h6")
            with ui.card().classes("w-full"):
                for item in inspection_focus(code):
                    ui.label(f"• {item}")
            ui.label("Quick actions").classes("text-h6")
            with ui.row():
                ui.button("Open", on_click=lambda: open_colony_workspace(code)).classes("dw-action")
                ui.button("Inspect", on_click=lambda: open_inspection_context(code)).classes("dw-action")
            with ui.row():
                ui.button("History", on_click=lambda: open_colony_history(code)).classes("dw-action")
                ui.button("Trends", on_click=lambda: open_colony_trends(code)).classes("dw-action")

    def select_colony(code):
        state["selected"] = code
        feedback(f"Selected {code}. Inspector updated.")

    def colony_card(card):
        key = _status_key(card)
        s = STATUS[key]
        with ui.card().classes("dw-card").style(_status_style(key)):
            ui.label(f"{s['symbol']} {card['code']}").classes("text-h6")
            ui.label(f"Status: {s['label']} — {card.get('status_badge','')}")
            ui.label(f"Health: {card.get('health',0)}%")
            ui.label(f"Queen: {card.get('queen') or '—'}")
            ui.label(f"Next: {card.get('next_action','Monitor')}")
            with ui.row():
                ui.button("Select", on_click=lambda c=card["code"]: select_colony(c))
                ui.button("Open", on_click=lambda c=card["code"]: open_colony_workspace(c))

    def open_home():
        state["workspace"] = "Home"
        clear_main("Home", """
**Purpose**  
Desktop command centre for daily apiary management.

**Logic**  
This view combines Digital Twin status, top risks, planned jobs and the contextual inspector.

**What you can achieve**  
Select a colony, open its workspace, review today's jobs and decide the inspection route.
""")
        data = aos_x_dashboard()
        intel = intelligence_summary()
        jobs = upcoming_jobs()
        with main:
            with ui.row().classes("w-full"):
                for title, value in [
                    ("High-risk colonies", intel["high_risk"]),
                    ("Today's jobs", len(jobs)),
                    ("Hives", len(data["hives"])),
                    ("Nucs", len(data["nucs"])),
                    ("Inventory lines", len(data["inventory"])),
                ]:
                    with ui.card().classes("dw-kpi"):
                        ui.label(title).classes("text-caption")
                        ui.label(str(value)).classes("text-h5")
            ui.label("Digital Twin — click Select or Open").classes("text-h6")
            layout = apiary_layout()
            for label, rows in [("Hives", layout["hives"]), ("Nucs", layout["nucs"]), ("Other", layout["other"])]:
                ui.label(label).classes("text-subtitle1")
                with ui.row().classes("w-full"):
                    if not rows:
                        ui.label("None")
                    for c in rows:
                        colony_card(c)
            ui.label("Today's Jobs").classes("text-h6")
            ui.table(
                columns=[
                    {"name":"due","label":"Due","field":"due"},
                    {"name":"colony","label":"Colony","field":"colony"},
                    {"name":"job","label":"Job","field":"job"},
                    {"name":"priority","label":"Priority","field":"priority"},
                ],
                rows=jobs[:10],
                row_key="job",
            ).classes("w-full")
        feedback("Home opened.")

    def open_colony_workspace(code):
        state["selected"] = code
        clear_main(f"Colony Workspace — {code}", """
**Purpose**  
One desktop workspace for a selected colony.

**Logic**  
Pulls record, current card, confidence, timeline, inspections and trends into one view.

**What you can achieve**  
Review colony status, inspect history, check trends and decide next action.
""")
        data = colony_workspace(code)
        colony = data.get("colony") or {}
        card = data.get("card") or {}
        conf = data.get("confidence") or {}
        with main:
            with ui.row().classes("w-full"):
                for title, value in [
                    ("Health", f"{card.get('health',0)}%"),
                    ("Status", card.get("status_badge","Unknown")),
                    ("Confidence", f"{conf.get('score',0)}%"),
                    ("Latest inspection", card.get("latest_inspection","Never")),
                ]:
                    with ui.card().classes("dw-kpi"):
                        ui.label(title).classes("text-caption")
                        ui.label(str(value)).classes("text-h6")
            with ui.tabs().classes("w-full") as tabs:
                t1=ui.tab("Overview"); t2=ui.tab("Timeline"); t3=ui.tab("Inspections"); t4=ui.tab("Trends"); t5=ui.tab("Confidence")
            with ui.tab_panels(tabs, value=t1).classes("w-full"):
                with ui.tab_panel(t1):
                    ui.table(columns=[{"name":"field","label":"Field","field":"field"},{"name":"value","label":"Value","field":"value"}],
                             rows=[{"field":k,"value":str(v)} for k,v in colony.items()], row_key="field").classes("w-full")
                with ui.tab_panel(t2):
                    ui.table(columns=[{"name":"date","label":"Date","field":"date"},{"name":"type","label":"Type","field":"type"},{"name":"title","label":"Title","field":"title"},{"name":"details","label":"Details","field":"details"}],
                             rows=data.get("timeline",[]), row_key="title").classes("w-full")
                with ui.tab_panel(t3):
                    ui.table(columns=[{"name":"date","label":"Date","field":"date"},{"name":"queen_seen","label":"Queen","field":"queen_seen"},{"name":"eggs_seen","label":"Eggs","field":"eggs_seen"},{"name":"brood_frames","label":"Brood","field":"brood_frames"},{"name":"stores_frames","label":"Stores","field":"stores_frames"},{"name":"notes","label":"Notes","field":"notes"}],
                             rows=data.get("inspections",[]), row_key="id").classes("w-full")
                with ui.tab_panel(t4):
                    ui.table(columns=[{"name":"date","label":"Date","field":"date"},{"name":"brood","label":"Brood","field":"brood"},{"name":"stores","label":"Stores","field":"stores"},{"name":"bees","label":"Bees","field":"bees"},{"name":"queen_cells","label":"Q Cells","field":"queen_cells"}],
                             rows=trend_rows(code), row_key="date").classes("w-full")
                with ui.tab_panel(t5):
                    ui.label(f"Confidence score: {conf.get('score',0)}%").classes("text-h6")
                    with ui.row():
                        with ui.card():
                            ui.label("Evidence present")
                            for e in conf.get("evidence", []): ui.label(f"✓ {e}")
                        with ui.card():
                            ui.label("Missing / weaker evidence")
                            for e in conf.get("missing", []): ui.label(f"• {e}")
        feedback(f"Opened colony workspace for {code}.")

    def open_colony_history(code):
        state["selected"] = code
        data = colony_workspace(code)
        clear_main(f"History — {code}", "**Purpose**  \nReview the story of this colony without losing selection context.")
        with main:
            ui.table(columns=[{"name":"date","label":"Date","field":"date"},{"name":"type","label":"Type","field":"type"},{"name":"title","label":"Title","field":"title"},{"name":"details","label":"Details","field":"details"}],
                     rows=data.get("timeline",[]), row_key="title").classes("w-full")
        feedback(f"Opened history for {code}.")

    def open_colony_trends(code):
        state["selected"] = code
        clear_main(f"Trends — {code}", "**Purpose**  \nShow brood, stores, bee coverage and queen-cell trend data.")
        with main:
            ui.table(columns=[{"name":"date","label":"Date","field":"date"},{"name":"brood","label":"Brood","field":"brood"},{"name":"stores","label":"Stores","field":"stores"},{"name":"bees","label":"Bees","field":"bees"},{"name":"queen_cells","label":"Q Cells","field":"queen_cells"}],
                     rows=trend_rows(code), row_key="date").classes("w-full")
        feedback(f"Opened trends for {code}.")

    def open_inspection_context(code):
        state["selected"] = code
        clear_main(f"Inspection Context — {code}", """
**Purpose**  
Prepare for opening this colony.

**Logic**  
Shows the smart focus generated from latest inspection, confidence and risk evidence.

**What you can achieve**  
Know what to check before you open the hive.
""")
        with main:
            with ui.card().classes("w-full"):
                ui.label("Inspection focus").classes("text-h6")
                for item in inspection_focus(code):
                    ui.label(f"✓ {item}")
            ui.label("Use Field Inspection Mode or Inspection Assistant to record the inspection.").classes("text-subtitle1")
        feedback(f"Opened inspection context for {code}.")

    def open_planning():
        clear_main("Planning Workspace", """
**Purpose**  
See upcoming jobs and inspection work in one desktop view.

**Logic**  
Uses planner jobs, due inspections and seasonal work.

**What you can achieve**  
Plan the next apiary visit and prepare equipment.
""")
        with main:
            ui.table(columns=[{"name":"due","label":"Due","field":"due"},{"name":"colony","label":"Colony","field":"colony"},{"name":"job","label":"Job","field":"job"},{"name":"priority","label":"Priority","field":"priority"}],
                     rows=upcoming_jobs(), row_key="job").classes("w-full")
        feedback("Planning workspace opened.")

    def open_analysis():
        clear_main("Analysis Workspace", """
**Purpose**  
Review risk, performance and predictive intelligence.

**Logic**  
Uses the intelligence engine and AOS X summary.

**What you can achieve**  
Identify weak colonies, high-risk colonies and operational trends.
""")
        data = aos_x_dashboard()
        with main:
            ui.table(columns=[{"name":"code","label":"Code","field":"code"},{"name":"swarm_prediction","label":"Swarm","field":"swarm_prediction"},{"name":"queen_failure_prediction","label":"Queen Failure","field":"queen_failure_prediction"},{"name":"starvation_prediction","label":"Starvation","field":"starvation_prediction"},{"name":"recommendation","label":"Recommendation","field":"recommendation"}],
                     rows=data["top_risks"], row_key="code").classes("w-full")
        feedback("Analysis workspace opened.")

    def open_inventory():
        clear_main("Inventory Workspace", """
**Purpose**  
Desktop overview of equipment and consumables.

**Logic**  
Pulls known inventory lines and suggested review points.

**What you can achieve**  
Prepare resources before the next apiary visit.
""")
        with main:
            ui.table(columns=[{"name":"item","label":"Item","field":"item"},{"name":"type","label":"Type","field":"type"},{"name":"location","label":"Location","field":"location"},{"name":"status","label":"Status","field":"status"},{"name":"reorder","label":"Reorder","field":"reorder"}],
                     rows=inventory_rows(), row_key="item").classes("w-full")
        feedback("Inventory workspace opened.")

    def run_search(query):
        q = (query or "").strip().lower()
        if not q:
            feedback("Search is empty.")
            return
        repo = Repository()
        match = next((c for c in repo.list_apiary_entities(True) if q in c["code"].lower() or q in c["name"].lower()), None)
        if match:
            open_colony_workspace(match["code"])
        else:
            clear_main("Search Results")
            with main:
                ui.label(f"No direct colony match for: {query}")
                ui.label("Try a colony code such as H5, N92, Hive 15, or open Home.")
            feedback(f"Searched for '{query}'.")

    refresh_inspector()

    with ui.row().classes("w-full").style("align-items:center; justify-content:space-between; margin-bottom:10px;"):
        ui.label("🐝 AOS Desktop Workspace Edition").classes("text-h4")
        search = ui.input("Search colony, queen, action...").classes("dw-search")
        ui.button("Search", on_click=lambda: run_search(search.value))
        ui.label(f"v{APP_VERSION}")

    with ui.element("div").classes("dw-shell"):
        with ui.column().classes("dw-left"):
            ui.label("Workspaces").classes("text-h6")
            ui.button("Home", on_click=open_home).classes("dw-nav-btn")
            ui.button("Digital Twin", on_click=open_home).classes("dw-nav-btn")
            ui.button("Planning", on_click=open_planning).classes("dw-nav-btn")
            ui.button("Analysis", on_click=open_analysis).classes("dw-nav-btn")
            ui.button("Inventory", on_click=open_inventory).classes("dw-nav-btn")
            ui.separator()
            ui.label("Selected colony").classes("dw-section")
            ui.button("Open selected", on_click=lambda: open_colony_workspace(state["selected"]) if state["selected"] else feedback("No colony selected. Select a colony first.")).classes("dw-nav-btn")
            ui.button("Inspect selected", on_click=lambda: open_inspection_context(state["selected"]) if state["selected"] else feedback("No colony selected. Select a colony first.")).classes("dw-nav-btn")
            ui.button("History selected", on_click=lambda: open_colony_history(state["selected"]) if state["selected"] else feedback("No colony selected. Select a colony first.")).classes("dw-nav-btn")
            ui.separator()
            ui.label("Legend").classes("dw-section")
            for key, s in STATUS.items():
                ui.label(f"{s['symbol']} {s['label']}").style(f"color:{s['text']}; background:{s['bg']}; padding:4px; border-radius:6px;")

        with ui.column().classes("dw-main"):
            main

        with ui.column().classes("dw-right"):
            inspector

    open_home()
