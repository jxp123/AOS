from nicegui import ui
from aos.engines.analytics_trends import apiary_metrics

def page():
    ui.label("Analytics & Trends").classes("text-h5")
    m = apiary_metrics()
    with ui.row():
        for title,value in [("Colonies",m["colonies"]),("Inspections",m["total_inspections"]),("Queen cell events",m["queen_cell_events"]),("Best brood",m["best_brood"])]:
            with ui.card():
                ui.label(title); ui.label(str(value)).classes("text-h5")
    ui.table(columns=[
        {"name":"code","label":"Code","field":"code"},
        {"name":"inspections","label":"Inspections","field":"inspections"},
        {"name":"avg_brood","label":"Avg Brood","field":"avg_brood"},
        {"name":"avg_stores","label":"Avg Stores","field":"avg_stores"},
        {"name":"queen_cell_events","label":"Q Cell Events","field":"queen_cell_events"},
        {"name":"latest","label":"Latest","field":"latest"},
    ], rows=m["rows"], row_key="code").classes("w-full")
