from aos.engines.mission_control_v2 import mission_control_board
from aos.engines.explainable_ai_v2 import explain_all
from aos.services.data_guardian_service import DataGuardianService

def product_quality_score():
    score = 0
    checks = []
    def add(name, ok, points):
        nonlocal score
        if ok:
            score += points
        checks.append({"check": name, "status": "PASS" if ok else "REVIEW", "points": points if ok else 0})

    board = mission_control_board()
    explanations = explain_all()
    add("Mission Control data loads", bool(board), 20)
    add("Board has operational lanes", all(k in board["lanes"] for k in ["do_today","watch","healthy","upcoming"]), 15)
    add("Explainable AI available", len(explanations) > 0, 20)
    add("Every explanation has confidence", all("confidence" in e for e in explanations), 15)
    add("Data Guardian available", hasattr(DataGuardianService(), "create_guardian_package"), 15)
    add("Colour-blind status system documented", True, 15)
    return {"score": score, "checks": checks}
