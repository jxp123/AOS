from datetime import datetime
import shutil
import sqlite3
from pathlib import Path

from aos.core.settings import DB_PATH, BACKUP_DIR, EXPORT_DIR
from aos.services.data_portability_service import DataPortabilityService
from aos.services.system_health_service import SystemHealthService

class DataGuardianService:
    def _copy_db(self, prefix):
        BACKUP_DIR.mkdir(exist_ok=True)
        if not DB_PATH.exists():
            return None
        stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        target = BACKUP_DIR / f"{prefix}_{stamp}.db"
        shutil.copy2(DB_PATH, target)
        return target

    def verify_sqlite(self, db_path):
        if not db_path or not Path(db_path).exists():
            return {"status": "FAIL", "detail": "Database file missing"}
        try:
            with sqlite3.connect(db_path) as con:
                result = con.execute("PRAGMA integrity_check").fetchone()[0]
            return {"status": "PASS" if result == "ok" else "FAIL", "detail": result}
        except Exception as e:
            return {"status": "FAIL", "detail": str(e)}

    def create_guardian_package(self):
        results = []

        backup = self._copy_db("aos_guardian_backup")
        if backup:
            results.append({"step": "Create database backup", "status": "PASS", "detail": str(backup)})
            verify = self.verify_sqlite(backup)
            results.append({"step": "Verify backup integrity", "status": verify["status"], "detail": verify["detail"]})
        else:
            results.append({"step": "Create database backup", "status": "SKIP", "detail": "No database exists yet"})

        try:
            json_export = DataPortabilityService().export_json()
            results.append({"step": "Create portable JSON export", "status": "PASS", "detail": str(json_export)})
        except Exception as e:
            results.append({"step": "Create portable JSON export", "status": "FAIL", "detail": str(e)})

        try:
            health = SystemHealthService().health_report()
            results.append({"step": "System health check", "status": health.get("status", "UNKNOWN"), "detail": f"{len(health.get('checks', []))} checks generated"})
        except Exception as e:
            results.append({"step": "System health check", "status": "FAIL", "detail": str(e)})

        failed = [r for r in results if r["status"] == "FAIL"]
        overall = "PASS" if not failed else "FAIL"
        return {"overall": overall, "results": results}

    def rollback_candidates(self):
        BACKUP_DIR.mkdir(exist_ok=True)
        files = sorted(BACKUP_DIR.glob("*.db"), key=lambda p: p.stat().st_mtime, reverse=True)
        return [
            {
                "filename": p.name,
                "path": str(p),
                "size_bytes": p.stat().st_size,
                "modified": datetime.fromtimestamp(p.stat().st_mtime).isoformat(timespec="seconds"),
            }
            for p in files[:50]
        ]

    def restore_backup(self, backup_path):
        backup = Path(backup_path)
        if not backup.exists():
            raise FileNotFoundError(f"Backup not found: {backup}")
        verify = self.verify_sqlite(backup)
        if verify["status"] != "PASS":
            raise ValueError(f"Backup failed integrity check: {verify['detail']}")
        safety = self._copy_db("aos_before_restore")
        shutil.copy2(backup, DB_PATH)
        return {"restored_from": str(backup), "safety_backup": str(safety) if safety else ""}
