@echo off
cd /d "%~dp0"
if not exist .venv call Install_AOS.bat
call .venv\Scripts\activate.bat
set PYTHONPATH=%CD%\backend
python -c "from aos.core.bootstrap import boot; boot(); from aos.services.data_guardian_service import DataGuardianService; import json; print(json.dumps(DataGuardianService().create_guardian_package(), indent=2))"
echo.
echo Guardian package created. Check backups and exports folders.
pause
