# AOS v8.3 — Production Manager

Adds honey-production readiness, harvest workflow templates and batch-management foundation.
