# AOS 5.2 — Inspection Launch & Colony Edit

## Fixed

- Fixed `name '_focus_items' is not defined` error.
- Inspect from Mission Control and Colony Workspace should now open the adaptive inspection form.
- Replaced the old checkbox-style "Today's priorities" in Colony Workspace with a clearer "Inspection focus" explanation.
- Inspection focus is now informational; the inspection form asks the actual questions.
- Added Edit Colony from the action bar.
- You can now amend colony details such as name, type, equipment, objective and profile notes.

## Colony equipment editing

Open a colony, then click:

Edit Colony → update Equipment → Save Colony Details

The change is stored as a profile override and shown in the Colony Workspace and State Engine.
