# AOS v5.0.2 — Populated From Apiary Database

This release is based on the latest AOS v5 UI and has been pre-populated from the uploaded Excel workbook:

`Apiary_Management_Database_v3_0_2026-07-01_REDESIGNED 2.xlsx`

## Populated data

- Colonies and nucs
- Queens
- Inspection events
- Equipment actions
- Feeding action for Hive 12
- Jolanta breeding/placement plan
- Risks, actions, decisions, opportunities and timeline entries into Operations Log
- Honey production and nuc-pipeline information appended to colony notes

## Important

The populated database is:

`data/aos.db`

The original uploaded workbook is copied to:

`imports/Apiary_Management_Database_v3_0_2026-07-01_REDESIGNED 2.xlsx`

## Recommended first checks

1. Run `Install_AOS.bat`
2. Run `Run_AOS.bat`
3. Open:
   - Dashboard
   - Records → Colonies
   - Records → Inspections
   - Queen Breeding
   - Operations Log
   - System Health
