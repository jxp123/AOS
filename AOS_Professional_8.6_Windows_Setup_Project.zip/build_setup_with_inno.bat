@echo off
powershell -ExecutionPolicy Bypass -File "%~dp0build_setup_with_inno.ps1"
pause
