# AOS Professional 8.6 — Windows Setup Project

## Added

- Inno Setup project
- NSIS alternative installer script
- Build script for setup.exe
- RunAOS.bat launcher
- User data preservation documentation
- Installer build guide

## Notes

This environment cannot compile the Windows installer executable directly. Build the `.exe` on Windows with Inno Setup 6 using the included build script.
