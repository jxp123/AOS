$ErrorActionPreference = "Stop"

Write-Host "AOS Professional 8.6 Setup Builder" -ForegroundColor Cyan

$InnoPaths = @(
    "${env:ProgramFiles(x86)}\Inno Setup 6\ISCC.exe",
    "${env:ProgramFiles}\Inno Setup 6\ISCC.exe"
)

$ISCC = $null
foreach ($p in $InnoPaths) {
    if (Test-Path $p) {
        $ISCC = $p
        break
    }
}

if ($null -eq $ISCC) {
    Write-Host "Inno Setup 6 compiler was not found." -ForegroundColor Yellow
    Write-Host "Install it from https://jrsoftware.org/isinfo.php and re-run this script."
    exit 1
}

New-Item -ItemType Directory -Force -Path ".\dist" | Out-Null

& $ISCC ".\installer\inno\AOS_Professional_8.6_Setup.iss"

Write-Host "Build complete. Setup file should be in .\dist" -ForegroundColor Green
