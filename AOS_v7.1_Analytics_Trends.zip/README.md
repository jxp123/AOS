# AOS v7.1 — Analytics & Trends

Adds apiary metrics and colony performance analytics.
