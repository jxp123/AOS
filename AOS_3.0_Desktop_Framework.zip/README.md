# AOS 3.0 — Desktop Framework

This release replaces the stacked page layout with a true fixed desktop shell.

## Fixed

- The Inspector is fixed on the right and no longer appears below the page.
- Mission Control is immediately visible in the centre workspace.
- Only the centre workspace scrolls.
- Select updates the fixed Inspector and gives visible feedback.
- Open changes the centre workspace.
- Quick actions are at the top of the colony workspace.
- Data fallback added: if advanced engines fail, AOS still lists colonies from the repository.

## Desktop layout

- Top bar: search and version.
- Left pane: navigation.
- Centre pane: Mission Control / selected workspace.
- Right pane: Inspector.

## Colour-blind accessibility

Status uses symbol + label + colour:
- ● Urgent
- ▲ Review
- ■ OK
- ◆ Info
