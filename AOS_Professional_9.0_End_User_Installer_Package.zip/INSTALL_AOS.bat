@echo off
setlocal
title AOS Professional 9.0 Installer

echo.
echo ===============================================
echo        AOS Professional 9.0 Installer
echo ===============================================
echo.

set "AOS_DATA=%LOCALAPPDATA%\AOS"
set "AOS_APP=%LOCALAPPDATA%\AOS\Application"
set "AOS_DB=%AOS_DATA%\data\aos.db"
set "AOS_BACKUPS=%AOS_DATA%\backups"

echo Installing AOS to:
echo   %AOS_APP%
echo.
echo Your data will be stored permanently in:
echo   %AOS_DATA%
echo.

mkdir "%AOS_DATA%" 2>nul
mkdir "%AOS_DATA%\data" 2>nul
mkdir "%AOS_BACKUPS%" 2>nul
mkdir "%AOS_DATA%\exports" 2>nul
mkdir "%AOS_DATA%\config" 2>nul
mkdir "%AOS_DATA%\logs" 2>nul

for /f "tokens=1-4 delims=/ " %%a in ("%date%") do set today=%%d%%b%%c
for /f "tokens=1-3 delims=:." %%a in ("%time%") do set now=%%a%%b%%c
set now=%now: =0%

if exist "%AOS_DB%" (
    echo Existing AOS database found.
    echo Creating backup before upgrade...
    copy "%AOS_DB%" "%AOS_BACKUPS%\aos_%today%_%now%_before_9_0_upgrade.db" >nul
    echo Backup created.
) else (
    echo No existing database found. AOS will create one on first launch.
)

echo.
echo Copying application files...
if exist "%AOS_APP%" (
    rmdir /s /q "%AOS_APP%"
)
mkdir "%AOS_APP%"
xcopy "%~dp0application\*" "%AOS_APP%\" /E /I /Y >nul

echo Creating launcher...
(
echo @echo off
echo set AOS_HOME=%%LOCALAPPDATA%%\AOS
echo cd /d "%%LOCALAPPDATA%%\AOS\Application"
echo python backend\main.py
echo pause
) > "%AOS_DATA%\Run AOS.bat"

echo Creating desktop shortcut...
powershell -NoProfile -ExecutionPolicy Bypass -Command "$s=(New-Object -COM WScript.Shell).CreateShortcut([Environment]::GetFolderPath('Desktop') + '\AOS Professional.lnk'); $s.TargetPath='%AOS_DATA%\Run AOS.bat'; $s.WorkingDirectory='%AOS_APP%'; $s.Save()"

echo.
echo ===============================================
echo Installation complete.
echo.
echo Launch AOS using the desktop shortcut:
echo   AOS Professional
echo.
echo Data location:
echo   %AOS_DATA%
echo ===============================================
echo.
pause
endlocal
