# AOS v8.2 — Computer Vision Foundation

Adds photo library/index and future computer-vision framework. Photo storage works immediately; AI image diagnosis needs a future model.
