# AOS 4.1 — Commit Inspection & State Refresh

This release makes the Colony State Engine operational after inspection save.

## Fixed

- Finish Inspection now commits a completed inspection event immediately.
- Mission Control reads committed inspections through the Colony State Engine.
- A colony inspected today should now move from Overdue / Do Today to Current / Healthy, unless the inspection itself records a risk such as queen cells or very low stores.
- The older staged/draft service may still run in the background for compatibility, but it is no longer the only source for Mission Control.
- Colony cards now include an explanation field from the State Engine.

## Behaviour

When you click Finish Inspection:

1. The inspection is saved to the committed inspection table.
2. Colony State Engine recalculates the colony.
3. Mission Control opens.
4. The colony card should show the new state.
