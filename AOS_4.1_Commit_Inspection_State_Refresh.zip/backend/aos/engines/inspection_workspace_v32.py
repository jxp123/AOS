from datetime import date
from aos.services.repository import Repository
from aos.services.inspection_commit_service import InspectionCommitService

try:
    from aos.services.field_inspection_service import FieldInspectionService
except Exception:
    FieldInspectionService = None

try:
    from aos.engines.digital_twin import colony_workspace, inspection_focus, trend_rows
except Exception:
    colony_workspace = None
    inspection_focus = None
    trend_rows = None


def _safe_float(value):
    try:
        return float(value or 0)
    except Exception:
        return 0.0


def _safe_int(value):
    try:
        return int(value or 0)
    except Exception:
        return 0


def colony_id_for_code(code):
    repo = Repository()
    for c in repo.list_apiary_entities(True):
        if c.get("code") == code:
            return c.get("id")
    for c in repo.list_colonies():
        if c.get("code") == code:
            return c.get("id")
    return None


def inspection_priorities(code):
    try:
        if inspection_focus:
            items = inspection_focus(code)
            if items:
                return items
    except Exception:
        pass
    return [
        "Confirm queen status.",
        "Check eggs and brood pattern.",
        "Assess stores.",
        "Assess space and swarm risk.",
        "Record temperament and notes.",
    ]


def split_details(details):
    if not details:
        return []
    parts = []
    for chunk in str(details).replace("\n", " | ").split("|"):
        clean = chunk.strip()
        if clean:
            parts.append(clean)
    return parts


def timeline_items(code):
    rows = []
    data = {}
    try:
        if colony_workspace:
            data = colony_workspace(code) or {}
    except Exception:
        data = {}

    timeline = data.get("timeline") or []
    for row in timeline:
        rows.append({
            "date": row.get("date", "") or "Undated",
            "type": row.get("type", "Record"),
            "title": row.get("title", ""),
            "details": row.get("details", ""),
            "detail_lines": split_details(row.get("details", "")),
        })

    try:
        inspections = Repository().list_inspections()
        for i in inspections:
            if i.get("colony") == code:
                details = []
                for key, label in [
                    ("queen_seen", "Queen"),
                    ("eggs_seen", "Eggs"),
                    ("larvae_seen", "Larvae"),
                    ("brood_frames", "Brood"),
                    ("stores_frames", "Stores"),
                    ("bee_coverage_frames", "Bees"),
                    ("queen_cells", "Queen cells"),
                    ("temperament", "Temperament"),
                ]:
                    if i.get(key) not in [None, ""]:
                        details.append(f"{label}: {i.get(key)}")
                if i.get("notes"):
                    details.append(f"Notes: {i.get('notes')}")
                rows.append({
                    "date": i.get("date", "") or "Undated",
                    "type": "Inspection",
                    "title": f"Inspection — {code}",
                    "details": " | ".join(details),
                    "detail_lines": details,
                })
    except Exception:
        pass

    rows = sorted(rows, key=lambda r: str(r.get("date", "")), reverse=True)

    seen = set()
    clean = []
    for r in rows:
        k = (r["date"], r["type"], r["title"], r["details"])
        if k not in seen:
            clean.append(r)
            seen.add(k)
    return clean


def latest_summary(code):
    items = timeline_items(code)
    if items:
        return items[0]
    return {
        "date": "No history",
        "type": "No record",
        "title": "No timeline records yet",
        "details": "Start an inspection to create the first activity record.",
        "detail_lines": ["Start an inspection to create the first activity record."],
    }


def review_payload(payload):
    warnings = []
    if payload.get("eggs_seen") and not payload.get("queen_seen"):
        warnings.append("Eggs recorded without queen seen. This may be correct, but confirm before finishing.")
    if _safe_float(payload.get("brood_frames")) >= 6 and _safe_float(payload.get("stores_frames")) <= 1:
        warnings.append("Strong brood with low stores. Consider feed or adding a stores frame.")
    if _safe_int(payload.get("queen_cells")) > 0 and "swarm" not in (payload.get("notes") or "").lower():
        warnings.append("Queen cells recorded. Add swarm-control notes or action if relevant.")
    if not payload.get("queen_seen") and not payload.get("eggs_seen"):
        warnings.append("No queen and no eggs recorded. Queen status may need follow-up.")
    return warnings



def save_inspection_plain_english(code, payload):
    payload = dict(payload)
    payload["inspection_date"] = payload.get("inspection_date") or str(date.today())
    payload["queen_cells"] = _safe_int(payload.get("queen_cells"))
    payload["brood_frames"] = _safe_float(payload.get("brood_frames"))
    payload["stores_frames"] = _safe_float(payload.get("stores_frames"))
    payload["bee_coverage_frames"] = _safe_float(payload.get("bee_coverage_frames"))

    warnings = review_payload(payload)

    committed = InspectionCommitService().commit_inspection(code, payload)

    validation = None
    try:
        if FieldInspectionService is not None:
            payload_for_stage = dict(payload)
            payload_for_stage["colony_id"] = colony_id_for_code(code)
            draft_id, validation = FieldInspectionService().stage_field_inspection(payload_for_stage)
            committed["legacy_draft_id"] = draft_id
    except Exception:
        pass

    committed.update({
        "status": "SAVED",
        "saved": True,
        "title": "Inspection recorded",
        "message": f"Inspection for {code} has been recorded successfully.",
        "warnings": warnings,
        "validation": validation,
        "next_step": "Mission Control has been refreshed using the Colony State Engine.",
    })
    return committed


# Backwards-compatible name used by older screens
def stage_inspection(code, payload):
    return save_inspection_plain_english(code, payload)
