# AOS v3.3 — Inspection Workbench

## Main purpose

Make the 7-day inspection logic actionable.

## Added
- Inspection Workbench.
- Record External Check from queue.
- Stage Guided Draft from queue.
- Edit inspection notes.
- Delete inspection records.
- Workbench included in AI export and tests.
