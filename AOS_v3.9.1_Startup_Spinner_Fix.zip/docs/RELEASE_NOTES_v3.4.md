# AOS v3.4 — Daily Apiary Operations

## Fixed
- `NameError: name 't_workbench' is not defined`

## Added
- Daily Operations dashboard
- Smart alerts
- Inspection route
- Evidence scoring
- Apiary map/list
- Operations log
