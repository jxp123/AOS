# AOS v3.9 — Queen Breeding Studio

## Added
- Queen evaluations.
- Breeding score calculation.
- Candidate recommendations.
- Breeding plans.
- Breeding alerts.
- Export and test integration.
