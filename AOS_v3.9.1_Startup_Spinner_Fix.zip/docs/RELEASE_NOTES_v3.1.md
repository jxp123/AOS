# AOS v3.1 — Engineering Foundation

This is a new engineering baseline.

## Added
- Proper backend package structure
- Release validation script
- GitHub Actions scaffold
- Self-test tab
- Apiary Brain retained
- Operations retained
- 7-day inspection scheduler retained
