# AOS v3.1 Architecture

AOS now uses a layered backend:

- `core`: settings, baseline and bootstrap
- `db`: SQLAlchemy models/session
- `services`: repository and workflows
- `engines`: reasoning, scheduler and operations logic
- `ui`: NiceGUI pages
- `utils`: self-test/export tools

All future releases should build from this repository baseline.
