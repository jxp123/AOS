# AOS v3.8 — Database Unification and Stability

## Added
- System Health.
- Database Unification tab.
- Automatic startup backup.
- Manual backup.
- Transactional inspection save.
- Health checks and counts.
- Export/test integration.
