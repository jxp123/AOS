# AOS v3.6 — Stability Gate

## Purpose
Stabilise AOS before further feature work.

## Added
- Runtime page-smoke test.
- `Run_Verification.bat`.
- Stronger validation script.
- Tests page includes page-render checks.
