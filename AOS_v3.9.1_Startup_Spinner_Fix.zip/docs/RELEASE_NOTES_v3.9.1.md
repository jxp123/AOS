# AOS v3.9.1 — Startup Spinner Fix

## Fixed
- Startup spinner caused by eager rendering of all pages.
- Rebuilt shell to lazy-load pages.
- Added browser-visible page error handling.
- Added diagnostics route `/diag`.

## Added
- `Open_Diagnostics.bat`.
