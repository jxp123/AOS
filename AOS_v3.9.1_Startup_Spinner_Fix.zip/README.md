# AOS v3.9.1 — Startup Spinner Fix

## Fixed

- Replaced the eager tab shell with lazy navigation.
- AOS no longer renders every page at startup.
- Page-level errors now display inside the browser instead of leaving a permanent spinner.
- Added `/diag` diagnostics page.
- Added `Open_Diagnostics.bat`.

## Why

A permanent spinner with only `NiceGUI ready to go` in the log usually means the server is running but the browser is waiting on a heavy or failed initial render. This release loads only **Daily Operations** on startup and loads other pages only when clicked.

## Run

1. `Install_AOS.bat`
2. `Run_Verification.bat`
3. `Run_AOS.bat`

If the home page spins, run `Open_Diagnostics.bat`.
