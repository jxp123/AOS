from aos.db.session import session_scope
from aos.db.models import Inspection

class InspectionService:
    def delete(self, inspection_id):
        with session_scope() as s:
            obj = s.query(Inspection).get(inspection_id)
            if not obj:
                raise ValueError("Inspection not found")
            s.delete(obj)
            s.commit()

    def update_notes(self, inspection_id, notes):
        with session_scope() as s:
            obj = s.query(Inspection).get(inspection_id)
            if not obj:
                raise ValueError("Inspection not found")
            obj.notes = notes or ""
            s.commit()
