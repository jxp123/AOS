from aos.db.session import session_scope
from aos.db.models import QueenEvaluation, BreedingPlan
from aos.services.repository import Repository

class BreedingService:
    def list_evaluations(self):
        with session_scope() as s:
            return [
                {
                    "id": r.id,
                    "date": r.date,
                    "queen_code": r.queen_code,
                    "colony_code": r.colony_code,
                    "temperament": r.temperament,
                    "brood_pattern": r.brood_pattern,
                    "spring_build_up": r.spring_build_up,
                    "honey_performance": r.honey_performance,
                    "swarm_tendency": r.swarm_tendency,
                    "winter_survival": r.winter_survival,
                    "disease_resilience": r.disease_resilience,
                    "score": self.score_row(r),
                    "notes": r.notes or "",
                }
                for r in s.query(QueenEvaluation).order_by(QueenEvaluation.date.desc(), QueenEvaluation.id.desc()).limit(500).all()
            ]

    def add_evaluation(self, data):
        with session_scope() as s:
            s.add(QueenEvaluation(**data))
            s.commit()

    def delete_evaluation(self, record_id):
        with session_scope() as s:
            r = s.query(QueenEvaluation).get(record_id)
            if not r:
                raise ValueError("Queen evaluation not found")
            s.delete(r)
            s.commit()

    def list_plans(self):
        with session_scope() as s:
            return [
                {
                    "id": p.id,
                    "date": p.date,
                    "queen_code": p.queen_code,
                    "plan_type": p.plan_type,
                    "target_colonies": p.target_colonies,
                    "rationale": p.rationale or "",
                    "status": p.status,
                    "notes": p.notes or "",
                }
                for p in s.query(BreedingPlan).order_by(BreedingPlan.date.desc(), BreedingPlan.id.desc()).limit(300).all()
            ]

    def add_plan(self, data):
        with session_scope() as s:
            s.add(BreedingPlan(**data))
            s.commit()

    def delete_plan(self, plan_id):
        with session_scope() as s:
            p = s.query(BreedingPlan).get(plan_id)
            if not p:
                raise ValueError("Breeding plan not found")
            s.delete(p)
            s.commit()

    @staticmethod
    def score_row(r):
        # Lower swarm tendency is better, so invert it.
        values = [
            r.temperament,
            r.brood_pattern,
            r.spring_build_up,
            r.honey_performance,
            10 - r.swarm_tendency,
            r.winter_survival,
            r.disease_resilience,
        ]
        valid = [float(v or 0) for v in values]
        return round(sum(valid) / len(valid), 2) if valid else 0

    def queen_scores(self):
        evals = self.list_evaluations()
        by_queen = {}
        for e in evals:
            by_queen.setdefault(e["queen_code"], []).append(e)
        rows = []
        queens = {q["code"]: q for q in Repository().list_queens()}
        for queen_code, records in by_queen.items():
            avg = round(sum(r["score"] for r in records) / len(records), 2)
            q = queens.get(queen_code, {})
            rows.append({
                "queen_code": queen_code,
                "name": q.get("name", ""),
                "line": q.get("line", ""),
                "current_colony": q.get("current_colony", ""),
                "evaluations": len(records),
                "breeding_score": avg,
                "recommendation": self.recommendation(avg),
            })
        for q in queens.values():
            if q["code"] not in by_queen:
                rows.append({
                    "queen_code": q["code"],
                    "name": q.get("name", ""),
                    "line": q.get("line", ""),
                    "current_colony": q.get("current_colony", ""),
                    "evaluations": 0,
                    "breeding_score": 0,
                    "recommendation": "Insufficient data",
                })
        rows.sort(key=lambda r: r["breeding_score"], reverse=True)
        return rows

    @staticmethod
    def recommendation(score):
        if score >= 8:
            return "Prime breeding candidate"
        if score >= 6.5:
            return "Possible breeding candidate"
        if score >= 5:
            return "Observe further"
        if score > 0:
            return "Do not prioritise for breeding"
        return "Insufficient data"
