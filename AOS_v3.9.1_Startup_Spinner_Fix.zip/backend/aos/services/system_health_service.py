from pathlib import Path
from datetime import datetime
import shutil
import sqlite3

from aos.core.settings import DB_PATH, BACKUP_DIR, SCHEMA_VERSION
from aos.db.session import session_scope
from aos.db.models import Colony, Queen, Equipment, Inspection, AuditLog

try:
    from aos.db.models import WeatherObservation, GuidedInspectionDraft, FeedingRecord, TreatmentRecord
except Exception:
    WeatherObservation = None
    GuidedInspectionDraft = None
    FeedingRecord = None
    TreatmentRecord = None

class SystemHealthService:
    REQUIRED_TABLES = [
        "system_meta",
        "colonies",
        "queens",
        "equipment",
        "inspections",
        "guided_inspection_drafts",
        "weather_observations",
        "audit_log",
        "feeding_records",
        "treatment_records",
    ]

    def create_startup_backup(self, keep=20):
        BACKUP_DIR.mkdir(exist_ok=True)
        if not DB_PATH.exists():
            return {"status": "SKIPPED", "message": "No database found yet"}

        stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        target = BACKUP_DIR / f"aos_auto_backup_{stamp}.db"
        shutil.copy2(DB_PATH, target)

        backups = sorted(BACKUP_DIR.glob("aos_auto_backup_*.db"), key=lambda p: p.stat().st_mtime, reverse=True)
        for old in backups[keep:]:
            try:
                old.unlink()
            except Exception:
                pass

        return {"status": "PASS", "message": str(target)}

    def table_names(self):
        if not DB_PATH.exists():
            return []
        with sqlite3.connect(DB_PATH) as con:
            rows = con.execute("SELECT name FROM sqlite_master WHERE type='table'").fetchall()
        return sorted([r[0] for r in rows])

    def missing_tables(self):
        existing = set(self.table_names())
        return [t for t in self.REQUIRED_TABLES if t not in existing]

    def counts(self):
        with session_scope() as s:
            data = {
                "colonies": s.query(Colony).count(),
                "queens": s.query(Queen).count(),
                "equipment": s.query(Equipment).count(),
                "inspections": s.query(Inspection).count(),
                "audit_log": s.query(AuditLog).count(),
            }
            if WeatherObservation is not None:
                data["weather"] = s.query(WeatherObservation).count()
            if GuidedInspectionDraft is not None:
                data["guided_drafts"] = s.query(GuidedInspectionDraft).count()
            if FeedingRecord is not None:
                data["feeding_records"] = s.query(FeedingRecord).count()
            if TreatmentRecord is not None:
                data["treatment_records"] = s.query(TreatmentRecord).count()
            return data

    def latest_backup(self):
        BACKUP_DIR.mkdir(exist_ok=True)
        backups = sorted(BACKUP_DIR.glob("*.db"), key=lambda p: p.stat().st_mtime, reverse=True)
        if not backups:
            return ""
        return str(backups[0])

    def health_report(self):
        missing = self.missing_tables()
        size = DB_PATH.stat().st_size if DB_PATH.exists() else 0
        status = "PASS" if not missing and DB_PATH.exists() else "FAIL"
        checks = [
            {"check": "Database exists", "status": "PASS" if DB_PATH.exists() else "FAIL", "detail": str(DB_PATH)},
            {"check": "Schema version", "status": "INFO", "detail": SCHEMA_VERSION},
            {"check": "Missing tables", "status": "PASS" if not missing else "FAIL", "detail": ", ".join(missing) if missing else "None"},
            {"check": "Database size", "status": "INFO", "detail": f"{size} bytes"},
            {"check": "Latest backup", "status": "INFO", "detail": self.latest_backup() or "No backup found"},
        ]

        try:
            counts = self.counts()
            for key, value in counts.items():
                checks.append({"check": key.replace("_", " ").title(), "status": "INFO", "detail": str(value)})
        except Exception as e:
            checks.append({"check": "Counts", "status": "FAIL", "detail": str(e)})
            status = "FAIL"

        return {"status": status, "checks": checks}
