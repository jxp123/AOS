from aos.db.session import session_scope
from aos.db.models import AuditLog

class OperationsLogService:
    def list(self):
        with session_scope() as s:
            return [
                {"id": a.id, "date": a.date, "action": a.action, "details": a.details}
                for a in s.query(AuditLog).order_by(AuditLog.id.desc()).limit(300).all()
            ]
