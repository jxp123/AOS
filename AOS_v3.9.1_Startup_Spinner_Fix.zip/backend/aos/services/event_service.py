from datetime import datetime
from aos.db.session import session_scope
from aos.db.models import AuditLog, Colony, Inspection

class EventService:
    def log(self, action, details):
        with session_scope() as s:
            s.add(AuditLog(date=str(datetime.now().replace(microsecond=0)), action=action, details=details))
            s.commit()

    def save_inspection_transaction(self, payload):
        """Single transaction for inspection save + audit log.

        This is the first database-unification step: one save operation,
        one commit, one rollback boundary.
        """
        with session_scope() as s:
            colony = s.query(Colony).get(payload["colony_id"])
            if not colony:
                raise ValueError("Selected colony/nuc does not exist")

            inspection = Inspection(**payload)
            s.add(inspection)
            s.add(AuditLog(
                date=str(datetime.now().replace(microsecond=0)),
                action="INSPECTION_SAVED",
                details=f"{colony.code} inspection saved for {payload.get('date')}",
            ))
            s.commit()
            return inspection.id
