from datetime import datetime
from aos.db.session import session_scope
from aos.db.models import Colony, Queen, Equipment, Inspection, WeatherObservation, AuditLog
from aos.core.baseline import BASELINE_COLONIES, BASELINE_QUEENS, BASELINE_EQUIPMENT

class Repository:
    def audit(self, action, details):
        with session_scope() as s:
            s.add(AuditLog(date=str(datetime.now().replace(microsecond=0)), action=action, details=details)); s.commit()

    def list_colonies(self, active_only=False):
        with session_scope() as s:
            q=s.query(Colony)
            if active_only: q=q.filter(Colony.status=='Active')
            return [self._colony(c) for c in q.order_by(Colony.colony_type, Colony.code).all()]
    def list_apiary_entities(self, active_only=True): return self.list_colonies(active_only)
    def create_colony(self,data):
        with session_scope() as s:
            if s.query(Colony).filter_by(code=data['code']).first(): raise ValueError('Colony already exists')
            s.add(Colony(**data)); s.commit()
        self.audit('CREATE_COLONY',data['code'])
    def update_colony(self,code,data):
        with session_scope() as s:
            o=s.query(Colony).filter_by(code=code).first()
            if not o: raise ValueError('Colony not found')
            for k,v in data.items(): setattr(o,k,v)
            s.commit()
        self.audit('UPDATE_COLONY',code)
    def delete_colony(self,code):
        with session_scope() as s:
            o=s.query(Colony).filter_by(code=code).first()
            if not o: raise ValueError('Colony not found')
            s.delete(o); s.commit()
        self.audit('DELETE_COLONY',code)

    def list_queens(self):
        with session_scope() as s: return [self._queen(q) for q in s.query(Queen).order_by(Queen.code).all()]
    def create_queen(self,data):
        with session_scope() as s:
            if s.query(Queen).filter_by(code=data['code']).first(): raise ValueError('Queen already exists')
            s.add(Queen(**data)); s.commit()
        self.audit('CREATE_QUEEN',data['code'])
    def update_queen(self,code,data):
        with session_scope() as s:
            o=s.query(Queen).filter_by(code=code).first()
            if not o: raise ValueError('Queen not found')
            for k,v in data.items(): setattr(o,k,v)
            s.commit()
        self.audit('UPDATE_QUEEN',code)
    def delete_queen(self,code):
        with session_scope() as s:
            o=s.query(Queen).filter_by(code=code).first()
            if not o: raise ValueError('Queen not found')
            s.delete(o); s.commit()
        self.audit('DELETE_QUEEN',code)

    def list_equipment(self):
        with session_scope() as s: return [self._equipment(e) for e in s.query(Equipment).order_by(Equipment.code).all()]
    def create_equipment(self,data):
        with session_scope() as s:
            if s.query(Equipment).filter_by(code=data['code']).first(): raise ValueError('Equipment already exists')
            s.add(Equipment(**data)); s.commit()
        self.audit('CREATE_EQUIPMENT',data['code'])
    def update_equipment(self,code,data):
        with session_scope() as s:
            o=s.query(Equipment).filter_by(code=code).first()
            if not o: raise ValueError('Equipment not found')
            for k,v in data.items(): setattr(o,k,v)
            s.commit()
        self.audit('UPDATE_EQUIPMENT',code)
    def delete_equipment(self,code):
        with session_scope() as s:
            o=s.query(Equipment).filter_by(code=code).first()
            if not o: raise ValueError('Equipment not found')
            s.delete(o); s.commit()
        self.audit('DELETE_EQUIPMENT',code)

    def list_inspections(self):
        with session_scope() as s:
            return [{'id':i.id,'date':i.date,'colony':i.colony.code if i.colony else '', 'inspection_type':i.inspection_type,'queen_seen':'Yes' if i.queen_seen else 'No','eggs_seen':'Yes' if i.eggs_seen else 'No','larvae_seen':'Yes' if i.larvae_seen else 'No','queen_cells':i.queen_cells,'brood_frames':i.brood_frames,'stores_frames':i.stores_frames,'bee_coverage_frames':i.bee_coverage_frames,'temperament':i.temperament,'notes':i.notes or ''} for i in s.query(Inspection).order_by(Inspection.date.desc(),Inspection.id.desc()).limit(500).all()]
    def latest_inspection_by_colony(self):
        latest={}
        for i in self.list_inspections():
            if i['colony'] not in latest: latest[i['colony']]=i
        return latest
    def create_inspection(self,data):
        with session_scope() as s:
            c=s.query(Colony).get(data['colony_id'])
            if not c: raise ValueError('Selected colony/nuc does not exist')
            s.add(Inspection(**data)); s.commit(); code=c.code
        self.audit('CREATE_INSPECTION',code)

    def list_weather(self):
        with session_scope() as s:
            return [{'id':w.id,'date':w.date,'temperature_c':w.temperature_c,'wind':w.wind,'rain':w.rain,'forage_flow':w.forage_flow,'inspection_suitability':w.inspection_suitability,'notes':w.notes or ''} for w in s.query(WeatherObservation).order_by(WeatherObservation.date.desc(),WeatherObservation.id.desc()).limit(100).all()]
    def create_weather(self,data):
        with session_scope() as s: s.add(WeatherObservation(**data)); s.commit()
        self.audit('CREATE_WEATHER',data.get('date',''))

    def baseline_integrity(self):
        colonies={c['code'] for c in self.list_colonies()}; queens={q['code'] for q in self.list_queens()}; equipment={e['code'] for e in self.list_equipment()}
        return {'missing_colonies':[c for c in BASELINE_COLONIES if c[0] not in colonies],'missing_queens':[q for q in BASELINE_QUEENS if q[0] not in queens],'missing_equipment':[e for e in BASELINE_EQUIPMENT if e[0] not in equipment]}
    def restore_missing_baseline(self):
        added={'colonies':0,'queens':0,'equipment':0}
        with session_scope() as s:
            for c in BASELINE_COLONIES:
                if not s.query(Colony).filter_by(code=c[0]).first(): s.add(Colony(code=c[0],name=c[1],colony_type=c[2],equipment=c[3],objective=c[4],status=c[5],notes=c[6])); added['colonies']+=1
            for q in BASELINE_QUEENS:
                if not s.query(Queen).filter_by(code=q[0]).first(): s.add(Queen(code=q[0],name=q[1],line=q[2],source=q[3],current_colony_code=q[4],status=q[5],evidence_status=q[6],notes=q[7])); added['queens']+=1
            for e in BASELINE_EQUIPMENT:
                if not s.query(Equipment).filter_by(code=e[0]).first(): s.add(Equipment(code=e[0],name=e[1],type=e[2],current_location=e[3],compatible_with=e[4],status=e[5],notes=e[6])); added['equipment']+=1
            s.commit()
        self.audit('RESTORE_BASELINE',str(added)); return added

    def _colony(self,c): return {'id':c.id,'code':c.code,'name':c.name,'type':c.colony_type,'equipment':c.equipment,'objective':c.objective,'status':c.status,'notes':c.notes or ''}
    def _queen(self,q): return {'id':q.id,'code':q.code,'name':q.name,'line':q.line,'source':q.source,'current_colony':q.current_colony_code,'status':q.status,'evidence':q.evidence_status,'notes':q.notes or ''}
    def _equipment(self,e): return {'id':e.id,'code':e.code,'name':e.name,'type':e.type,'location':e.current_location,'compatible':e.compatible_with,'status':e.status,'notes':e.notes or ''}
