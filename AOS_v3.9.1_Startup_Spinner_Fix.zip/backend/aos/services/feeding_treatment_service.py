from aos.db.session import session_scope
from aos.db.models import FeedingRecord, TreatmentRecord

class FeedingTreatmentService:
    def list_feedings(self):
        with session_scope() as s:
            return [
                {
                    "id": r.id,
                    "date": r.date,
                    "colony_code": r.colony_code,
                    "feed_type": r.feed_type,
                    "amount": r.amount,
                    "reason": r.reason,
                    "notes": r.notes or "",
                }
                for r in s.query(FeedingRecord).order_by(FeedingRecord.date.desc(), FeedingRecord.id.desc()).limit(300).all()
            ]

    def add_feeding(self, data):
        with session_scope() as s:
            s.add(FeedingRecord(**data))
            s.commit()

    def delete_feeding(self, record_id):
        with session_scope() as s:
            r = s.query(FeedingRecord).get(record_id)
            if not r:
                raise ValueError("Feeding record not found")
            s.delete(r)
            s.commit()

    def list_treatments(self):
        with session_scope() as s:
            return [
                {
                    "id": r.id,
                    "date": r.date,
                    "colony_code": r.colony_code,
                    "treatment": r.treatment,
                    "dose": r.dose,
                    "reason": r.reason,
                    "follow_up_date": r.follow_up_date,
                    "notes": r.notes or "",
                }
                for r in s.query(TreatmentRecord).order_by(TreatmentRecord.date.desc(), TreatmentRecord.id.desc()).limit(300).all()
            ]

    def add_treatment(self, data):
        with session_scope() as s:
            s.add(TreatmentRecord(**data))
            s.commit()

    def delete_treatment(self, record_id):
        with session_scope() as s:
            r = s.query(TreatmentRecord).get(record_id)
            if not r:
                raise ValueError("Treatment record not found")
            s.delete(r)
            s.commit()
