from datetime import datetime
from aos.db.session import session_scope
from aos.db.models import Colony, Inspection, GuidedInspectionDraft

class DraftService:
    def validate(self,payload):
        if not payload.get('colony_id'): return {'status':'FAIL','message':'Colony/nuc required'}
        if not payload.get('inspection_date'): return {'status':'FAIL','message':'Inspection date required'}
        return {'status':'PASS','message':'Validation passed'}
    def confidence(self,payload):
        score=40
        for key in ['queen_seen','eggs_seen','brood_frames','stores_frames','bee_coverage_frames']:
            if payload.get(key): score+=12
        return min(100,score)
    def stage(self,payload):
        validation=self.validate(payload)
        with session_scope() as s:
            colony=s.query(Colony).get(payload['colony_id'])
            if not colony: raise ValueError('Colony not found')
            d=GuidedInspectionDraft(created_at=str(datetime.now().replace(microsecond=0)),colony_id=colony.id,colony_code=colony.code,inspection_date=payload['inspection_date'],queen_seen=bool(payload.get('queen_seen')),eggs_seen=bool(payload.get('eggs_seen')),larvae_seen=bool(payload.get('larvae_seen')),queen_cells=int(payload.get('queen_cells') or 0),brood_frames=float(payload.get('brood_frames') or 0),stores_frames=float(payload.get('stores_frames') or 0),bee_coverage_frames=float(payload.get('bee_coverage_frames') or 0),temperament=payload.get('temperament') or 'Unknown',notes=payload.get('notes') or '',evidence=str(payload),confidence=self.confidence(payload),validation_status=validation['status'],validation_message=validation['message'],status='Staged')
            s.add(d); s.commit(); return d.id, validation
    def list(self):
        with session_scope() as s:
            return [{'id':d.id,'created_at':d.created_at,'colony_code':d.colony_code,'inspection_date':d.inspection_date,'queen_seen':'Yes' if d.queen_seen else 'No','eggs_seen':'Yes' if d.eggs_seen else 'No','brood_frames':d.brood_frames,'stores_frames':d.stores_frames,'bee_coverage_frames':d.bee_coverage_frames,'confidence':d.confidence,'validation_status':d.validation_status,'validation_message':d.validation_message,'status':d.status} for d in s.query(GuidedInspectionDraft).order_by(GuidedInspectionDraft.id.desc()).limit(100).all()]
    def commit(self,draft_id):
        with session_scope() as s:
            d=s.query(GuidedInspectionDraft).get(draft_id)
            if not d or d.status!='Staged': raise ValueError('Draft not staged')
            if d.validation_status=='FAIL': raise ValueError('Cannot commit failed draft')
            s.add(Inspection(colony_id=d.colony_id,date=d.inspection_date,inspection_type='Guided',queen_seen=d.queen_seen,eggs_seen=d.eggs_seen,larvae_seen=d.larvae_seen,queen_cells=d.queen_cells,brood_frames=d.brood_frames,stores_frames=d.stores_frames,bee_coverage_frames=d.bee_coverage_frames,temperament=d.temperament,notes=d.notes)); d.status='Committed'; s.commit()
    def reject(self,draft_id):
        with session_scope() as s:
            d=s.query(GuidedInspectionDraft).get(draft_id)
            if not d: raise ValueError('Draft not found')
            d.status='Rejected'; s.commit()
