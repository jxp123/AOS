BASELINE_COLONIES = [
    ("H1","Hive 1","Hive","National","Honey / Build","Active","Double brood; super added."),
    ("H2","Hive 2","Hive","National","Build / Recover","Active","Essex Buckfast; low population recovery."),
    ("H3","Hive 3","Hive","Langstroth","Honey","Active","Queen seen; underpopulated; super unused."),
    ("H4","Hive 4","Hive","Langstroth","Honey","Active","Replace brood box with rails."),
    ("H5","Hive 5","Hive","Unknown","Requeening after swarm","Active","Swarm source; two queen cells left."),
    ("H6","Hive 6","Hive","Unknown","Queenright / Recover","Active","Eggs seen."),
    ("H7","Hive 7","Hive","Unknown","Honey","Active","Strong production colony; second super added."),
    ("H8","Hive 8","Hive","Unknown","Honey","Active","Queen seen, eggs, approx six brood frames."),
    ("H12","Hive 12","Hive","National","Expansion","Active","Former Nuc 99; feeder fitted."),
    ("H13","Hive 13","Hive","National","Build / Carpathian evaluation","Active","Former Nuc 93; Carpathian queen."),
    ("H14","Hive 14","Hive","National","Build / Queenright","Active","Eggs seen; not candidate for Jolanta."),
    ("H15","Hive 15","Hive","National","Honey","Active","Feeder removed; first super filling."),
    ("H16","Hive 16","Hive","National","Honey / Watch brood congestion","Active","Queen seen; no queen cells; brood box full."),
    ("H17","Hive 17","Hive","National","Build","Active","Queen seen; developing colony."),
    ("H19","Hive 19","Hive","National","Build / Carpathian evaluation","Active","Carpathian queen accepted; eggs seen."),
    ("N91","Nuc 91","Nuc","National","Recover after brood donation","Active","Donated 2 brood frames for Jolanta nuc."),
    ("N94","Nuc 94","Nuc","14x12","Build","Active","Hard rule: not National."),
    ("N100","Nuc 100","Nuc","National","Recover after brood donation","Active","Donated 1 brood frame for Jolanta nuc."),
    ("NJOL","Jolanta Nuc","Nuc","National","Scottish Carnica evaluation","Active","Created from brood frames from N91 and N100."),
]
BASELINE_QUEENS = [
    ("Q-JOLANTA","Jolanta","Scottish Carnica","Denrosa / Jolanta","NJOL","Introduced / pending confirmation","Confirmed","Strategic asset."),
]
BASELINE_EQUIPMENT = [
    ("FEED-001","Abelo Ashford Poly Feeder","Feeder","H12","National","In use","Moved from Hive 15."),
]
