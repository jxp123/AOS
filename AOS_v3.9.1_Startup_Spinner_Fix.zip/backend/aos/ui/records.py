from nicegui import ui
from aos.ui import colonies, queens, equipment, inspections, weather, integrity

def page():
    ui.label('Records').classes('text-h5')
    with ui.tabs().classes('w-full') as tabs:
        t_colonies=ui.tab('Colonies'); t_queens=ui.tab('Queens'); t_equipment=ui.tab('Equipment'); t_inspections=ui.tab('Inspections'); t_weather=ui.tab('Weather'); t_integrity=ui.tab('Data Integrity')
    with ui.tab_panels(tabs,value=t_colonies).classes('w-full'):
        with ui.tab_panel(t_colonies): colonies.page()
        with ui.tab_panel(t_queens): queens.page()
        with ui.tab_panel(t_equipment): equipment.page()
        with ui.tab_panel(t_inspections): inspections.page()
        with ui.tab_panel(t_weather): weather.page()
        with ui.tab_panel(t_integrity): integrity.page()
