from nicegui import ui
from aos.services.repository import Repository
from aos.engines.timelines import colony_timeline, queen_timeline, timeline_summary

def page():
    ui.label("Timelines").classes("text-h5")
    repo = Repository()

    with ui.tabs().classes("w-full") as tabs:
        t_summary = ui.tab("Summary")
        t_colony = ui.tab("Colony Timeline")
        t_queen = ui.tab("Queen Timeline")

    with ui.tab_panels(tabs, value=t_summary).classes("w-full"):
        with ui.tab_panel(t_summary):
            ui.table(
                columns=[
                    {"name":"code","label":"Code","field":"code"},
                    {"name":"name","label":"Name","field":"name"},
                    {"name":"latest_inspection","label":"Latest Inspection","field":"latest_inspection"},
                    {"name":"latest_notes","label":"Latest Notes","field":"latest_notes"},
                ],
                rows=timeline_summary(),
                row_key="code",
            ).classes("w-full")

        with ui.tab_panel(t_colony):
            holder = ui.column().classes("w-full")
            options = {f"{c['code']} — {c['name']}": c["code"] for c in repo.list_apiary_entities(True)}
            sel = ui.select(options, label="Colony/Nuc").classes("w-96")
            def show():
                holder.clear()
                if not sel.value:
                    ui.notify("Select colony/nuc", type="warning")
                    return
                with holder:
                    ui.table(
                        columns=[
                            {"name":"date","label":"Date","field":"date"},
                            {"name":"type","label":"Type","field":"type"},
                            {"name":"title","label":"Title","field":"title"},
                            {"name":"details","label":"Details","field":"details"},
                        ],
                        rows=colony_timeline(sel.value),
                        row_key="title",
                    ).classes("w-full")
            ui.button("Show Colony Timeline", on_click=show)
            holder

        with ui.tab_panel(t_queen):
            holder = ui.column().classes("w-full")
            options = {f"{q['code']} — {q.get('name','')}": q["code"] for q in repo.list_queens()}
            sel = ui.select(options, label="Queen").classes("w-96")
            def show():
                holder.clear()
                if not sel.value:
                    ui.notify("Select queen", type="warning")
                    return
                with holder:
                    ui.table(
                        columns=[
                            {"name":"date","label":"Date","field":"date"},
                            {"name":"type","label":"Type","field":"type"},
                            {"name":"title","label":"Title","field":"title"},
                            {"name":"details","label":"Details","field":"details"},
                        ],
                        rows=queen_timeline(sel.value),
                        row_key="title",
                    ).classes("w-full")
            ui.button("Show Queen Timeline", on_click=show)
            holder
