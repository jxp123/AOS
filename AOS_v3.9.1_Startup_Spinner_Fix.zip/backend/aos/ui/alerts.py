from nicegui import ui
from aos.engines.daily_operations import smart_alerts, latest_evidence_scores

def page():
    ui.label("Alerts").classes("text-h5")
    ui.label("Smart alerts and weak-evidence checks.").classes("text-subtitle1")

    ui.label("Smart Alerts").classes("text-h6")
    ui.table(
        columns=[
            {"name":"priority","label":"Priority","field":"priority"},
            {"name":"code","label":"Code","field":"code"},
            {"name":"alert","label":"Alert","field":"alert"},
            {"name":"reason","label":"Reason","field":"reason"},
        ],
        rows=smart_alerts(),
        row_key="code",
    ).classes("w-full")

    ui.label("Evidence Scores").classes("text-h6")
    ui.table(
        columns=[
            {"name":"code","label":"Code","field":"code"},
            {"name":"name","label":"Name","field":"name"},
            {"name":"evidence_score","label":"Evidence %","field":"evidence_score"},
            {"name":"evidence","label":"Evidence","field":"evidence"},
        ],
        rows=latest_evidence_scores(),
        row_key="code",
    ).classes("w-full")
