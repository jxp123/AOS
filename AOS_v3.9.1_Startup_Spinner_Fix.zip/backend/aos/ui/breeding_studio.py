from nicegui import ui
from datetime import date
from aos.services.repository import Repository
from aos.services.breeding_service import BreedingService
from aos.engines.breeding_engine import breeding_studio_summary, breeding_alerts

def page():
    ui.label("Queen Breeding Studio").classes("text-h5")
    ui.label("Evaluate queens, rank breeding candidates and create breeding plans.")

    service = BreedingService()
    repo = Repository()
    queen_options = {f"{q['code']} — {q.get('name','')} ({q.get('line','')})": q["code"] for q in repo.list_queens()}
    colony_options = {"None / not linked": ""}
    colony_options.update({f"{c['code']} — {c['name']}": c["code"] for c in repo.list_apiary_entities(True)})

    with ui.tabs().classes("w-full") as tabs:
        t_summary = ui.tab("Summary")
        t_eval = ui.tab("Queen Evaluation")
        t_plans = ui.tab("Breeding Plans")
        t_alerts = ui.tab("Breeding Alerts")

    with ui.tab_panels(tabs, value=t_summary).classes("w-full"):
        with ui.tab_panel(t_summary):
            holder = ui.column().classes("w-full")
            def render_summary():
                holder.clear()
                summary = breeding_studio_summary()
                with holder:
                    with ui.row():
                        for title, value in [
                            ("Queens", summary["queen_count"]),
                            ("Evaluated", summary["evaluated_queens"]),
                            ("Prime Candidates", summary["prime_candidates"]),
                            ("Possible Candidates", summary["possible_candidates"]),
                            ("Insufficient Data", summary["insufficient_data"]),
                            ("Active Plans", summary["active_plans"]),
                        ]:
                            with ui.card():
                                ui.label(title)
                                ui.label(str(value)).classes("text-h5")
                    ui.table(
                        columns=[
                            {"name":"queen_code","label":"Queen","field":"queen_code"},
                            {"name":"name","label":"Name","field":"name"},
                            {"name":"line","label":"Line","field":"line"},
                            {"name":"current_colony","label":"Colony","field":"current_colony"},
                            {"name":"evaluations","label":"Evaluations","field":"evaluations"},
                            {"name":"breeding_score","label":"Score","field":"breeding_score"},
                            {"name":"recommendation","label":"Recommendation","field":"recommendation"},
                        ],
                        rows=summary["scores"],
                        row_key="queen_code",
                    ).classes("w-full")
            ui.button("Refresh Summary", on_click=render_summary)
            render_summary()

        with ui.tab_panel(t_eval):
            holder = ui.column().classes("w-full")
            with ui.card().classes("w-full"):
                d = ui.input("Date", value=str(date.today())).classes("w-48")
                queen = ui.select(queen_options, label="Queen").classes("w-96")
                colony = ui.select(colony_options, label="Colony").classes("w-96")
                ui.label("Scores 0–10. For swarm tendency, 0 is best and 10 is worst.").classes("text-subtitle2")
                temperament = ui.number("Temperament", value=0, min=0, max=10, step=0.5).classes("w-48")
                brood = ui.number("Brood pattern", value=0, min=0, max=10, step=0.5).classes("w-48")
                spring = ui.number("Spring build-up", value=0, min=0, max=10, step=0.5).classes("w-48")
                honey = ui.number("Honey performance", value=0, min=0, max=10, step=0.5).classes("w-48")
                swarm = ui.number("Swarm tendency", value=0, min=0, max=10, step=0.5).classes("w-48")
                winter = ui.number("Winter survival", value=0, min=0, max=10, step=0.5).classes("w-48")
                disease = ui.number("Disease resilience", value=0, min=0, max=10, step=0.5).classes("w-48")
                notes = ui.textarea("Notes").classes("w-full")

                def save_eval():
                    if not queen.value:
                        ui.notify("Select queen", type="warning")
                        return
                    try:
                        service.add_evaluation({
                            "date": d.value,
                            "queen_code": queen.value,
                            "colony_code": colony.value or "",
                            "temperament": float(temperament.value or 0),
                            "brood_pattern": float(brood.value or 0),
                            "spring_build_up": float(spring.value or 0),
                            "honey_performance": float(honey.value or 0),
                            "swarm_tendency": float(swarm.value or 0),
                            "winter_survival": float(winter.value or 0),
                            "disease_resilience": float(disease.value or 0),
                            "notes": notes.value or "",
                        })
                        ui.notify("Queen evaluation saved", type="positive")
                        render_evals()
                    except Exception as e:
                        ui.notify(str(e), type="negative")
                ui.button("Save Queen Evaluation", on_click=save_eval)

            def render_evals():
                holder.clear()
                with holder:
                    table = ui.table(
                        columns=[
                            {"name":"id","label":"ID","field":"id"},
                            {"name":"date","label":"Date","field":"date"},
                            {"name":"queen_code","label":"Queen","field":"queen_code"},
                            {"name":"colony_code","label":"Colony","field":"colony_code"},
                            {"name":"score","label":"Score","field":"score"},
                            {"name":"temperament","label":"Temperament","field":"temperament"},
                            {"name":"brood_pattern","label":"Brood","field":"brood_pattern"},
                            {"name":"honey_performance","label":"Honey","field":"honey_performance"},
                            {"name":"swarm_tendency","label":"Swarm","field":"swarm_tendency"},
                            {"name":"notes","label":"Notes","field":"notes"},
                        ],
                        rows=service.list_evaluations(),
                        row_key="id",
                        selection="single",
                    ).classes("w-full")

                    def delete_selected():
                        if not table.selected:
                            ui.notify("Select evaluation", type="warning")
                            return
                        try:
                            service.delete_evaluation(table.selected[0]["id"])
                            ui.notify("Deleted", type="positive")
                            render_evals()
                        except Exception as e:
                            ui.notify(str(e), type="negative")

                    ui.button("Delete Selected Evaluation", color="red", on_click=delete_selected)
            render_evals()

        with ui.tab_panel(t_plans):
            holder = ui.column().classes("w-full")
            with ui.card().classes("w-full"):
                d = ui.input("Date", value=str(date.today())).classes("w-48")
                queen = ui.select(queen_options, label="Queen").classes("w-96")
                plan_type = ui.select(["Graft from queen", "Raise daughter queens", "Keep daughters", "Do not breed", "Monitor further"], label="Plan type", value="Monitor further").classes("w-64")
                targets = ui.input("Target colonies/nucs", placeholder="e.g. N91, N100, NJOL").classes("w-full")
                rationale = ui.textarea("Rationale").classes("w-full")
                status = ui.select(["Planned", "Active", "Completed", "Cancelled"], label="Status", value="Planned").classes("w-48")
                notes = ui.textarea("Notes").classes("w-full")

                def save_plan():
                    if not queen.value:
                        ui.notify("Select queen", type="warning")
                        return
                    try:
                        service.add_plan({
                            "date": d.value,
                            "queen_code": queen.value,
                            "plan_type": plan_type.value,
                            "target_colonies": targets.value or "",
                            "rationale": rationale.value or "",
                            "status": status.value,
                            "notes": notes.value or "",
                        })
                        ui.notify("Breeding plan saved", type="positive")
                        render_plans()
                    except Exception as e:
                        ui.notify(str(e), type="negative")
                ui.button("Save Breeding Plan", on_click=save_plan)

            def render_plans():
                holder.clear()
                with holder:
                    table = ui.table(
                        columns=[
                            {"name":"id","label":"ID","field":"id"},
                            {"name":"date","label":"Date","field":"date"},
                            {"name":"queen_code","label":"Queen","field":"queen_code"},
                            {"name":"plan_type","label":"Plan","field":"plan_type"},
                            {"name":"target_colonies","label":"Targets","field":"target_colonies"},
                            {"name":"rationale","label":"Rationale","field":"rationale"},
                            {"name":"status","label":"Status","field":"status"},
                            {"name":"notes","label":"Notes","field":"notes"},
                        ],
                        rows=service.list_plans(),
                        row_key="id",
                        selection="single",
                    ).classes("w-full")

                    def delete_selected():
                        if not table.selected:
                            ui.notify("Select plan", type="warning")
                            return
                        try:
                            service.delete_plan(table.selected[0]["id"])
                            ui.notify("Deleted", type="positive")
                            render_plans()
                        except Exception as e:
                            ui.notify(str(e), type="negative")

                    ui.button("Delete Selected Plan", color="red", on_click=delete_selected)
            render_plans()

        with ui.tab_panel(t_alerts):
            ui.table(
                columns=[
                    {"name":"priority","label":"Priority","field":"priority"},
                    {"name":"queen_code","label":"Queen","field":"queen_code"},
                    {"name":"alert","label":"Alert","field":"alert"},
                    {"name":"reason","label":"Reason","field":"reason"},
                ],
                rows=breeding_alerts(),
                row_key="queen_code",
            ).classes("w-full")
