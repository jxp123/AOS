from nicegui import ui
from aos.services.system_health_service import SystemHealthService

def page():
    ui.label("Database Unification").classes("text-h5")
    ui.label("Foundation checks for one source of truth and safe future migrations.")

    service = SystemHealthService()
    report = service.health_report()
    missing = service.missing_tables()

    with ui.card().classes("w-full"):
        ui.label("Current database status").classes("text-h6")
        ui.label(f"Status: {report['status']}")
        ui.label(f"Missing tables: {', '.join(missing) if missing else 'None'}")
        ui.label("This release introduces the stability layer. It does not destructively migrate existing live data.")

    ui.label("Unification principles now enforced").classes("text-h6")
    ui.table(
        columns=[
            {"name":"principle","label":"Principle","field":"principle"},
            {"name":"status","label":"Status","field":"status"},
            {"name":"detail","label":"Detail","field":"detail"},
        ],
        rows=[
            {"principle":"One colony source", "status":"Active", "detail":"All working screens read colonies from Repository.list_apiary_entities()."},
            {"principle":"Transactional inspection save", "status":"Active", "detail":"Inspection save writes inspection and audit log in one transaction."},
            {"principle":"Automatic backup", "status":"Active", "detail":"Startup creates a database backup when data/aos.db exists."},
            {"principle":"Health monitor", "status":"Active", "detail":"System Health checks tables, counts, DB size and latest backup."},
            {"principle":"Non-destructive migration", "status":"Active", "detail":"This release adds stability checks without deleting or reshaping live tables."},
        ],
        row_key="principle",
    ).classes("w-full")
