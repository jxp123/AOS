from nicegui import ui
from aos.services.repository import Repository

def page():
    ui.label('Data Integrity').classes('text-h5'); repo=Repository(); holder=ui.column().classes('w-full')
    def render():
        holder.clear(); data=repo.baseline_integrity()
        with holder:
            ui.label(f"Missing colonies: {len(data['missing_colonies'])}"); ui.label(f"Missing queens: {len(data['missing_queens'])}"); ui.label(f"Missing equipment: {len(data['missing_equipment'])}")
            ui.table(columns=[{'name':'code','label':'Code','field':'code'},{'name':'name','label':'Name','field':'name'},{'name':'type','label':'Type','field':'type'}],rows=[{'code':c[0],'name':c[1],'type':c[2]} for c in data['missing_colonies']],row_key='code').classes('w-full')
    def restore():
        added=repo.restore_missing_baseline(); ui.notify(f'Restored {added}',type='positive'); render()
    with ui.row(): ui.button('Run Check',on_click=render); ui.button('Restore Missing Baseline',on_click=restore)
    render()
