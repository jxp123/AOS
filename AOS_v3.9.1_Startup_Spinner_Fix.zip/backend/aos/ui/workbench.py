from nicegui import ui
from datetime import date
from aos.engines.workbench import workbench_rows, quick_inspection_payload
from aos.services.repository import Repository
from aos.services.draft_service import DraftService

def page():
    ui.label("Inspection Workbench").classes("text-h5")
    ui.label("Select a colony/nuc from today's queue, then either record an external check or stage a guided inspection draft.")

    repo = Repository()
    draft_service = DraftService()
    holder = ui.column().classes("w-full")

    def render():
        holder.clear()
        rows = workbench_rows()
        with holder:
            table = ui.table(
                columns=[
                    {"name":"priority","label":"Priority","field":"priority"},
                    {"name":"code","label":"Code","field":"code"},
                    {"name":"name","label":"Name","field":"name"},
                    {"name":"type","label":"Type","field":"type"},
                    {"name":"equipment","label":"Equipment","field":"equipment"},
                    {"name":"inspection_status","label":"Inspection Status","field":"inspection_status"},
                    {"name":"days_since","label":"Days Since","field":"days_since"},
                    {"name":"brain_score","label":"Brain Score","field":"brain_score"},
                    {"name":"next_action","label":"Next Action","field":"next_action"},
                    {"name":"reason","label":"Reason","field":"reason"},
                ],
                rows=rows,
                row_key="code",
                selection="single",
            ).classes("w-full")

            notes = ui.textarea("Action notes", value="External check completed.").classes("w-full")

            def selected_entity():
                if not table.selected:
                    ui.notify("Select a colony/nuc first", type="warning")
                    return None
                code = table.selected[0]["code"]
                for c in repo.list_apiary_entities(True):
                    if c["code"] == code:
                        return c
                ui.notify("Selected colony/nuc not found", type="negative")
                return None

            def record_external_check():
                c = selected_entity()
                if not c:
                    return
                try:
                    repo.create_inspection(quick_inspection_payload(c["id"], str(date.today()), notes.value or "External check completed."))
                    ui.notify(f"External check recorded for {c['code']}", type="positive")
                    render()
                except Exception as e:
                    ui.notify(str(e), type="negative")

            def stage_guided_draft():
                c = selected_entity()
                if not c:
                    return
                try:
                    draft_id, validation = draft_service.stage({
                        "colony_id": c["id"],
                        "inspection_date": str(date.today()),
                        "queen_seen": False,
                        "eggs_seen": False,
                        "larvae_seen": False,
                        "queen_cells": 0,
                        "brood_frames": 0,
                        "stores_frames": 0,
                        "bee_coverage_frames": 0,
                        "temperament": "Unknown",
                        "notes": notes.value or f"Guided inspection draft opened from workbench for {c['code']}",
                    })
                    ui.notify(f"Draft staged for {c['code']} — #{draft_id}: {validation['status']}", type="positive")
                    render()
                except Exception as e:
                    ui.notify(str(e), type="negative")

            with ui.row():
                ui.button("Record External Check", on_click=record_external_check)
                ui.button("Stage Guided Draft", on_click=stage_guided_draft)
                ui.button("Refresh", on_click=render)

    render()
