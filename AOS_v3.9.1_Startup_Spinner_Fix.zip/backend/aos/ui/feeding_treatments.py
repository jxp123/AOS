from nicegui import ui
from datetime import date
from aos.services.repository import Repository
from aos.services.feeding_treatment_service import FeedingTreatmentService
from aos.engines.feeding_treatment_engine import feeding_treatment_summary

def page():
    ui.label("Feeding / Treatments").classes("text-h5")
    repo = Repository()
    service = FeedingTreatmentService()
    entities = repo.list_apiary_entities(True)
    colony_options = {"All / Apiary-wide": ""}
    colony_options.update({f"{c['code']} — {c['name']}": c["code"] for c in entities})

    with ui.tabs().classes("w-full") as tabs:
        t_summary = ui.tab("Summary")
        t_feed = ui.tab("Feeding")
        t_treat = ui.tab("Treatments")

    with ui.tab_panels(tabs, value=t_summary).classes("w-full"):
        with ui.tab_panel(t_summary):
            holder = ui.column().classes("w-full")

            def render_summary():
                holder.clear()
                summary = feeding_treatment_summary()
                with holder:
                    with ui.row():
                        for title, value in [
                            ("Feeding Records", summary["feeding_count"]),
                            ("Treatment Records", summary["treatment_count"]),
                            ("Follow-ups Due", summary["follow_up_count"]),
                            ("Feeding Reviews", summary["feeding_review_count"]),
                        ]:
                            with ui.card():
                                ui.label(title)
                                ui.label(str(value)).classes("text-h5")
                    ui.label("Feeding / Treatment Alerts").classes("text-h6")
                    ui.table(
                        columns=[
                            {"name":"priority","label":"Priority","field":"priority"},
                            {"name":"colony_code","label":"Colony/Nuc","field":"colony_code"},
                            {"name":"type","label":"Type","field":"type"},
                            {"name":"reason","label":"Reason","field":"reason"},
                            {"name":"date","label":"Date","field":"date"},
                        ],
                        rows=summary["alerts"],
                        row_key="reason",
                    ).classes("w-full")

            ui.button("Refresh Summary", on_click=render_summary)
            render_summary()

        with ui.tab_panel(t_feed):
            holder = ui.column().classes("w-full")
            with ui.card().classes("w-full"):
                d = ui.input("Date", value=str(date.today())).classes("w-48")
                colony = ui.select(colony_options, label="Colony/Nuc").classes("w-96")
                feed_type = ui.select(["Syrup", "Fondant", "Pollen substitute", "Honey frame", "Other"], label="Feed type", value="Syrup").classes("w-64")
                amount = ui.input("Amount", placeholder="e.g. 1 litre / 2 frames").classes("w-64")
                reason = ui.input("Reason", placeholder="e.g. low stores / nuc build-up").classes("w-full")
                notes = ui.textarea("Notes").classes("w-full")

                def save_feed():
                    try:
                        service.add_feeding({
                            "date": d.value,
                            "colony_code": colony.value or "",
                            "feed_type": feed_type.value,
                            "amount": amount.value or "",
                            "reason": reason.value or "",
                            "notes": notes.value or "",
                        })
                        ui.notify("Feeding record saved", type="positive")
                        render_feed()
                    except Exception as e:
                        ui.notify(str(e), type="negative")

                ui.button("Save Feeding Record", on_click=save_feed)

            def render_feed():
                holder.clear()
                with holder:
                    table = ui.table(
                        columns=[
                            {"name":"id","label":"ID","field":"id"},
                            {"name":"date","label":"Date","field":"date"},
                            {"name":"colony_code","label":"Colony/Nuc","field":"colony_code"},
                            {"name":"feed_type","label":"Feed","field":"feed_type"},
                            {"name":"amount","label":"Amount","field":"amount"},
                            {"name":"reason","label":"Reason","field":"reason"},
                            {"name":"notes","label":"Notes","field":"notes"},
                        ],
                        rows=service.list_feedings(),
                        row_key="id",
                        selection="single",
                    ).classes("w-full")

                    def delete_selected():
                        if not table.selected:
                            ui.notify("Select a feeding record", type="warning")
                            return
                        try:
                            service.delete_feeding(table.selected[0]["id"])
                            ui.notify("Deleted", type="positive")
                            render_feed()
                        except Exception as e:
                            ui.notify(str(e), type="negative")

                    ui.button("Delete Selected Feeding Record", color="red", on_click=delete_selected)

            render_feed()

        with ui.tab_panel(t_treat):
            holder = ui.column().classes("w-full")
            with ui.card().classes("w-full"):
                d = ui.input("Date", value=str(date.today())).classes("w-48")
                colony = ui.select(colony_options, label="Colony/Nuc").classes("w-96")
                treatment = ui.input("Treatment", placeholder="e.g. oxalic / thymol / varroa check").classes("w-full")
                dose = ui.input("Dose / method").classes("w-full")
                reason = ui.input("Reason").classes("w-full")
                follow_up = ui.input("Follow-up date", placeholder="YYYY-MM-DD").classes("w-48")
                notes = ui.textarea("Notes").classes("w-full")

                def save_treatment():
                    try:
                        service.add_treatment({
                            "date": d.value,
                            "colony_code": colony.value or "",
                            "treatment": treatment.value or "",
                            "dose": dose.value or "",
                            "reason": reason.value or "",
                            "follow_up_date": follow_up.value or "",
                            "notes": notes.value or "",
                        })
                        ui.notify("Treatment record saved", type="positive")
                        render_treatments()
                    except Exception as e:
                        ui.notify(str(e), type="negative")

                ui.button("Save Treatment Record", on_click=save_treatment)

            def render_treatments():
                holder.clear()
                with holder:
                    table = ui.table(
                        columns=[
                            {"name":"id","label":"ID","field":"id"},
                            {"name":"date","label":"Date","field":"date"},
                            {"name":"colony_code","label":"Colony/Nuc","field":"colony_code"},
                            {"name":"treatment","label":"Treatment","field":"treatment"},
                            {"name":"dose","label":"Dose","field":"dose"},
                            {"name":"reason","label":"Reason","field":"reason"},
                            {"name":"follow_up_date","label":"Follow-up","field":"follow_up_date"},
                            {"name":"notes","label":"Notes","field":"notes"},
                        ],
                        rows=service.list_treatments(),
                        row_key="id",
                        selection="single",
                    ).classes("w-full")

                    def delete_selected():
                        if not table.selected:
                            ui.notify("Select a treatment record", type="warning")
                            return
                        try:
                            service.delete_treatment(table.selected[0]["id"])
                            ui.notify("Deleted", type="positive")
                            render_treatments()
                        except Exception as e:
                            ui.notify(str(e), type="negative")

                    ui.button("Delete Selected Treatment Record", color="red", on_click=delete_selected)

            render_treatments()
