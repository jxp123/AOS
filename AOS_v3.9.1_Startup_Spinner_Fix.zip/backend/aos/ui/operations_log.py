from nicegui import ui
from aos.services.operations_log_service import OperationsLogService

def page():
    ui.label("Operations Log").classes("text-h5")
    ui.table(columns=[
        {"name":"date","label":"Date","field":"date"},
        {"name":"action","label":"Action","field":"action"},
        {"name":"details","label":"Details","field":"details"},
    ], rows=OperationsLogService().list(), row_key="id").classes("w-full")
