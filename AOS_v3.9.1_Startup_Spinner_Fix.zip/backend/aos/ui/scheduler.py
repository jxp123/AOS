from nicegui import ui
from aos.engines.scheduler import inspection_schedule, DEFAULT_INTERVAL_DAYS
def page():
    ui.label("Inspection Scheduler").classes("text-h5")
    ui.label(f"Rule: inspect every {DEFAULT_INTERVAL_DAYS} days.")
    ui.table(columns=[{"name":"code","label":"Code","field":"code"},{"name":"status","label":"Status","field":"status"},{"name":"days_since","label":"Days Since","field":"days_since"},{"name":"reason","label":"Reason","field":"reason"}], rows=inspection_schedule(), row_key="code").classes("w-full")
