from nicegui import ui
from aos.engines.brain import apiary_brain_state, brain_briefing
def page():
    state = apiary_brain_state()
    ui.label("Apiary Brain").classes("text-h5")
    with ui.card().classes("w-full"):
        ui.label(brain_briefing())
    ui.table(columns=[{"name":"priority_score","label":"Priority","field":"priority_score"},{"name":"code","label":"Code","field":"code"},{"name":"inspection_status","label":"Inspection","field":"inspection_status"},{"name":"next_action","label":"Next Action","field":"next_action"},{"name":"evidence","label":"Evidence","field":"evidence"}], rows=state["colonies"], row_key="code").classes("w-full")
