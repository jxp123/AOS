from nicegui import ui
from aos.services.repository import Repository

def page():
    ui.label('Queen Register').classes('text-h5'); repo=Repository(); holder=ui.column().classes('w-full')
    fields=['code', 'name', 'line', 'source', 'current_colony', 'status', 'evidence', 'notes']
    def open_dialog(existing=None):
        with ui.dialog() as d, ui.card().classes('w-[700px]'):
            inputs={}
            for f in fields:
                inputs[f]=ui.textarea(f.title(),value=existing.get(f,'') if existing and f=='notes' else '').classes('w-full') if f=='notes' else ui.input(f.title(),value=existing.get(f,'') if existing else '').classes('w-full')
            def save():
                try:
                    raw={f:inputs[f].value or '' for f in fields}
                    if 'queens'=='queens': data={'code':raw['code'].strip(),'name':raw['name'],'line':raw['line'],'source':raw['source'],'current_colony_code':raw['current_colony'],'status':raw['status'],'evidence_status':raw['evidence'],'notes':raw['notes']}
                    else: data={'code':raw['code'].strip(),'name':raw['name'],'type':raw['type'],'current_location':raw['location'],'compatible_with':raw['compatible'],'status':raw['status'],'notes':raw['notes']}
                    getattr(repo,'update_queen')(existing['code'],data) if existing else getattr(repo,'create_queen')(data)
                    ui.notify('Saved',type='positive'); d.close(); render()
                except Exception as e: ui.notify(str(e),type='negative')
            with ui.row(): ui.button('Save',on_click=save); ui.button('Cancel',on_click=d.close)
        d.open()
    def render():
        holder.clear()
        with holder:
            table=ui.table(columns=[{'name':k,'label':k.replace('_',' ').title(),'field':k} for k in fields],rows=getattr(repo,'list_queens')(),row_key='code',selection='single').classes('w-full')
            def edit():
                if not table.selected: ui.notify('Select a row',type='warning'); return
                open_dialog(table.selected[0])
            def delete_selected():
                if not table.selected: ui.notify('Select a row',type='warning'); return
                try: getattr(repo,'delete_queen')(table.selected[0]['code']); ui.notify('Deleted',type='positive'); render()
                except Exception as e: ui.notify(str(e),type='negative')
            with ui.row(): ui.button('Add',on_click=lambda:open_dialog()); ui.button('Edit',on_click=edit); ui.button('Delete',color='red',on_click=delete_selected); ui.button('Refresh',on_click=render)
    render()
