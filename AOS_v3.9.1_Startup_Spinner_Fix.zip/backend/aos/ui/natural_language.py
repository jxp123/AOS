from nicegui import ui
from aos.engines.natural_language import parse_note
from aos.services.draft_service import DraftService

def page():
    ui.label('Natural Language').classes('text-h5'); note=ui.textarea('Inspection note',placeholder='Hive 16 queen seen, eggs present, 6 brood, 2 stores, calm.').classes('w-full'); holder=ui.column().classes('w-full'); cache={'parsed':None}
    def parse():
        holder.clear(); data=parse_note(note.value or ''); cache['parsed']=data
        with holder: ui.table(columns=[{'name':'field','label':'Field','field':'field'},{'name':'value','label':'Value','field':'value'}],rows=[{'field':k,'value':str(v)} for k,v in data.items()],row_key='field').classes('w-full')
    def stage():
        if cache['parsed'] is None: parse()
        data=cache['parsed']
        if not data.get('colony_id'): ui.notify('Colony/nuc not detected',type='warning'); return
        try: draft_id,validation=DraftService().stage(data); ui.notify(f"Draft {draft_id}: {validation['status']}",type='positive')
        except Exception as e: ui.notify(str(e),type='negative')
    with ui.row(): ui.button('Parse',on_click=parse); ui.button('Stage Draft',on_click=stage)
