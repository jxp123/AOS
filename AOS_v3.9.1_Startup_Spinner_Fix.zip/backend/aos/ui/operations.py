from nicegui import ui
from aos.engines.operations import todays_work, shift_briefing
from aos.engines.workbench import workbench_rows

def page():
    w = todays_work()
    wb = workbench_rows()
    ui.label("Operations").classes("text-h5")
    with ui.row():
        for k in ["overdue","due_today","due_soon","estimated_duration"]:
            with ui.card():
                ui.label(k.replace("_"," ").title())
                ui.label(str(w[k])).classes("text-h5")
        with ui.card():
            ui.label("Workbench Items")
            ui.label(str(len([r for r in wb if r["priority"] in ["High", "Medium"]]))).classes("text-h5")
    with ui.card().classes("w-full"):
        ui.label(shift_briefing())
        ui.label("Use the Inspection Workbench tab to record or stage today's inspection work.")
    ui.label("Inspection Queue").classes("text-h6")
    ui.table(columns=[
        {"name":"code","label":"Code","field":"code"},
        {"name":"status","label":"Status","field":"status"},
        {"name":"days_since","label":"Days Since","field":"days_since"},
        {"name":"reason","label":"Reason","field":"reason"}],
        rows=w["inspection_queue"], row_key="code").classes("w-full")
    ui.label("Suggested Route").classes("text-h6")
    ui.label(" → ".join(w["route"]) if w["route"] else "No inspections due.")
    ui.label("Equipment Checklist").classes("text-h6")
    for item in ["Smoker", "Fuel", "Hive tool", "Notebook/phone", "Queen clip", "Marker pen", "Spare frames", "Feeder"]:
        ui.checkbox(item)
