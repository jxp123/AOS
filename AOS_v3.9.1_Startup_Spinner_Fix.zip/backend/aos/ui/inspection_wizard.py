from nicegui import ui
from datetime import date
from aos.services.repository import Repository
from aos.services.draft_service import DraftService

def page():
    ui.label("Inspection Wizard").classes("text-h5")
    ui.label("Fast phone/tablet workflow: colony → queen → brood → stores → cells → temperament → stage draft.")

    repo = Repository()
    svc = DraftService()
    entities = repo.list_apiary_entities(True)
    options = {f"{e['code']} — {e['name']} ({e['type']}, {e['equipment']})": e["id"] for e in entities}

    holder = ui.column().classes("w-full")
    result = ui.column().classes("w-full")

    state = {
        "colony_id": None,
        "inspection_date": str(date.today()),
        "queen_seen": False,
        "eggs_seen": False,
        "larvae_seen": False,
        "queen_cells": 0,
        "brood_frames": 0,
        "stores_frames": 0,
        "bee_coverage_frames": 0,
        "temperament": "Unknown",
        "notes": "",
    }

    def render_step(step=1):
        holder.clear()
        result.clear()
        with holder:
            if step == 1:
                ui.label("Step 1 — Select colony/nuc").classes("text-h6")
                sel = ui.select(options, label="Colony/Nuc").classes("w-96")
                d = ui.input("Date", value=state["inspection_date"]).classes("w-48")
                def next_step():
                    if not sel.value:
                        ui.notify("Select colony/nuc", type="warning")
                        return
                    state["colony_id"] = sel.value
                    state["inspection_date"] = d.value
                    render_step(2)
                ui.button("Next", on_click=next_step)

            elif step == 2:
                ui.label("Step 2 — Queen evidence").classes("text-h6")
                q = ui.checkbox("Queen seen", value=state["queen_seen"])
                eggs = ui.checkbox("Eggs seen", value=state["eggs_seen"])
                larvae = ui.checkbox("Larvae seen", value=state["larvae_seen"])
                def next_step():
                    state["queen_seen"] = bool(q.value)
                    state["eggs_seen"] = bool(eggs.value)
                    state["larvae_seen"] = bool(larvae.value)
                    render_step(3)
                with ui.row():
                    ui.button("Back", on_click=lambda: render_step(1))
                    ui.button("Next", on_click=next_step)

            elif step == 3:
                ui.label("Step 3 — Strength").classes("text-h6")
                brood = ui.number("Brood frames", value=state["brood_frames"], min=0, step=0.5).classes("w-48")
                stores = ui.number("Stores frames", value=state["stores_frames"], min=0, step=0.5).classes("w-48")
                bees = ui.number("Bee coverage frames", value=state["bee_coverage_frames"], min=0, step=0.5).classes("w-48")
                def next_step():
                    state["brood_frames"] = float(brood.value or 0)
                    state["stores_frames"] = float(stores.value or 0)
                    state["bee_coverage_frames"] = float(bees.value or 0)
                    render_step(4)
                with ui.row():
                    ui.button("Back", on_click=lambda: render_step(2))
                    ui.button("Next", on_click=next_step)

            elif step == 4:
                ui.label("Step 4 — Queen cells and temperament").classes("text-h6")
                qcells = ui.number("Queen cells", value=state["queen_cells"], min=0).classes("w-48")
                temperament = ui.select(["Calm","OK","Defensive","Aggressive","Unknown"], label="Temperament", value=state["temperament"]).classes("w-48")
                notes = ui.textarea("Notes", value=state["notes"]).classes("w-full")
                def next_step():
                    state["queen_cells"] = int(qcells.value or 0)
                    state["temperament"] = temperament.value
                    state["notes"] = notes.value or ""
                    render_step(5)
                with ui.row():
                    ui.button("Back", on_click=lambda: render_step(3))
                    ui.button("Review", on_click=next_step)

            elif step == 5:
                ui.label("Step 5 — Review and stage").classes("text-h6")
                ui.table(
                    columns=[{"name":"field","label":"Field","field":"field"},{"name":"value","label":"Value","field":"value"}],
                    rows=[{"field": k, "value": str(v)} for k, v in state.items()],
                    row_key="field",
                ).classes("w-full")
                def stage():
                    try:
                        draft_id, validation = svc.stage(state)
                        ui.notify(f"Draft staged #{draft_id}: {validation['status']}", type="positive")
                        with result:
                            ui.label(f"Draft staged #{draft_id}. Go to Guided Inspection to commit/reject.").classes("text-positive")
                    except Exception as e:
                        ui.notify(str(e), type="negative")
                with ui.row():
                    ui.button("Back", on_click=lambda: render_step(4))
                    ui.button("Stage Draft", on_click=stage)
                    ui.button("Start Again", on_click=lambda: render_step(1))

    render_step(1)
