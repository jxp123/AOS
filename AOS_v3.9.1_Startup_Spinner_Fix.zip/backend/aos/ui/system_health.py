from nicegui import ui
from aos.services.system_health_service import SystemHealthService

def page():
    ui.label("System Health").classes("text-h5")
    ui.label("Database, tables, counts and backup status.").classes("text-subtitle1")

    service = SystemHealthService()
    holder = ui.column().classes("w-full")

    def render():
        holder.clear()
        report = service.health_report()
        with holder:
            with ui.card():
                ui.label("Overall Status")
                ui.label(report["status"]).classes("text-h5")
            ui.table(
                columns=[
                    {"name":"check","label":"Check","field":"check"},
                    {"name":"status","label":"Status","field":"status"},
                    {"name":"detail","label":"Detail","field":"detail"},
                ],
                rows=report["checks"],
                row_key="check",
            ).classes("w-full")

    def backup():
        result = service.create_startup_backup()
        ui.notify(f"{result['status']}: {result['message']}", type="positive" if result["status"] == "PASS" else "warning")
        render()

    with ui.row():
        ui.button("Refresh Health", on_click=render)
        ui.button("Create Backup Now", on_click=backup)
    render()
