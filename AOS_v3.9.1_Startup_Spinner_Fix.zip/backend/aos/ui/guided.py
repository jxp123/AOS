from nicegui import ui
from datetime import date
from aos.services.repository import Repository
from aos.services.draft_service import DraftService

def page():
    ui.label('Guided Inspection').classes('text-h5'); repo=Repository(); svc=DraftService(); holder=ui.column().classes('w-full'); options={f"{e['code']} — {e['name']} ({e['type']}, {e['equipment']})":e['id'] for e in repo.list_apiary_entities(True)}
    with ui.card().classes('w-full'):
        sel=ui.select(options,label='Colony/Nuc').classes('w-96'); d=ui.input('Date',value=str(date.today())).classes('w-48'); q=ui.checkbox('Queen seen'); eggs=ui.checkbox('Eggs seen'); larvae=ui.checkbox('Larvae seen'); qcells=ui.number('Queen cells',value=0,min=0).classes('w-48'); brood=ui.number('Brood frames',value=0,min=0,step=0.5).classes('w-48'); stores=ui.number('Stores frames',value=0,min=0,step=0.5).classes('w-48'); bees=ui.number('Bee coverage frames',value=0,min=0,step=0.5).classes('w-48'); temperament=ui.select(['Calm','OK','Defensive','Aggressive','Unknown'],label='Temperament',value='Unknown').classes('w-48'); notes=ui.textarea('Notes').classes('w-full')
        def stage():
            try: draft_id,validation=svc.stage({'colony_id':sel.value,'inspection_date':d.value,'queen_seen':q.value,'eggs_seen':eggs.value,'larvae_seen':larvae.value,'queen_cells':qcells.value,'brood_frames':brood.value,'stores_frames':stores.value,'bee_coverage_frames':bees.value,'temperament':temperament.value,'notes':notes.value or ''}); ui.notify(f"Draft {{draft_id}}: {{validation['status']}}",type='positive'); render()
            except Exception as e: ui.notify(str(e),type='negative')
        ui.button('Stage Draft',on_click=stage)
    def render():
        holder.clear()
        with holder:
            table=ui.table(columns=[{'name':k,'label':k.replace('_',' ').title(),'field':k} for k in ['id','colony_code','inspection_date','confidence','validation_status','status','validation_message']],rows=svc.list(),row_key='id',selection='single').classes('w-full')
            def commit():
                if not table.selected: ui.notify('Select draft',type='warning'); return
                try: svc.commit(table.selected[0]['id']); ui.notify('Committed',type='positive'); render()
                except Exception as e: ui.notify(str(e),type='negative')
            def reject():
                if not table.selected: ui.notify('Select draft',type='warning'); return
                try: svc.reject(table.selected[0]['id']); ui.notify('Rejected',type='positive'); render()
                except Exception as e: ui.notify(str(e),type='negative')
            with ui.row(): ui.button('Commit Selected',on_click=commit); ui.button('Reject Selected',color='red',on_click=reject); ui.button('Refresh',on_click=render)
    render()
