from nicegui import ui
from aos.utils.self_test import run_self_tests, summary
from aos.utils.exporters import export_ai_json, export_excel

def page():
    ui.label("Tests / Exports").classes("text-h5")
    holder = ui.column().classes("w-full")

    def test():
        holder.clear()
        rows = run_self_tests()
        s = summary(rows)
        with holder:
            ui.label(f"Self-test: PASS={s['pass']} FAIL={s['fail']} TOTAL={s['total']}")
            ui.table(
                columns=[
                    {"name":"status","label":"Status","field":"status"},
                    {"name":"test","label":"Test","field":"test"},
                    {"name":"message","label":"Message","field":"message"},
                ],
                rows=rows,
                row_key="test",
            ).classes("w-full")

            try:
                from aos.utils.runtime_smoke import run_runtime_smoke
                smoke = run_runtime_smoke()
                ui.label("Runtime page smoke")
                ui.table(
                    columns=[
                        {"name":"status","label":"Status","field":"status"},
                        {"name":"page","label":"Page","field":"page"},
                        {"name":"message","label":"Message","field":"message"},
                    ],
                    rows=smoke,
                    row_key="page",
                ).classes("w-full")
            except Exception as e:
                ui.label(f"Runtime page smoke could not run: {e}").classes("text-negative")

    def ai():
        path = export_ai_json()
        ui.notify(f"Exported {path}", type="positive")

    def excel():
        path = export_excel()
        ui.notify(f"Exported {path}", type="positive")

    with ui.row():
        ui.button("Run Tests", on_click=test)
        ui.button("Export AI JSON", on_click=ai)
        ui.button("Export Excel", on_click=excel)
    test()
