from datetime import date
from aos.engines.operations import todays_work, shift_briefing
from aos.engines.workbench import workbench_rows
from aos.engines.brain import apiary_brain_state
from aos.services.repository import Repository
from aos.engines.feeding_treatment_engine import feeding_treatment_summary
from aos.engines.breeding_engine import breeding_alerts

def evidence_score_for_inspection(row):
    score = 0
    if row.get("queen_seen") == "Yes": score += 20
    if row.get("eggs_seen") == "Yes": score += 20
    if row.get("larvae_seen") == "Yes": score += 10
    if row.get("brood_frames", 0): score += 15
    if row.get("stores_frames", 0): score += 15
    if row.get("bee_coverage_frames", 0): score += 10
    if row.get("notes"): score += 10
    return min(100, score)

def latest_evidence_scores():
    repo = Repository()
    latest = repo.latest_inspection_by_colony()
    rows = []
    for c in repo.list_apiary_entities(True):
        inspection = latest.get(c["code"])
        if inspection:
            score = evidence_score_for_inspection(inspection)
            evidence = []
            if inspection.get("queen_seen") == "Yes": evidence.append("Queen seen")
            if inspection.get("eggs_seen") == "Yes": evidence.append("Eggs")
            if inspection.get("larvae_seen") == "Yes": evidence.append("Larvae")
            if inspection.get("brood_frames", 0): evidence.append("Brood measured")
            if inspection.get("stores_frames", 0): evidence.append("Stores measured")
            if inspection.get("bee_coverage_frames", 0): evidence.append("Bee coverage measured")
            if inspection.get("notes"): evidence.append("Notes")
        else:
            score = 0
            evidence = ["No inspection recorded"]
        rows.append({"code": c["code"], "name": c["name"], "evidence_score": score, "evidence": ", ".join(evidence)})
    rows.sort(key=lambda r: r["evidence_score"])
    return rows

def smart_alerts():
    alerts = []
    for row in apiary_brain_state()["colonies"]:
        if row.get("inspection_status") == "Overdue":
            alerts.append({"priority": "High", "code": row["code"], "alert": "Inspection overdue", "reason": row.get("evidence", "")})
        if row.get("priority_score", 0) >= 80:
            alerts.append({"priority": "High", "code": row["code"], "alert": "High Apiary Brain priority", "reason": row.get("next_action", "")})
    for row in latest_evidence_scores():
        if row["evidence_score"] < 40:
            alerts.append({"priority": "Medium", "code": row["code"], "alert": "Weak inspection evidence", "reason": row["evidence"]})
    order = {"High": 0, "Medium": 1, "Low": 2}
    alerts.sort(key=lambda a: (order.get(a["priority"], 9), a["code"]))
    alerts.extend(feeding_treatment_summary().get('alerts', []))
    for b in breeding_alerts():
        alerts.append({"priority": b.get("priority", "Medium"), "code": b.get("queen_code", ""), "alert": b.get("alert", "Breeding"), "reason": b.get("reason", "")})
    return alerts

def inspection_route():
    rows = [r for r in workbench_rows() if r["priority"] in ["High", "Medium"]]
    def key(row):
        import re
        prefix = 0 if row["code"].startswith("H") else 1 if row["code"].startswith("N") else 2
        m = re.search(r"(\d+)", row["code"])
        return (prefix, int(m.group(1)) if m else 999)
    return sorted(rows, key=key)

def apiary_map_rows():
    return [{"position": c["code"], "name": c["name"], "type": c["type"], "equipment": c["equipment"], "status": c["status"]} for c in Repository().list_apiary_entities(True)]

def daily_dashboard():
    work = todays_work()
    brain = apiary_brain_state()
    route = inspection_route()
    alerts = smart_alerts()
    return {
        "date": str(date.today()),
        "briefing": shift_briefing(),
        "apiary_priority_score": brain.get("apiary_priority_score", 0),
        "overdue": work.get("overdue", 0),
        "due_today": work.get("due_today", 0),
        "due_soon": work.get("due_soon", 0),
        "estimated_duration": work.get("estimated_duration", "0m"),
        "route_count": len(route),
        "alerts_count": len(alerts),
        "route": route,
        "alerts": alerts,
        "evidence_scores": latest_evidence_scores(),
        "map": apiary_map_rows(),
    }
