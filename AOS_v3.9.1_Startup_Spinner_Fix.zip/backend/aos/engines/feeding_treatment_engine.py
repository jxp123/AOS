from datetime import date, datetime
from aos.services.feeding_treatment_service import FeedingTreatmentService
from aos.services.repository import Repository

def _parse_date(value):
    try:
        return datetime.fromisoformat(str(value)).date()
    except Exception:
        return None

def feeding_treatment_summary():
    service = FeedingTreatmentService()
    feedings = service.list_feedings()
    treatments = service.list_treatments()
    today = date.today()

    follow_ups = []
    for t in treatments:
        d = _parse_date(t.get("follow_up_date"))
        if d and d <= today:
            follow_ups.append({
                "priority": "High",
                "colony_code": t.get("colony_code", ""),
                "type": "Treatment follow-up",
                "reason": f"Follow-up due for {t.get('treatment','')}",
                "date": t.get("follow_up_date", ""),
            })

    latest_feed_by_colony = {}
    for f in feedings:
        latest_feed_by_colony.setdefault(f.get("colony_code", ""), f)

    feed_gaps = []
    for colony in Repository().list_apiary_entities(True):
        code = colony["code"]
        if "recover" in (colony.get("objective") or "").lower() or colony.get("type") == "Nuc":
            if code not in latest_feed_by_colony:
                feed_gaps.append({
                    "priority": "Medium",
                    "colony_code": code,
                    "type": "Feeding review",
                    "reason": "Nuc/recovery colony has no feeding record in AOS.",
                    "date": str(today),
                })

    return {
        "feeding_count": len(feedings),
        "treatment_count": len(treatments),
        "follow_up_count": len(follow_ups),
        "feeding_review_count": len(feed_gaps),
        "alerts": follow_ups + feed_gaps,
    }
