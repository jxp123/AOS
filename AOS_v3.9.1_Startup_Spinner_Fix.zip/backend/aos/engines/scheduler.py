from datetime import date, datetime
from aos.services.repository import Repository
DEFAULT_INTERVAL_DAYS = 7
def parse_date(value):
    try:
        return datetime.fromisoformat(str(value)).date()
    except Exception:
        return None
def inspection_schedule():
    repo = Repository()
    latest = repo.latest_inspection_by_colony()
    today = date.today()
    rows = []
    for c in repo.list_apiary_entities(True):
        li = latest.get(c["code"])
        last = parse_date(li["date"]) if li else None
        days = (today - last).days if last else None
        if days is None:
            status, reason = "Overdue", "No inspection recorded"
        elif days > DEFAULT_INTERVAL_DAYS:
            status, reason = "Overdue", f"{days} days since inspection"
        elif days == DEFAULT_INTERVAL_DAYS:
            status, reason = "Due Today", "7-day rule"
        elif days == DEFAULT_INTERVAL_DAYS - 1:
            status, reason = "Due Soon", "6 days since inspection"
        else:
            status, reason = "Recent", f"{days} days since inspection"
        rows.append({"code":c["code"],"name":c["name"],"status":status,"days_since":"" if days is None else days,"reason":reason})
    return rows
