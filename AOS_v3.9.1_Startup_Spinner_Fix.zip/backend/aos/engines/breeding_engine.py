from aos.services.breeding_service import BreedingService
from aos.services.repository import Repository

def breeding_studio_summary():
    service = BreedingService()
    scores = service.queen_scores()
    plans = service.list_plans()
    prime = [s for s in scores if s["recommendation"] == "Prime breeding candidate"]
    possible = [s for s in scores if s["recommendation"] == "Possible breeding candidate"]
    insufficient = [s for s in scores if s["recommendation"] == "Insufficient data"]
    return {
        "queen_count": len(Repository().list_queens()),
        "evaluated_queens": len([s for s in scores if s["evaluations"] > 0]),
        "prime_candidates": len(prime),
        "possible_candidates": len(possible),
        "insufficient_data": len(insufficient),
        "active_plans": len([p for p in plans if p["status"] in ["Planned", "Active"]]),
        "scores": scores,
        "plans": plans,
    }

def breeding_alerts():
    summary = breeding_studio_summary()
    alerts = []
    for row in summary["scores"]:
        if row["recommendation"] == "Prime breeding candidate":
            alerts.append({
                "priority": "High",
                "queen_code": row["queen_code"],
                "alert": "Prime breeding candidate",
                "reason": f"Breeding score {row['breeding_score']}",
            })
        elif row["recommendation"] == "Insufficient data":
            alerts.append({
                "priority": "Medium",
                "queen_code": row["queen_code"],
                "alert": "Queen needs evaluation",
                "reason": "No queen evaluation records yet.",
            })
    return alerts
