from datetime import date
from aos.engines.scheduler import inspection_schedule
from aos.engines.brain import apiary_brain_state
from aos.services.repository import Repository

def workbench_rows():
    schedule = {r["code"]: r for r in inspection_schedule()}
    brain = {r["code"]: r for r in apiary_brain_state()["colonies"]}
    rows = []
    for c in Repository().list_apiary_entities(True):
        sched = schedule.get(c["code"], {})
        state = brain.get(c["code"], {})
        status = sched.get("status", "Unknown")
        if status in ["Overdue", "Due Today", "Due Soon"]:
            priority = "High" if status in ["Overdue", "Due Today"] else "Medium"
        elif state.get("priority_score", 0) >= 70:
            priority = "High"
        else:
            priority = "Low"
        rows.append({
            "code": c["code"],
            "name": c["name"],
            "type": c["type"],
            "equipment": c["equipment"],
            "priority": priority,
            "inspection_status": status,
            "days_since": sched.get("days_since", ""),
            "brain_score": state.get("priority_score", 0),
            "next_action": state.get("next_action", "Monitor"),
            "reason": sched.get("reason", state.get("evidence", "")),
        })
    order = {"High": 0, "Medium": 1, "Low": 2}
    rows.sort(key=lambda r: (order.get(r["priority"], 9), r["code"]))
    return rows

def quick_inspection_payload(colony_id, inspection_date=None, notes="External check completed"):
    return {
        "colony_id": colony_id,
        "date": inspection_date or str(date.today()),
        "inspection_type": "External Check",
        "queen_seen": False,
        "eggs_seen": False,
        "larvae_seen": False,
        "queen_cells": 0,
        "brood_frames": 0,
        "stores_frames": 0,
        "bee_coverage_frames": 0,
        "temperament": "Unknown",
        "notes": notes,
    }
