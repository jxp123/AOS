from aos.engines.scheduler import inspection_schedule
def todays_work():
    due = [r for r in inspection_schedule() if r["status"] in ["Overdue","Due Today","Due Soon"]]
    return {"overdue":len([r for r in due if r["status"]=="Overdue"]),"due_today":len([r for r in due if r["status"]=="Due Today"]),"due_soon":len([r for r in due if r["status"]=="Due Soon"]),"route":[r["code"] for r in due],"inspection_queue":due,"estimated_duration":f"{len(due)*10}m"}
def shift_briefing():
    w = todays_work()
    return f"{w['overdue']} overdue, {w['due_today']} due today, {w['due_soon']} due soon. Estimated visit {w['estimated_duration']}."
