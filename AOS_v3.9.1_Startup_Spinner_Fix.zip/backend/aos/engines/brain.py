from aos.services.repository import Repository
from aos.engines.scheduler import inspection_schedule
def apiary_brain_state():
    schedule = {r["code"]:r for r in inspection_schedule()}
    rows = []
    for c in Repository().list_apiary_entities(True):
        s = schedule[c["code"]]
        urgency = 90 if s["status"] == "Overdue" else 75 if s["status"] == "Due Today" else 50 if s["status"] == "Due Soon" else 20
        risk = 30 if "swarm" in (c["notes"] or "").lower() or "requeening" in (c["objective"] or "").lower() else 10
        priority = int(urgency * 0.7 + risk * 0.3)
        rows.append({"code":c["code"],"name":c["name"],"priority_score":priority,"inspection_status":s["status"],"days_since":s["days_since"],"next_action":"Inspect today" if urgency >= 75 else "Monitor","evidence":s["reason"]})
    rows.sort(key=lambda x:x["priority_score"], reverse=True)
    return {"apiary_priority_score": int(sum(r["priority_score"] for r in rows[:5]) / max(1,min(5,len(rows)))),"colonies":rows,"critical":len([r for r in rows if r["priority_score"]>=80])}
def brain_briefing():
    state = apiary_brain_state()
    top = state["colonies"][0] if state["colonies"] else None
    return f"Apiary priority score {state['apiary_priority_score']}/100. Top priority: {top['code'] if top else 'none'}."
