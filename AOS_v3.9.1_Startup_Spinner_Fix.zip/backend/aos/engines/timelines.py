from aos.services.repository import Repository

def colony_timeline(code):
    repo = Repository()
    events = []
    colony = next((c for c in repo.list_colonies() if c["code"] == code), None)
    if colony:
        events.append({
            "date": "",
            "type": "Colony record",
            "title": f"{colony['code']} — {colony['name']}",
            "details": f"{colony['type']} / {colony['equipment']} / {colony['objective']} / {colony['notes']}",
        })
    for i in repo.list_inspections():
        if i.get("colony") == code:
            events.append({
                "date": i.get("date", ""),
                "type": "Inspection",
                "title": f"Queen {i.get('queen_seen')} | Eggs {i.get('eggs_seen')} | Brood {i.get('brood_frames')}",
                "details": f"Stores {i.get('stores_frames')}; Bees {i.get('bee_coverage_frames')}; Q cells {i.get('queen_cells')}; {i.get('notes','')}",
            })
    events.sort(key=lambda e: e.get("date") or "0000-00-00", reverse=True)
    return events

def queen_timeline(code):
    repo = Repository()
    events = []
    queen = next((q for q in repo.list_queens() if q["code"] == code), None)
    if queen:
        events.append({
            "date": "",
            "type": "Queen profile",
            "title": f"{queen['code']} — {queen.get('name','')}",
            "details": f"Line {queen.get('line','')}; Current colony {queen.get('current_colony','')}; Status {queen.get('status','')}; {queen.get('notes','')}",
        })
        current = queen.get("current_colony")
        if current:
            events += [
                {
                    "date": e["date"],
                    "type": "Linked colony inspection",
                    "title": e["title"],
                    "details": e["details"],
                }
                for e in colony_timeline(current)
                if e["type"] == "Inspection"
            ]
    events.sort(key=lambda e: e.get("date") or "0000-00-00", reverse=True)
    return events

def timeline_summary():
    repo = Repository()
    latest = repo.latest_inspection_by_colony()
    return [
        {
            "code": c["code"],
            "name": c["name"],
            "latest_inspection": latest.get(c["code"], {}).get("date", "Never"),
            "latest_notes": latest.get(c["code"], {}).get("notes", ""),
        }
        for c in repo.list_apiary_entities(True)
    ]
