import re
from datetime import date
from aos.services.repository import Repository
def parse_note(text):
    lower = text.lower()
    entity = None
    for c in Repository().list_apiary_entities(True):
        if c["code"].lower() in lower or (c["type"].lower() + " " + c["code"][1:]).lower() in lower:
            entity = c
            break
    brood = re.search(r"(\d+)\s+brood", lower)
    stores = re.search(r"(\d+)\s+stores", lower)
    return {"colony_id":entity["id"] if entity else None,"colony_code":entity["code"] if entity else "","inspection_date":str(date.today()),"queen_seen":"queen seen" in lower,"eggs_seen":"egg" in lower,"brood_frames":float(brood.group(1)) if brood else 0,"stores_frames":float(stores.group(1)) if stores else 0,"notes":text}
