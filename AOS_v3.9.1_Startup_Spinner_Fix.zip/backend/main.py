from nicegui import ui
from aos.core.bootstrap import boot
from aos.ui.shell import render_app
from aos.ui.diagnostics import diagnostic_rows

boot()

@ui.page("/")
def index():
    render_app()

@ui.page("/diag")
def diag():
    ui.label("AOS Diagnostics").classes("text-h4")
    ui.table(
        columns=[
            {"name":"item","label":"Item","field":"item"},
            {"name":"value","label":"Value","field":"value"},
        ],
        rows=diagnostic_rows(),
        row_key="item",
    ).classes("w-full")

ui.run(title="AOS", host="127.0.0.1", port=8000, reload=False)
