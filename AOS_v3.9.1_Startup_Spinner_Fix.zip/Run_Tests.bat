@echo off
cd /d "%~dp0"
if not exist .venv call Install_AOS.bat
call .venv\Scripts\activate.bat
set PYTHONPATH=%CD%\backend
python scripts\validate_release.py
pause
