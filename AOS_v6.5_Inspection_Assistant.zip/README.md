# AOS v6.5 — Inspection Assistant

Adds adaptive inspection checklists and consistency warnings before staging drafts.
