@echo off
cd /d "%~dp0"
if not exist .venv call Install_AOS.bat
call .venv\Scripts\activate.bat
set PYTHONPATH=%CD%\backend
python -c "from aos.core.bootstrap import boot; boot(); from aos.services.data_portability_service import DataPortabilityService; s=DataPortabilityService(); print('JSON:', s.export_json()); print('SQLite:', s.export_sqlite_backup())"
echo.
echo Exports created in the exports folder.
pause
