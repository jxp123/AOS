from nicegui import ui
from aos.engines.digital_twin import apiary_layout, colony_workspace, trend_rows, inspection_focus

def _style_for(card):
    h = card.get("health", 0)
    if h >= 75:
        return "background:#ecfdf5;border:2px solid #10b981;"
    if h >= 50:
        return "background:#fffbeb;border:2px solid #f59e0b;"
    return "background:#fef2f2;border:2px solid #ef4444;"

def page():
    ui.label("Digital Twin").classes("text-h5")
    ui.label("Live operational representation of the apiary. Click any colony to open its workspace.").classes("text-subtitle1")

    holder = ui.column().classes("w-full")
    workspace = ui.column().classes("w-full")

    def open_workspace(code):
        workspace.clear()
        data = colony_workspace(code)
        colony = data.get("colony") or {}
        card = data.get("card") or {}
        conf = data.get("confidence") or {}

        with workspace:
            ui.separator()
            ui.label(f"{code} Workspace").classes("text-h5")
            with ui.row().classes("w-full"):
                with ui.card().style("min-width:220px;"):
                    ui.label("Health")
                    ui.label(f"{card.get('health', 0)}%").classes("text-h4")
                    ui.label(card.get("status_badge", ""))
                with ui.card().style("min-width:260px;"):
                    ui.label("Colony")
                    ui.label(colony.get("name", ""))
                    ui.label(f"{colony.get('type','')} / {colony.get('equipment','')}")
                with ui.card().style("min-width:260px;"):
                    ui.label("Queen")
                    qs = data.get("queens", [])
                    ui.label(", ".join([q.get("code","") for q in qs]) if qs else "Not linked")
                with ui.card().style("min-width:260px;"):
                    ui.label("Confidence")
                    ui.label(f"{conf.get('score',0)}%").classes("text-h4")

            ui.label("Smart inspection focus").classes("text-h6")
            with ui.card().classes("w-full"):
                for item in inspection_focus(code):
                    ui.label(f"✓ {item}")

            with ui.tabs().classes("w-full") as tabs:
                t_overview = ui.tab("Overview")
                t_timeline = ui.tab("Timeline")
                t_inspections = ui.tab("Inspections")
                t_trends = ui.tab("Trends")
                t_conf = ui.tab("Confidence")

            with ui.tab_panels(tabs, value=t_overview).classes("w-full"):
                with ui.tab_panel(t_overview):
                    ui.table(
                        columns=[{"name":"field","label":"Field","field":"field"},{"name":"value","label":"Value","field":"value"}],
                        rows=[
                            {"field":"Objective","value":colony.get("objective","")},
                            {"field":"Inspection status","value":card.get("inspection_status","")},
                            {"field":"Next action","value":card.get("next_action","")},
                            {"field":"Reason","value":card.get("reason","")},
                            {"field":"Latest inspection","value":card.get("latest_inspection","")},
                            {"field":"Brood frames","value":card.get("brood_frames","")},
                            {"field":"Stores frames","value":card.get("stores_frames","")},
                            {"field":"Notes","value":colony.get("notes","")},
                        ],
                        row_key="field",
                    ).classes("w-full")
                with ui.tab_panel(t_timeline):
                    ui.table(columns=[
                        {"name":"date","label":"Date","field":"date"},
                        {"name":"type","label":"Type","field":"type"},
                        {"name":"title","label":"Title","field":"title"},
                        {"name":"details","label":"Details","field":"details"}],
                        rows=data.get("timeline", []), row_key="title").classes("w-full")
                with ui.tab_panel(t_inspections):
                    ui.table(columns=[
                        {"name":"date","label":"Date","field":"date"},
                        {"name":"queen_seen","label":"Queen","field":"queen_seen"},
                        {"name":"eggs_seen","label":"Eggs","field":"eggs_seen"},
                        {"name":"brood_frames","label":"Brood","field":"brood_frames"},
                        {"name":"stores_frames","label":"Stores","field":"stores_frames"},
                        {"name":"bee_coverage_frames","label":"Bees","field":"bee_coverage_frames"},
                        {"name":"notes","label":"Notes","field":"notes"}],
                        rows=data.get("inspections", []), row_key="id").classes("w-full")
                with ui.tab_panel(t_trends):
                    ui.table(columns=[
                        {"name":"date","label":"Date","field":"date"},
                        {"name":"brood","label":"Brood","field":"brood"},
                        {"name":"stores","label":"Stores","field":"stores"},
                        {"name":"bees","label":"Bees","field":"bees"},
                        {"name":"queen_cells","label":"Queen Cells","field":"queen_cells"}],
                        rows=trend_rows(code), row_key="date").classes("w-full")
                with ui.tab_panel(t_conf):
                    ui.label(f"Confidence score: {conf.get('score',0)}%").classes("text-h6")
                    with ui.row().classes("w-full"):
                        with ui.card().style("min-width:320px;"):
                            ui.label("Evidence present")
                            for e in conf.get("evidence", []):
                                ui.label(f"✓ {e}")
                        with ui.card().style("min-width:320px;"):
                            ui.label("Missing / weaker evidence")
                            for e in conf.get("missing", []):
                                ui.label(f"• {e}")

    def render():
        holder.clear()
        layout = apiary_layout()
        with holder:
            for title, rows in [("Hives", layout["hives"]), ("Nucs", layout["nucs"]), ("Other", layout["other"])]:
                ui.label(title).classes("text-h6")
                with ui.row().classes("w-full"):
                    if not rows:
                        ui.label("None")
                    for c in rows:
                        with ui.card().style(f"width:210px; min-height:160px; {_style_for(c)}"):
                            ui.label(c["code"]).classes("text-h6")
                            ui.label(c.get("status_badge",""))
                            ui.label(f"Health {c.get('health',0)}%")
                            ui.label(f"Queen: {c.get('queen') or '—'}")
                            ui.label(f"Last: {c.get('latest_inspection')}")
                            ui.label(f"Next: {c.get('next_action')}")
                            ui.button("Open workspace", on_click=lambda code=c["code"]: open_workspace(code)).classes("w-full")

    ui.button("Refresh Digital Twin", on_click=render)
    render()
    workspace
