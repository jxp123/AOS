from nicegui import ui
from aos.engines.intelligence_platform import intelligence_summary

def page():
    ui.label("Intelligence Platform").classes("text-h5")
    data = intelligence_summary()
    with ui.row():
        for title, value in [("Colonies profiled", data["colonies_profiled"]), ("High risk", data["high_risk"])]:
            with ui.card():
                ui.label(title); ui.label(str(value)).classes("text-h5")
    ui.label("Predictive risks").classes("text-h6")
    ui.table(columns=[
        {"name":"code","label":"Code","field":"code"},
        {"name":"swarm_prediction","label":"Swarm","field":"swarm_prediction"},
        {"name":"queen_failure_prediction","label":"Queen Failure","field":"queen_failure_prediction"},
        {"name":"starvation_prediction","label":"Starvation","field":"starvation_prediction"},
        {"name":"disease_prediction","label":"Disease","field":"disease_prediction"},
        {"name":"memory","label":"Memory","field":"memory"},
        {"name":"recommendation","label":"Recommendation","field":"recommendation"},
    ], rows=data["risks"], row_key="code").classes("w-full")
    ui.label("Seasonal planner").classes("text-h6")
    ui.table(columns=[{"name":"seasonal_task","label":"Task","field":"seasonal_task"},{"name":"status","label":"Status","field":"status"}], rows=data["seasonal"], row_key="seasonal_task").classes("w-full")
    ui.label("Resource forecast").classes("text-h6")
    ui.table(columns=[{"name":"resource","label":"Resource","field":"resource"},{"name":"forecast","label":"Forecast","field":"forecast"},{"name":"reason","label":"Reason","field":"reason"}], rows=data["resources"], row_key="resource").classes("w-full")
