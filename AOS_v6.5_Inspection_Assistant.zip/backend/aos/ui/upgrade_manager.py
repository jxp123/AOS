from nicegui import ui
from aos.services.upgrade_service import UpgradeService

def page():
    ui.label("Upgrade Manager").classes("text-h5")
    ui.label("Prepare AOS for future upgrades by creating backups, exports and a health report.").classes("text-subtitle1")
    holder = ui.column().classes("w-full")

    def run():
        holder.clear()
        rows = UpgradeService().pre_upgrade_package()
        with holder:
            ui.table(columns=[
                {"name":"step","label":"Step","field":"step"},
                {"name":"status","label":"Status","field":"status"},
                {"name":"detail","label":"Detail","field":"detail"}],
                rows=rows, row_key="step").classes("w-full")
            ui.label("Keep the JSON export safe. Use it to re-import your data after installing a future release.")
    ui.button("Prepare Upgrade Package", on_click=run)
    run()
