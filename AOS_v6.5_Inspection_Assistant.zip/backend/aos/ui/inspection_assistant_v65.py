from nicegui import ui
from datetime import date
from aos.services.repository import Repository
from aos.services.field_inspection_service import FieldInspectionService
from aos.engines.inspection_assistant import adaptive_checklist, consistency_warnings

def page():
    ui.label("Inspection Assistant").classes("text-h5")
    repo = Repository()
    service = FieldInspectionService()
    options = {f"{c['code']} — {c['name']}": c["code"] for c in repo.list_apiary_entities(True)}
    id_map = {c["code"]: c["id"] for c in repo.list_apiary_entities(True)}
    selected = ui.select(options, label="Colony / Nuc").classes("w-full")
    holder = ui.column().classes("w-full")

    def start():
        holder.clear()
        code = selected.value
        if not code:
            ui.notify("Select colony", type="warning"); return
        with holder:
            ui.label(f"Adaptive checklist for {code}").classes("text-h6")
            for item in adaptive_checklist(code):
                ui.checkbox(item)
            ui.label("Record inspection").classes("text-h6")
            queen=ui.checkbox("Queen seen"); eggs=ui.checkbox("Eggs seen"); larvae=ui.checkbox("Larvae seen")
            qcells=ui.number("Queen cells", value=0, min=0)
            brood=ui.number("Brood frames", value=0, min=0, step=0.5)
            stores=ui.number("Stores frames", value=0, min=0, step=0.5)
            bees=ui.number("Bee coverage frames", value=0, min=0, step=0.5)
            notes=ui.textarea("Notes").classes("w-full")
            warning_holder=ui.column().classes("w-full")
            def review():
                warning_holder.clear()
                payload={"colony_id":id_map[code],"inspection_date":str(date.today()),"queen_seen":queen.value,"eggs_seen":eggs.value,"larvae_seen":larvae.value,"queen_cells":qcells.value,"brood_frames":brood.value,"stores_frames":stores.value,"bee_coverage_frames":bees.value,"temperament":"Unknown","notes":notes.value or ""}
                warns=consistency_warnings(payload)
                with warning_holder:
                    if warns:
                        ui.label("Warnings").classes("text-h6 text-negative")
                        for w in warns: ui.label(f"⚠ {w}")
                    else:
                        ui.label("No consistency warnings.").classes("text-positive")
                return payload
            def stage():
                payload=review()
                try:
                    draft_id, validation = service.stage_field_inspection(payload)
                    ui.notify(f"Draft staged #{draft_id}: {validation['status']}", type="positive")
                except Exception as e:
                    ui.notify(str(e), type="negative")
            ui.button("Review consistency", on_click=review)
            ui.button("Stage draft", on_click=stage)
            warning_holder
    ui.button("Start Assistant", on_click=start)
    holder
