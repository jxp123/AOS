from nicegui import ui
from aos.engines.daily_operations import daily_dashboard

def page():
    ui.label("Daily Apiary Operations").classes("text-h5")
    ui.label("Today's work, smart alerts, route, evidence quality and apiary map.").classes("text-subtitle1")
    holder = ui.column().classes("w-full")

    def render():
        holder.clear()
        data = daily_dashboard()
        with holder:
            with ui.row():
                for title, value in [
                    ("Apiary Priority", f"{data['apiary_priority_score']}/100"),
                    ("Overdue", data["overdue"]),
                    ("Due Today", data["due_today"]),
                    ("Due Soon", data["due_soon"]),
                    ("Route Items", data["route_count"]),
                    ("Alerts", data["alerts_count"]),
                    ("Visit Time", data["estimated_duration"]),
                ]:
                    with ui.card():
                        ui.label(title)
                        ui.label(str(value)).classes("text-h5")
            ui.label("Apiary Assistant").classes("text-h6")
            with ui.card().classes("w-full"):
                ui.label("Use the Apiary Assistant tab to ask: What should I inspect today? Which colonies worry you?")
            ui.label("Daily Briefing").classes("text-h6")
            with ui.card().classes("w-full"):
                ui.label(data["briefing"])
            ui.label("Inspection Route").classes("text-h6")
            ui.table(columns=[
                {"name":"priority","label":"Priority","field":"priority"},
                {"name":"code","label":"Code","field":"code"},
                {"name":"name","label":"Name","field":"name"},
                {"name":"inspection_status","label":"Inspection","field":"inspection_status"},
                {"name":"next_action","label":"Next Action","field":"next_action"},
                {"name":"reason","label":"Reason","field":"reason"},
            ], rows=data["route"], row_key="code").classes("w-full")
            ui.label("Smart Alerts").classes("text-h6")
            ui.table(columns=[
                {"name":"priority","label":"Priority","field":"priority"},
                {"name":"code","label":"Code","field":"code"},
                {"name":"alert","label":"Alert","field":"alert"},
                {"name":"reason","label":"Reason","field":"reason"},
            ], rows=data["alerts"], row_key="code").classes("w-full")
            ui.label("Evidence Scores").classes("text-h6")
            ui.table(columns=[
                {"name":"code","label":"Code","field":"code"},
                {"name":"name","label":"Name","field":"name"},
                {"name":"evidence_score","label":"Evidence %","field":"evidence_score"},
                {"name":"evidence","label":"Evidence","field":"evidence"},
            ], rows=data["evidence_scores"], row_key="code").classes("w-full")
            ui.label("Apiary Map / Layout List").classes("text-h6")
            ui.table(columns=[
                {"name":"position","label":"Position","field":"position"},
                {"name":"name","label":"Name","field":"name"},
                {"name":"type","label":"Type","field":"type"},
                {"name":"equipment","label":"Equipment","field":"equipment"},
                {"name":"status","label":"Status","field":"status"},
            ], rows=data["map"], row_key="position").classes("w-full")

    ui.button("Refresh Daily Operations", on_click=render)
    render()
