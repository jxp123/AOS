from nicegui import ui
from datetime import date
from aos.services.field_inspection_service import FieldInspectionService

def page():
    ui.label("Field Inspection Mode").classes("text-h5")
    ui.label("Fast inspection entry beside the hive. Records are staged as drafts first, then committed from Guided Inspection.").classes("text-subtitle1")

    service = FieldInspectionService()
    options = {row["label"]: row["id"] for row in service.colony_options()}

    state = {
        "colony_id": None,
        "inspection_date": str(date.today()),
        "queen_seen": False,
        "eggs_seen": False,
        "larvae_seen": False,
        "queen_cells": 0,
        "brood_frames": 0,
        "stores_frames": 0,
        "bee_coverage_frames": 0,
        "temperament": "Unknown",
        "notes": "",
    }

    step_holder = ui.column().classes("w-full")
    summary_holder = ui.column().classes("w-full")

    def update_summary():
        summary_holder.clear()
        quality = service.inspection_quality(state)
        rec = service.field_recommendation(state)
        with summary_holder:
            with ui.card().classes("w-full"):
                ui.label("Live inspection summary").classes("text-h6")
                ui.label(f"Evidence quality: {quality['score']}%")
                ui.label(f"Evidence: {quality['evidence']}")
                ui.label(f"Recommendation: {rec}")

    def render_step(step):
        step_holder.clear()
        update_summary()
        with step_holder:
            with ui.card().classes("w-full"):
                if step == 1:
                    ui.label("1. Select colony / nuc").classes("text-h6")
                    sel = ui.select(options, label="Colony/Nuc").classes("w-full")
                    d = ui.input("Date", value=state["inspection_date"]).classes("w-48")

                    def next_step():
                        if not sel.value:
                            ui.notify("Select colony/nuc", type="warning")
                            return
                        state["colony_id"] = sel.value
                        state["inspection_date"] = d.value
                        render_step(2)

                    ui.button("Next", on_click=next_step).classes("w-full")

                elif step == 2:
                    ui.label("2. Queen and brood evidence").classes("text-h6")
                    queen_seen = ui.checkbox("Queen seen", value=state["queen_seen"])
                    eggs = ui.checkbox("Eggs seen", value=state["eggs_seen"])
                    larvae = ui.checkbox("Larvae / open brood seen", value=state["larvae_seen"])

                    def next_step():
                        state["queen_seen"] = bool(queen_seen.value)
                        state["eggs_seen"] = bool(eggs.value)
                        state["larvae_seen"] = bool(larvae.value)
                        render_step(3)

                    with ui.row():
                        ui.button("Back", on_click=lambda: render_step(1))
                        ui.button("Next", on_click=next_step)

                elif step == 3:
                    ui.label("3. Frame counts").classes("text-h6")
                    brood = ui.number("Brood frames", value=state["brood_frames"], min=0, step=0.5).classes("w-full")
                    stores = ui.number("Stores frames", value=state["stores_frames"], min=0, step=0.5).classes("w-full")
                    bees = ui.number("Bee coverage frames", value=state["bee_coverage_frames"], min=0, step=0.5).classes("w-full")

                    def next_step():
                        state["brood_frames"] = float(brood.value or 0)
                        state["stores_frames"] = float(stores.value or 0)
                        state["bee_coverage_frames"] = float(bees.value or 0)
                        render_step(4)

                    with ui.row():
                        ui.button("Back", on_click=lambda: render_step(2))
                        ui.button("Next", on_click=next_step)

                elif step == 4:
                    ui.label("4. Risk signs and notes").classes("text-h6")
                    qcells = ui.number("Queen cells", value=state["queen_cells"], min=0).classes("w-full")
                    temperament = ui.select(["Calm", "OK", "Defensive", "Aggressive", "Unknown"], label="Temperament", value=state["temperament"]).classes("w-full")
                    notes = ui.textarea("Notes", value=state["notes"], placeholder="Supers, feed, queen cells, brood pattern, stores, disease signs.").classes("w-full")

                    def next_step():
                        state["queen_cells"] = int(qcells.value or 0)
                        state["temperament"] = temperament.value
                        state["notes"] = notes.value or ""
                        render_step(5)

                    with ui.row():
                        ui.button("Back", on_click=lambda: render_step(3))
                        ui.button("Review", on_click=next_step)

                elif step == 5:
                    ui.label("5. Review and stage").classes("text-h6")
                    quality = service.inspection_quality(state)
                    rec = service.field_recommendation(state)
                    ui.label(f"Evidence quality: {quality['score']}%")
                    ui.label(rec)
                    ui.table(
                        columns=[
                            {"name":"field","label":"Field","field":"field"},
                            {"name":"value","label":"Value","field":"value"},
                        ],
                        rows=[{"field": k, "value": str(v)} for k, v in state.items()],
                        row_key="field",
                    ).classes("w-full")

                    def stage():
                        try:
                            draft_id, validation = service.stage_field_inspection(state)
                            ui.notify(f"Draft staged #{draft_id}: {validation['status']}", type="positive")
                        except Exception as e:
                            ui.notify(str(e), type="negative")

                    with ui.row():
                        ui.button("Back", on_click=lambda: render_step(4))
                        ui.button("Stage Draft", on_click=stage)
                        ui.button("Start New Inspection", on_click=lambda: render_step(1))

    render_step(1)
    summary_holder
