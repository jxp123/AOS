from nicegui import ui
from aos.engines.field_operations import field_route, current_stop

def page():
    ui.label("Field Operations").classes("text-h5")
    ui.label("Route-first workflow for a real apiary visit.").classes("text-subtitle1")
    route = field_route()
    with ui.card().classes("w-full"):
        ui.label("Today's Route").classes("text-h6")
        ui.label(" → ".join([r["code"] for r in route]) if route else "No route required.")
    ui.table(columns=[
        {"name":"position","label":"#","field":"position"},
        {"name":"code","label":"Code","field":"code"},
        {"name":"status","label":"Status","field":"status"},
        {"name":"health","label":"Health","field":"health"},
        {"name":"primary_risk","label":"Top Risk","field":"primary_risk"},
        {"name":"focus","label":"Inspection Focus","field":"focus"},
        {"name":"actions","label":"Suggested Actions","field":"actions"},
    ], rows=route, row_key="position").classes("w-full")
    if route:
        stop = current_stop(0)
        ui.label("First stop").classes("text-h6")
        with ui.card().classes("w-full"):
            ui.label(f"{stop['code']} — {stop['name']}").classes("text-h5")
            ui.label(stop["focus"])
            ui.label(f"Suggested actions: {stop['actions']}")
