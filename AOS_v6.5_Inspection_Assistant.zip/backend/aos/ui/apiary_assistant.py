from nicegui import ui
from aos.engines.apiary_assistant import assistant_answer

def page():
    ui.label("Apiary Assistant").classes("text-h5")
    ui.label("Ask AOS operational questions. This assistant uses local AOS data and rule-based reasoning.").classes("text-subtitle1")

    question = ui.textarea(
        "Question",
        placeholder="What should I inspect today? Which colonies worry you? Which queens should I breed from?",
    ).classes("w-full")

    output = ui.column().classes("w-full")

    def ask():
        output.clear()
        result = assistant_answer(question.value or "")
        with output:
            with ui.card().classes("w-full"):
                ui.label("Answer").classes("text-h6")
                ui.textarea(value=result["answer"]).props("readonly autogrow").classes("w-full")
                ui.label(f"Confidence: {result['confidence']}")
                ui.label(f"Source: {result['source']}")

    with ui.row():
        ui.button("Ask AOS", on_click=ask)
        ui.button("Inspect Today", on_click=lambda: quick("What should I inspect today?"))
        ui.button("Risks", on_click=lambda: quick("Which colonies worry you?"))
        ui.button("Queens", on_click=lambda: quick("Which queens should I breed from?"))
        ui.button("Evidence", on_click=lambda: quick("Which colonies have weak evidence?"))

    def quick(text):
        question.value = text
        ask()

    ask()
