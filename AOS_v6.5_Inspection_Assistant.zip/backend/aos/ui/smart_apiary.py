from nicegui import ui
from aos.engines.smart_apiary import todays_mission, smart_colony_rows

def _risk_label(v):
    if v >= 70: return f"🔴 {v}%"
    if v >= 40: return f"🟡 {v}%"
    return f"🟢 {v}%"

def page():
    ui.label("Smart Apiary").classes("text-h5")
    ui.label("Risk scores and recommendations generated from the current AOS data.").classes("text-subtitle1")
    mission = todays_mission()
    with ui.row():
        for title, value in [("Priority colonies", mission["priority_count"]), ("Treatment follow-ups", mission["treatment_followups"]), ("Prime queens", mission["prime_queens"])]:
            with ui.card():
                ui.label(title); ui.label(str(value)).classes("text-h5")
    ui.label("Highest priorities").classes("text-h6")
    rows = mission["top_priorities"]
    ui.table(columns=[
        {"name":"code","label":"Code","field":"code"},
        {"name":"status_badge","label":"Status","field":"status_badge"},
        {"name":"health","label":"Health","field":"health"},
        {"name":"swarm_risk","label":"Swarm","field":"swarm_risk"},
        {"name":"queen_failure_risk","label":"Queen Failure","field":"queen_failure_risk"},
        {"name":"starvation_risk","label":"Starvation","field":"starvation_risk"},
        {"name":"disease_risk","label":"Disease","field":"disease_risk"},
        {"name":"recommendation","label":"Recommendation","field":"recommendation"},
    ], rows=rows, row_key="code").classes("w-full")
    ui.label("All colony risk scores").classes("text-h6")
    ui.table(columns=[
        {"name":"code","label":"Code","field":"code"},
        {"name":"name","label":"Name","field":"name"},
        {"name":"health","label":"Health","field":"health"},
        {"name":"swarm_risk","label":"Swarm","field":"swarm_risk"},
        {"name":"queen_failure_risk","label":"Queen Failure","field":"queen_failure_risk"},
        {"name":"starvation_risk","label":"Starvation","field":"starvation_risk"},
        {"name":"disease_risk","label":"Disease","field":"disease_risk"},
        {"name":"next_action","label":"Next Action","field":"next_action"},
    ], rows=smart_colony_rows(), row_key="code").classes("w-full")
