from nicegui import ui
from aos.engines.operations_centre import operations_centre_summary, one_click_actions_for
from aos.engines.timelines import colony_timeline

def _health_class(score):
    if score >= 75:
        return "background:#ecfdf5;border-color:#10b981;"
    if score >= 50:
        return "background:#fffbeb;border-color:#f59e0b;"
    return "background:#fef2f2;border-color:#ef4444;"

def page():
    ui.label("Operations Centre").classes("text-h5")
    ui.label("Interactive apiary overview: status, health, due inspections and next actions.").classes("text-subtitle1")

    holder = ui.column().classes("w-full")
    detail = ui.column().classes("w-full")

    def show_detail(code):
        detail.clear()
        summary = operations_centre_summary()
        card = next((c for c in summary["cards"] if c["code"] == code), None)
        if not card:
            ui.notify("Colony not found", type="warning")
            return
        with detail:
            ui.separator()
            ui.label(f"{card['code']} — {card['name']}").classes("text-h5")
            with ui.row().classes("w-full"):
                with ui.card().style("min-width:220px;"):
                    ui.label("Health").classes("text-subtitle2")
                    ui.label(f"{card['health']}%").classes("text-h4")
                    ui.label(card["status_badge"])
                with ui.card().style("min-width:260px;"):
                    ui.label("Queen").classes("text-subtitle2")
                    ui.label(card.get("queen") or "Not linked")
                    ui.label(card.get("queen_line") or "")
                with ui.card().style("min-width:260px;"):
                    ui.label("Latest inspection").classes("text-subtitle2")
                    ui.label(card.get("latest_inspection"))
                    ui.label(f"Brood: {card.get('brood_frames')} | Stores: {card.get('stores_frames')}")
                with ui.card().style("min-width:260px;"):
                    ui.label("Next action").classes("text-subtitle2")
                    ui.label(card.get("next_action"))
                    ui.label(card.get("reason"))

            ui.label("One-click actions").classes("text-h6")
            with ui.row():
                for action in one_click_actions_for(code):
                    ui.button(action, on_click=lambda a=action: ui.notify(f"{a} selected for {code}. Use the relevant workflow to complete it.", type="info"))

            ui.label("Timeline").classes("text-h6")
            ui.table(
                columns=[
                    {"name":"date","label":"Date","field":"date"},
                    {"name":"type","label":"Type","field":"type"},
                    {"name":"title","label":"Title","field":"title"},
                    {"name":"details","label":"Details","field":"details"},
                ],
                rows=colony_timeline(code),
                row_key="title",
            ).classes("w-full")

    def render():
        holder.clear()
        summary = operations_centre_summary()
        with holder:
            with ui.row():
                for title, value in [
                    ("Colonies", summary["colonies"]),
                    ("Red", summary["red"]),
                    ("Amber", summary["amber"]),
                    ("Green", summary["green"]),
                    ("Treatment Follow-ups", summary["treatment_followups"]),
                    ("Prime Queens", summary["prime_queens"]),
                ]:
                    with ui.card():
                        ui.label(title)
                        ui.label(str(value)).classes("text-h5")

            ui.label("Apiary Map").classes("text-h6")
            ui.label("Click a card to open details. Red/Amber/Green is shown with text as well as colour.").classes("text-caption")

            with ui.row().classes("w-full"):
                for c in summary["cards"]:
                    with ui.card().style(f"width:220px; min-height:180px; border:2px solid; {_health_class(c['health'])}"):
                        ui.label(c["code"]).classes("text-h6")
                        ui.label(c["name"])
                        ui.label(c["status_badge"])
                        ui.label(f"Health: {c['health']}%")
                        ui.label(f"Due: {c['inspection_status']}")
                        ui.label(f"Next: {c['next_action']}")
                        ui.button("Open", on_click=lambda code=c["code"]: show_detail(code)).classes("w-full")

            ui.label("Priority Table").classes("text-h6")
            ui.table(
                columns=[
                    {"name":"status_badge","label":"Status","field":"status_badge"},
                    {"name":"code","label":"Code","field":"code"},
                    {"name":"health","label":"Health","field":"health"},
                    {"name":"inspection_status","label":"Inspection","field":"inspection_status"},
                    {"name":"days_since","label":"Days","field":"days_since"},
                    {"name":"next_action","label":"Next Action","field":"next_action"},
                    {"name":"reason","label":"Reason","field":"reason"},
                ],
                rows=summary["cards"],
                row_key="code",
            ).classes("w-full")

    ui.button("Refresh Operations Centre", on_click=render)
    render()
    detail
