from nicegui import ui
from aos.core.settings import APP_VERSION
import importlib
import traceback

PAGES = [
    ("Daily Operations", "aos.ui.daily_operations", "page"),
    ("Apiary Assistant", "aos.ui.apiary_assistant", "page"),
    ("Apiary Brain", "aos.ui.brain", "page"),
    ("Operations", "aos.ui.operations", "page"),
    ("Inspection Workbench", "aos.ui.workbench", "page"),
    ("Inspection Wizard", "aos.ui.inspection_wizard", "page"),
    ("Inspection Scheduler", "aos.ui.scheduler", "page"),
    ("Natural Language", "aos.ui.natural_language", "page"),
    ("Guided Inspection", "aos.ui.guided", "page"),
    ("Records", "aos.ui.records", "page"),
    ("Feeding / Treatments", "aos.ui.feeding_treatments", "page"),
    ("Queen Breeding", "aos.ui.breeding_studio", "page"),
    ("Timelines", "aos.ui.timelines", "page"),
    ("Alerts", "aos.ui.alerts", "page"),
    ("Operations Log", "aos.ui.operations_log", "page"),
    ("System Health", "aos.ui.system_health", "page"),
    ("Database", "aos.ui.database_unification", "page"),
    ("Tests", "aos.ui.tests", "page"),
]

def render_app():
    ui.label("🐝 Apiary Operating System").classes("text-h4")
    ui.label(f"v{APP_VERSION} Startup Spinner Fix").classes("text-subtitle1")

    content = ui.column().classes("w-full")

    def load_page(title, module_name, function_name):
        content.clear()
        with content:
            try:
                ui.label(title).classes("text-h5")
                module = importlib.import_module(module_name)
                page_func = getattr(module, function_name)
                page_func()
            except Exception as e:
                ui.label("AOS page error").classes("text-h5 text-negative")
                ui.label(f"{title} failed to load.").classes("text-negative")
                ui.label(str(e)).classes("text-negative")
                tb = traceback.format_exc()
                ui.textarea("Diagnostic traceback", value=tb).props("readonly").classes("w-full")
                print(f"AOS PAGE ERROR — {title}: {e}")
                print(tb)

    with ui.card().classes("w-full"):
        ui.label("Navigation").classes("text-h6")
        with ui.row().classes("w-full"):
            for title, module_name, function_name in PAGES:
                ui.button(title, on_click=lambda t=title, m=module_name, f=function_name: load_page(t, m, f))

    load_page("Daily Operations", "aos.ui.daily_operations", "page")
