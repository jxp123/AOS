from nicegui import ui
from aos.services.repository import Repository
from aos.engines.digital_twin import colony_workspace, trend_rows, inspection_focus
from aos.engines.operations_centre import one_click_actions_for

def page():
    ui.label("Beekeeper Workspace").classes("text-h5")
    ui.label("Open a colony and work from one place: overview, inspections, queen, history and actions.").classes("text-subtitle1")
    repo = Repository()
    options = {f"{c['code']} — {c['name']}": c["code"] for c in repo.list_apiary_entities(True)}
    holder = ui.column().classes("w-full")
    selected = ui.select(options, label="Open colony / nuc").classes("w-full")
    def open_colony():
        holder.clear()
        code = selected.value
        if not code:
            ui.notify("Select a colony/nuc", type="warning"); return
        data = colony_workspace(code)
        colony = data.get("colony") or {}
        card = data.get("card") or {}
        conf = data.get("confidence") or {}
        with holder:
            ui.label(f"{code} — {colony.get('name','')}").classes("text-h5")
            with ui.row():
                for title, value in [("Health", f"{card.get('health',0)}%"), ("Inspection", card.get("inspection_status","")), ("Confidence", f"{conf.get('score',0)}%"), ("Queen", ", ".join([q.get("code","") for q in data.get("queens", [])]) or "Not linked")]:
                    with ui.card():
                        ui.label(title); ui.label(str(value)).classes("text-h6")
            ui.label("AI-style summary").classes("text-h6")
            with ui.card().classes("w-full"):
                for item in inspection_focus(code):
                    ui.label(f"✓ {item}")
            ui.label("Actions").classes("text-h6")
            with ui.row():
                for action in one_click_actions_for(code):
                    ui.button(action, on_click=lambda a=action: ui.notify(f"{a} selected for {code}", type="info"))
            with ui.tabs().classes("w-full") as tabs:
                t_overview = ui.tab("Overview"); t_history = ui.tab("History"); t_trends = ui.tab("Trends"); t_confidence = ui.tab("Confidence")
            with ui.tab_panels(tabs, value=t_overview).classes("w-full"):
                with ui.tab_panel(t_overview):
                    ui.table(columns=[{"name":"field","label":"Field","field":"field"},{"name":"value","label":"Value","field":"value"}],
                             rows=[{"field":k,"value":str(v)} for k,v in colony.items()], row_key="field").classes("w-full")
                with ui.tab_panel(t_history):
                    ui.table(columns=[{"name":"date","label":"Date","field":"date"},{"name":"type","label":"Type","field":"type"},{"name":"title","label":"Title","field":"title"},{"name":"details","label":"Details","field":"details"}],
                             rows=data.get("timeline", []), row_key="title").classes("w-full")
                with ui.tab_panel(t_trends):
                    ui.table(columns=[{"name":"date","label":"Date","field":"date"},{"name":"brood","label":"Brood","field":"brood"},{"name":"stores","label":"Stores","field":"stores"},{"name":"bees","label":"Bees","field":"bees"},{"name":"queen_cells","label":"Q Cells","field":"queen_cells"}],
                             rows=trend_rows(code), row_key="date").classes("w-full")
                with ui.tab_panel(t_confidence):
                    ui.label(f"Confidence: {conf.get('score',0)}%")
                    ui.label("Evidence present")
                    for e in conf.get("evidence", []): ui.label(f"✓ {e}")
                    ui.label("Missing/weaker evidence")
                    for e in conf.get("missing", []): ui.label(f"• {e}")
    ui.button("Open Workspace", on_click=open_colony)
    holder
