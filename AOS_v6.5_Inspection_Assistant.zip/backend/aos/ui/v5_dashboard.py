from nicegui import ui
from aos.engines.daily_operations import daily_dashboard
from aos.engines.brain import apiary_brain_state, brain_briefing
from aos.engines.operations import shift_briefing
from aos.engines.feeding_treatment_engine import feeding_treatment_summary
from aos.engines.breeding_engine import breeding_studio_summary
from aos.engines.operations_centre import operations_centre_summary

def _card(title, value, detail=""):
    with ui.card().classes("aos-card").style("min-width: 170px;"):
        ui.label(title).classes("text-subtitle2")
        ui.label(str(value)).classes("text-h5")
        if detail:
            ui.label(detail).classes("text-caption")

def page():
    data = daily_dashboard()
    brain = apiary_brain_state()
    feed = feeding_treatment_summary()
    breeding = breeding_studio_summary()
    centre = operations_centre_summary()

    ui.label("Today's Work").classes("text-h5")
    ui.label("One-glance operational overview for the apiary.").classes("text-subtitle1")

    with ui.row().classes("w-full"):
        _card("Priority Score", f"{data['apiary_priority_score']}/100", "Apiary Brain")
        _card("Overdue", data["overdue"], "inspections")
        _card("Due Today", data["due_today"], "inspections")
        _card("Route Items", data["route_count"], data["estimated_duration"])
        _card("Alerts", data["alerts_count"], "current")
        _card("Treatments Due", feed["follow_up_count"], "follow-ups")
        _card("Prime Queens", breeding["prime_candidates"], "breeding"),
        ("Red Colonies", centre["red"], "needs attention")

    ui.separator()

    with ui.row().classes("w-full"):
        with ui.card().classes("aos-card").style("flex: 1; min-width: 360px;"):
            ui.label("Daily Briefing").classes("text-h6")
            ui.label(brain_briefing())
            ui.label(shift_briefing())

        with ui.card().classes("aos-card").style("flex: 1; min-width: 360px;"):
            ui.label("Recommended Route").classes("text-h6")
            route_text = " → ".join([r["code"] for r in data["route"]]) if data["route"] else "No route required."
            ui.label(route_text)

    ui.label("Inspection Route").classes("text-h6")
    ui.table(
        columns=[
            {"name":"priority","label":"Priority","field":"priority"},
            {"name":"code","label":"Code","field":"code"},
            {"name":"name","label":"Name","field":"name"},
            {"name":"inspection_status","label":"Inspection","field":"inspection_status"},
            {"name":"next_action","label":"Next Action","field":"next_action"},
            {"name":"reason","label":"Reason","field":"reason"},
        ],
        rows=data["route"],
        row_key="code",
    ).classes("w-full")

    ui.label("Smart Alerts").classes("text-h6")
    ui.table(
        columns=[
            {"name":"priority","label":"Priority","field":"priority"},
            {"name":"code","label":"Code","field":"code"},
            {"name":"alert","label":"Alert","field":"alert"},
            {"name":"reason","label":"Reason","field":"reason"},
        ],
        rows=data["alerts"][:12],
        row_key="reason",
    ).classes("w-full")
