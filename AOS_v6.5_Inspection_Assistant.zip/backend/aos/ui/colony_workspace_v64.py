from nicegui import ui
from aos.services.repository import Repository
from aos.engines.digital_twin import colony_workspace, trend_rows, confidence_meter, inspection_focus
from aos.engines.intelligence_platform import predictive_risk_rows

def page():
    ui.label("Colony Workspace").classes("text-h5")
    repo = Repository()
    options = {f"{c['code']} — {c['name']}": c["code"] for c in repo.list_apiary_entities(True)}
    selected = ui.select(options, label="Colony / Nuc").classes("w-full")
    holder = ui.column().classes("w-full")

    def open_selected():
        holder.clear()
        code = selected.value
        if not code:
            ui.notify("Select a colony", type="warning"); return
        data = colony_workspace(code)
        colony = data.get("colony") or {}
        card = data.get("card") or {}
        conf = confidence_meter(code)
        risk = next((r for r in predictive_risk_rows() if r["code"] == code), {})
        with holder:
            ui.label(f"{code} — {colony.get('name','')}").classes("text-h5")
            with ui.row():
                for title, value in [("Health", f"{card.get('health',0)}%"), ("Confidence", f"{conf.get('score',0)}%"), ("Swarm", f"{risk.get('swarm_prediction',0)}%"), ("Queen failure", f"{risk.get('queen_failure_prediction',0)}%")]:
                    with ui.card():
                        ui.label(title); ui.label(value).classes("text-h6")
            with ui.card().classes("w-full"):
                ui.label("AI summary").classes("text-h6")
                for item in inspection_focus(code):
                    ui.label(f"✓ {item}")
            with ui.tabs().classes("w-full") as tabs:
                t_overview=ui.tab("Overview"); t_inspections=ui.tab("Inspections"); t_timeline=ui.tab("Timeline"); t_trends=ui.tab("Analytics"); t_conf=ui.tab("Confidence")
            with ui.tab_panels(tabs, value=t_overview).classes("w-full"):
                with ui.tab_panel(t_overview):
                    ui.table(columns=[{"name":"field","label":"Field","field":"field"},{"name":"value","label":"Value","field":"value"}], rows=[{"field":k,"value":str(v)} for k,v in colony.items()], row_key="field").classes("w-full")
                with ui.tab_panel(t_inspections):
                    ui.table(columns=[
                        {"name":"date","label":"Date","field":"date"},{"name":"queen_seen","label":"Queen","field":"queen_seen"},{"name":"eggs_seen","label":"Eggs","field":"eggs_seen"},{"name":"brood_frames","label":"Brood","field":"brood_frames"},{"name":"stores_frames","label":"Stores","field":"stores_frames"},{"name":"notes","label":"Notes","field":"notes"}], rows=data.get("inspections",[]), row_key="id").classes("w-full")
                with ui.tab_panel(t_timeline):
                    ui.table(columns=[{"name":"date","label":"Date","field":"date"},{"name":"type","label":"Type","field":"type"},{"name":"title","label":"Title","field":"title"},{"name":"details","label":"Details","field":"details"}], rows=data.get("timeline",[]), row_key="title").classes("w-full")
                with ui.tab_panel(t_trends):
                    ui.table(columns=[{"name":"date","label":"Date","field":"date"},{"name":"brood","label":"Brood","field":"brood"},{"name":"stores","label":"Stores","field":"stores"},{"name":"bees","label":"Bees","field":"bees"},{"name":"queen_cells","label":"Q Cells","field":"queen_cells"}], rows=trend_rows(code), row_key="date").classes("w-full")
                with ui.tab_panel(t_conf):
                    ui.label(f"Confidence score: {conf.get('score',0)}%")
                    ui.label("Evidence present")
                    for e in conf.get("evidence",[]): ui.label(f"✓ {e}")
                    ui.label("Missing / weaker evidence")
                    for e in conf.get("missing",[]): ui.label(f"• {e}")
    ui.button("Open Colony Workspace", on_click=open_selected)
    holder
