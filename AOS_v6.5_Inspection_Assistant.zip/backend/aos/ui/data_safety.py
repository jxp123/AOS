from nicegui import ui
from aos.services.data_portability_service import DataPortabilityService

def page():
    ui.label("Data Safety").classes("text-h5")
    ui.label("Export your AOS data before installing future releases, then re-import it afterwards.").classes("text-subtitle1")

    service = DataPortabilityService()
    export_holder = ui.column().classes("w-full")
    import_holder = ui.column().classes("w-full")
    result_holder = ui.column().classes("w-full")

    def refresh_exports():
        export_holder.clear()
        with export_holder:
            ui.label("Latest exports").classes("text-h6")
            ui.table(
                columns=[
                    {"name":"filename","label":"Filename","field":"filename"},
                    {"name":"size_bytes","label":"Size","field":"size_bytes"},
                    {"name":"modified","label":"Modified","field":"modified"},
                    {"name":"path","label":"Path","field":"path"},
                ],
                rows=service.latest_exports(),
                row_key="path",
            ).classes("w-full")

    def refresh_imports():
        import_holder.clear()
        with import_holder:
            ui.label("Available JSON imports").classes("text-h6")
            table = ui.table(
                columns=[
                    {"name":"filename","label":"Filename","field":"filename"},
                    {"name":"size_bytes","label":"Size","field":"size_bytes"},
                    {"name":"modified","label":"Modified","field":"modified"},
                    {"name":"path","label":"Path","field":"path"},
                ],
                rows=service.available_import_files(),
                row_key="path",
                selection="single",
            ).classes("w-full")

            def import_selected():
                result_holder.clear()
                if not table.selected:
                    ui.notify("Select a JSON import file first", type="warning")
                    return
                try:
                    imported = service.import_json(table.selected[0]["path"], mode="replace")
                    ui.notify("Import completed", type="positive")
                    with result_holder:
                        ui.label("Import completed").classes("text-positive text-h6")
                        ui.table(
                            columns=[
                                {"name":"table","label":"Table","field":"table"},
                                {"name":"rows","label":"Rows imported","field":"rows"},
                            ],
                            rows=[{"table": k, "rows": v} for k, v in imported.items()],
                            row_key="table",
                        ).classes("w-full")
                except Exception as e:
                    ui.notify(str(e), type="negative")
                    with result_holder:
                        ui.label(str(e)).classes("text-negative")

            ui.button("Import Selected JSON — Replace Current Data", color="red", on_click=import_selected)

    def export_json():
        try:
            path = service.export_json()
            ui.notify(f"JSON export created: {path}", type="positive")
            refresh_exports()
            refresh_imports()
        except Exception as e:
            ui.notify(str(e), type="negative")

    def export_db():
        try:
            path = service.export_sqlite_backup()
            ui.notify(f"SQLite backup created: {path}", type="positive")
            refresh_exports()
        except Exception as e:
            ui.notify(str(e), type="negative")

    with ui.card().classes("w-full"):
        ui.label("Before installing a new release").classes("text-h6")
        ui.label("Click both export buttons. Keep the exported JSON file safe. The JSON is what you should re-import into future versions.")
        with ui.row():
            ui.button("Export AOS Data JSON", on_click=export_json)
            ui.button("Export Full SQLite Backup", on_click=export_db)

    with ui.card().classes("w-full"):
        ui.label("After installing a new release").classes("text-h6")
        ui.label("Copy your JSON export into the new release's imports folder, then select it below and import.")
        refresh_imports()

    result_holder
    refresh_exports()
