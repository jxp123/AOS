from datetime import date, datetime
from aos.services.repository import Repository
from aos.engines.brain import apiary_brain_state
from aos.engines.scheduler import inspection_schedule
from aos.engines.daily_operations import smart_alerts, daily_dashboard
from aos.engines.feeding_treatment_engine import feeding_treatment_summary
from aos.engines.breeding_engine import breeding_studio_summary

def _parse_date(value):
    try:
        return datetime.fromisoformat(str(value)).date()
    except Exception:
        return None

def status_badge(days_since, inspection_status):
    if inspection_status == "Overdue":
        return "🔴 Overdue"
    if inspection_status in ["Due Today", "Due Soon"]:
        return "🟡 Due"
    if days_since == "" or days_since is None:
        return "🔴 No record"
    try:
        days = int(days_since)
        if days <= 7:
            return "🟢 Current"
        if days <= 10:
            return "🟡 Due"
        return "🔴 Overdue"
    except Exception:
        return "⚪ Unknown"

def colony_health_score(colony, brain_row, schedule_row, latest_inspection):
    score = 100
    if schedule_row.get("status") == "Overdue":
        score -= 25
    elif schedule_row.get("status") in ["Due Today", "Due Soon"]:
        score -= 10

    if brain_row.get("priority_score", 0) >= 80:
        score -= 25
    elif brain_row.get("priority_score", 0) >= 60:
        score -= 10

    if latest_inspection:
        if latest_inspection.get("queen_seen") != "Yes" and latest_inspection.get("eggs_seen") != "Yes":
            score -= 20
        try:
            if float(latest_inspection.get("stores_frames") or 0) <= 1:
                score -= 10
        except Exception:
            pass
        try:
            if int(latest_inspection.get("queen_cells") or 0) > 0:
                score -= 15
        except Exception:
            pass
    else:
        score -= 25

    if "swarm" in (colony.get("notes", "") + " " + colony.get("objective", "")).lower():
        score -= 10
    return max(0, min(100, int(score)))

def colony_cards():
    repo = Repository()
    latest = repo.latest_inspection_by_colony()
    brain = {r["code"]: r for r in apiary_brain_state()["colonies"]}
    schedule = {r["code"]: r for r in inspection_schedule()}
    queens = {q.get("current_colony"): q for q in repo.list_queens() if q.get("current_colony")}

    rows = []
    for c in repo.list_apiary_entities(True):
        b = brain.get(c["code"], {})
        s = schedule.get(c["code"], {})
        li = latest.get(c["code"], {})
        q = queens.get(c["code"], {})
        health = colony_health_score(c, b, s, li)
        rows.append({
            "code": c["code"],
            "name": c["name"],
            "type": c["type"],
            "equipment": c["equipment"],
            "health": health,
            "status_badge": status_badge(s.get("days_since"), s.get("status")),
            "inspection_status": s.get("status", "Unknown"),
            "days_since": s.get("days_since", ""),
            "priority_score": b.get("priority_score", 0),
            "next_action": b.get("next_action", "Monitor"),
            "reason": b.get("evidence", s.get("reason", "")),
            "queen": q.get("code", ""),
            "queen_line": q.get("line", ""),
            "latest_inspection": li.get("date", "Never"),
            "brood_frames": li.get("brood_frames", ""),
            "stores_frames": li.get("stores_frames", ""),
            "queen_seen": li.get("queen_seen", ""),
            "eggs_seen": li.get("eggs_seen", ""),
        })
    rows.sort(key=lambda r: (0 if r["status_badge"].startswith("🔴") else 1 if r["status_badge"].startswith("🟡") else 2, -r["priority_score"], r["code"]))
    return rows

def one_click_actions_for(code):
    cards = {c["code"]: c for c in colony_cards()}
    c = cards.get(code)
    if not c:
        return []
    actions = ["Inspect", "Add note"]
    if c["status_badge"].startswith("🔴") or c["status_badge"].startswith("🟡"):
        actions.insert(0, "Start inspection")
    try:
        stores = float(c.get("stores_frames") or 0)
        if stores <= 1:
            actions.append("Feed")
    except Exception:
        pass
    if "Hive" in c.get("type", "") and c.get("health", 0) >= 70:
        actions.append("Check super space")
    if c.get("queen_seen") != "Yes" and c.get("eggs_seen") != "Yes":
        actions.append("Queen check")
    return actions

def operations_centre_summary():
    cards = colony_cards()
    dashboard = daily_dashboard()
    feed = feeding_treatment_summary()
    breeding = breeding_studio_summary()
    return {
        "date": str(date.today()),
        "colonies": len(cards),
        "red": len([c for c in cards if c["status_badge"].startswith("🔴")]),
        "amber": len([c for c in cards if c["status_badge"].startswith("🟡")]),
        "green": len([c for c in cards if c["status_badge"].startswith("🟢")]),
        "due_route": dashboard.get("route", []),
        "alerts": smart_alerts(),
        "treatment_followups": feed.get("follow_up_count", 0),
        "prime_queens": breeding.get("prime_candidates", 0),
        "cards": cards,
    }
