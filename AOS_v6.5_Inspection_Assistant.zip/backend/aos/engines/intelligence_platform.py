from datetime import date
from aos.services.repository import Repository
from aos.engines.operations_centre import colony_cards
from aos.engines.digital_twin import confidence_meter
from aos.engines.daily_operations import smart_alerts
from aos.engines.feeding_treatment_engine import feeding_treatment_summary

def _n(value):
    try:
        return float(value or 0)
    except Exception:
        return 0.0

def colony_memory_profiles():
    repo = Repository()
    inspections = repo.list_inspections()
    rows = []
    for c in repo.list_apiary_entities(True):
        history = [i for i in inspections if i.get("colony") == c["code"]]
        brood_values = [_n(i.get("brood_frames")) for i in history if _n(i.get("brood_frames")) > 0]
        stores_values = [_n(i.get("stores_frames")) for i in history if _n(i.get("stores_frames")) > 0]
        qcell_events = len([i for i in history if _n(i.get("queen_cells")) > 0])
        temperament_notes = " ".join([i.get("temperament","") + " " + i.get("notes","") for i in history]).lower()
        profile = []
        if brood_values and sum(brood_values)/len(brood_values) >= 6:
            profile.append("strong brood producer")
        if stores_values and sum(stores_values)/len(stores_values) <= 2:
            profile.append("stores often low")
        if qcell_events:
            profile.append("queen-cell / swarm-watch history")
        if "defensive" in temperament_notes or "aggressive" in temperament_notes:
            profile.append("temperament watch")
        if not profile:
            profile.append("insufficient behavioural history")
        rows.append({
            "code": c["code"], "name": c["name"], "inspections": len(history),
            "avg_brood": round(sum(brood_values)/len(brood_values), 1) if brood_values else 0,
            "avg_stores": round(sum(stores_values)/len(stores_values), 1) if stores_values else 0,
            "queen_cell_events": qcell_events,
            "memory": ", ".join(profile),
        })
    return rows

def predictive_risk_rows():
    cards = colony_cards()
    memories = {m["code"]: m for m in colony_memory_profiles()}
    rows = []
    for c in cards:
        m = memories.get(c["code"], {})
        conf = confidence_meter(c["code"])
        swarm = 15 + (25 if c.get("status_badge","").startswith("🔴") else 0) + (20 if m.get("queen_cell_events",0) else 0)
        queen = 15 + (35 if c.get("queen_seen") != "Yes" and c.get("eggs_seen") != "Yes" else 0) + (10 if conf.get("score",0) < 50 else 0)
        starvation = 10 + (50 if _n(c.get("stores_frames")) <= 1 else 0) + (10 if "stores often low" in m.get("memory","") else 0)
        disease = 10 + (10 if c.get("health",100) < 60 else 0)
        rows.append({
            "code": c["code"], "name": c["name"],
            "swarm_prediction": min(100, int(swarm)),
            "queen_failure_prediction": min(100, int(queen)),
            "starvation_prediction": min(100, int(starvation)),
            "disease_prediction": min(100, int(disease)),
            "memory": m.get("memory",""),
            "recommendation": c.get("next_action","Monitor"),
        })
    rows.sort(key=lambda r: max(r["swarm_prediction"], r["queen_failure_prediction"], r["starvation_prediction"], r["disease_prediction"]), reverse=True)
    return rows

def seasonal_planner():
    month = date.today().month
    if month in [3,4]:
        tasks = ["spring build-up", "feed if stores are low", "replace winter losses", "prepare supers"]
    elif month in [5,6,7]:
        tasks = ["swarm control", "super management", "queen rearing", "monitor nectar flow", "inspect every 7 days"]
    elif month in [8,9]:
        tasks = ["varroa treatment", "reduce entrances", "assess winter stores", "feed for winter"]
    else:
        tasks = ["winter checks", "equipment repair", "plan queen replacement", "review records"]
    return [{"seasonal_task": t, "status": "Review"} for t in tasks]

def resource_forecast():
    colonies = len(Repository().list_apiary_entities(True))
    feed = feeding_treatment_summary()
    return [
        {"resource": "Sugar / syrup", "forecast": f"{max(5, colonies // 2)} kg reserve suggested", "reason": "Active colonies and nucs"},
        {"resource": "Spare frames", "forecast": f"{max(10, colonies)} frames", "reason": "Growth, nuc transfers and supering"},
        {"resource": "Supers", "forecast": "Keep 2–4 spare supers available", "reason": "Production colonies may need space quickly"},
        {"resource": "Treatment stock", "forecast": "Check varroa treatment availability", "reason": f"{feed.get('treatment_count',0)} treatment records in AOS"},
    ]

def intelligence_summary():
    risks = predictive_risk_rows()
    return {
        "date": str(date.today()),
        "colonies_profiled": len(risks),
        "high_risk": len([r for r in risks if max(r["swarm_prediction"], r["queen_failure_prediction"], r["starvation_prediction"], r["disease_prediction"]) >= 70]),
        "alerts": smart_alerts(),
        "memory": colony_memory_profiles(),
        "risks": risks,
        "seasonal": seasonal_planner(),
        "resources": resource_forecast(),
    }
