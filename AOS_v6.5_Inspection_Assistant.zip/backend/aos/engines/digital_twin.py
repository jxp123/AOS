from aos.engines.operations_centre import colony_cards
from aos.services.repository import Repository
from aos.engines.timelines import colony_timeline

def _num(value):
    try:
        return float(value or 0)
    except Exception:
        return 0.0

def apiary_layout():
    cards = colony_cards()
    return {
        "hives": [c for c in cards if c["code"].startswith("H")],
        "nucs": [c for c in cards if c["code"].startswith("N")],
        "other": [c for c in cards if not c["code"].startswith(("H", "N"))],
    }

def confidence_meter(code):
    repo = Repository()
    latest = repo.latest_inspection_by_colony().get(code)
    if not latest:
        return {"score": 0, "evidence": ["No inspection recorded"], "missing": ["Full inspection"]}

    score = 0
    evidence = []
    missing = []

    checks = [
        ("queen_seen", "Yes", 18, "Queen seen", "Queen not seen"),
        ("eggs_seen", "Yes", 20, "Eggs seen", "Eggs not recorded"),
        ("larvae_seen", "Yes", 10, "Larvae/open brood seen", "Larvae not recorded"),
    ]
    for key, expected, points, ok, miss in checks:
        if latest.get(key) == expected:
            score += points
            evidence.append(ok)
        else:
            missing.append(miss)

    for key, points, ok, miss in [
        ("brood_frames", 16, "Brood measured", "Brood frames missing"),
        ("stores_frames", 16, "Stores measured", "Stores frames missing"),
        ("bee_coverage_frames", 10, "Bee coverage measured", "Bee coverage missing"),
    ]:
        if _num(latest.get(key)) > 0:
            score += points
            evidence.append(ok)
        else:
            missing.append(miss)

    if latest.get("notes"):
        score += 10
        evidence.append("Notes recorded")
    else:
        missing.append("Notes missing")

    return {"score": min(score, 100), "evidence": evidence, "missing": missing}

def colony_workspace(code):
    repo = Repository()
    colony = next((c for c in repo.list_apiary_entities(True) if c["code"] == code), None)
    if not colony:
        colony = next((c for c in repo.list_colonies() if c["code"] == code), None)
    card = {c["code"]: c for c in colony_cards()}.get(code, {})
    queens = [q for q in repo.list_queens() if q.get("current_colony") == code]
    inspections = [i for i in repo.list_inspections() if i.get("colony") == code]
    return {
        "colony": colony,
        "card": card,
        "queens": queens,
        "inspections": inspections,
        "timeline": colony_timeline(code),
        "confidence": confidence_meter(code),
    }

def trend_rows(code):
    repo = Repository()
    rows = sorted([i for i in repo.list_inspections() if i.get("colony") == code], key=lambda r: r.get("date") or "")
    return [
        {
            "date": r.get("date", ""),
            "brood": _num(r.get("brood_frames")),
            "stores": _num(r.get("stores_frames")),
            "bees": _num(r.get("bee_coverage_frames")),
            "queen_cells": _num(r.get("queen_cells")),
        }
        for r in rows
    ]

def inspection_focus(code):
    ws = colony_workspace(code)
    card = ws.get("card", {})
    confidence = ws.get("confidence", {})
    focus = []
    if card.get("inspection_status") in ["Overdue", "Due Today", "Due Soon"]:
        focus.append(f"Inspection status: {card.get('inspection_status')}.")
    if "Queen not seen" in confidence.get("missing", []) and "Eggs not recorded" in confidence.get("missing", []):
        focus.append("Confirm queen status first: queen/eggs evidence is weak.")
    if _num(card.get("stores_frames")) <= 1:
        focus.append("Check stores carefully; last record suggests low stores.")
    if card.get("health", 100) < 60:
        focus.append("Health score is low: inspect brood pattern, disease signs and queen status.")
    if not focus:
        focus.append("Routine inspection: confirm queen status, brood, stores, space and temperament.")
    return focus
