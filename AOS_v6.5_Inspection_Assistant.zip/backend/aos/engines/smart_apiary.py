from aos.engines.operations_centre import colony_cards
from aos.engines.digital_twin import inspection_focus
from aos.engines.daily_operations import smart_alerts
from aos.engines.feeding_treatment_engine import feeding_treatment_summary
from aos.engines.breeding_engine import breeding_studio_summary

def _risk_from_card(card):
    health = int(card.get("health") or 0)
    status = card.get("status_badge","")
    q_seen = card.get("queen_seen","")
    eggs = card.get("eggs_seen","")
    stores = float(card.get("stores_frames") or 0) if str(card.get("stores_frames","")).replace(".","",1).isdigit() else 0
    swarm = 20
    queen = 15
    starvation = 15
    disease = 10
    if status.startswith("🔴"):
        swarm += 20; queen += 15; starvation += 10
    if health < 60:
        swarm += 10; queen += 15; starvation += 10; disease += 10
    if q_seen != "Yes" and eggs != "Yes":
        queen += 45
    if stores <= 1:
        starvation += 45
    return {
        "swarm_risk": min(100, swarm),
        "queen_failure_risk": min(100, queen),
        "starvation_risk": min(100, starvation),
        "disease_risk": min(100, disease),
    }

def smart_colony_rows():
    rows = []
    for c in colony_cards():
        risk = _risk_from_card(c)
        recs = inspection_focus(c["code"])
        rows.append({**c, **risk, "recommendation": " ".join(recs)})
    rows.sort(key=lambda r: (r["swarm_risk"] + r["queen_failure_risk"] + r["starvation_risk"] + r["disease_risk"]), reverse=True)
    return rows

def todays_mission():
    rows = smart_colony_rows()
    high = [r for r in rows if max(r["swarm_risk"], r["queen_failure_risk"], r["starvation_risk"], r["disease_risk"]) >= 60]
    feed = feeding_treatment_summary()
    breed = breeding_studio_summary()
    return {
        "priority_count": len(high),
        "top_priorities": high[:8],
        "alerts": smart_alerts()[:12],
        "treatment_followups": feed.get("follow_up_count",0),
        "prime_queens": breed.get("prime_candidates",0),
        "all_colonies": rows,
    }
