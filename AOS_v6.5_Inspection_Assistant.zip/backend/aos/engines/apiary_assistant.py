from aos.engines.brain import apiary_brain_state, brain_briefing
from aos.engines.operations import todays_work, shift_briefing
from aos.engines.scheduler import inspection_schedule
from aos.engines.daily_operations import smart_alerts, latest_evidence_scores
from aos.engines.breeding_engine import breeding_studio_summary
from aos.engines.feeding_treatment_engine import feeding_treatment_summary
from aos.services.repository import Repository

def _contains(text, words):
    t = (text or "").lower()
    return any(w in t for w in words)

def _top_priorities(limit=8):
    rows = apiary_brain_state()["colonies"]
    return rows[:limit]

def _format_rows(rows, fields):
    if not rows:
        return "No matching records."
    lines = []
    for row in rows:
        parts = [f"{field}: {row.get(field, '')}" for field in fields]
        lines.append(" | ".join(parts))
    return "\n".join(lines)

def assistant_answer(question):
    q = (question or "").strip()
    lower = q.lower()
    repo = Repository()

    if not q:
        return {
            "answer": "Ask a question such as: What should I inspect today? Which colonies are overdue? Which queens should I breed from?",
            "confidence": "High",
            "source": "Assistant prompt guidance",
        }

    if _contains(lower, ["inspect today", "inspection today", "overdue", "due today", "what should i inspect", "inspect"]):
        work = todays_work()
        sched = [r for r in inspection_schedule() if r["status"] in ["Overdue", "Due Today", "Due Soon"]]
        return {
            "answer": (
                f"{shift_briefing()}\n\n"
                "Inspection queue:\n"
                + _format_rows(sched, ["code", "status", "days_since", "reason"])
            ),
            "confidence": "High",
            "source": "Inspection scheduler + operations engine",
        }

    if _contains(lower, ["worry", "risk", "priority", "problem", "concern"]):
        top = _top_priorities(10)
        return {
            "answer": (
                f"{brain_briefing()}\n\nHighest priorities:\n"
                + _format_rows(top, ["code", "priority_score", "inspection_status", "next_action", "evidence"])
            ),
            "confidence": "High",
            "source": "Apiary Brain",
        }

    if _contains(lower, ["queen", "breed", "breeding", "genetic", "line"]):
        summary = breeding_studio_summary()
        return {
            "answer": (
                f"Queens recorded: {summary['queen_count']}. Evaluated queens: {summary['evaluated_queens']}. "
                f"Prime candidates: {summary['prime_candidates']}. Possible candidates: {summary['possible_candidates']}.\n\n"
                "Queen ranking:\n"
                + _format_rows(summary["scores"], ["queen_code", "line", "current_colony", "breeding_score", "recommendation"])
            ),
            "confidence": "Medium" if summary["evaluated_queens"] == 0 else "High",
            "source": "Queen Breeding Studio",
        }

    if _contains(lower, ["feed", "feeding", "syrup", "fondant", "treatment", "varroa", "medicine"]):
        summary = feeding_treatment_summary()
        return {
            "answer": (
                f"Feeding records: {summary['feeding_count']}. Treatment records: {summary['treatment_count']}. "
                f"Follow-ups due: {summary['follow_up_count']}. Feeding reviews: {summary['feeding_review_count']}.\n\n"
                "Alerts:\n"
                + _format_rows(summary["alerts"], ["priority", "colony_code", "type", "reason", "date"])
            ),
            "confidence": "High",
            "source": "Feeding / Treatments engine",
        }

    if _contains(lower, ["evidence", "confidence", "data quality", "weak"]):
        rows = latest_evidence_scores()
        return {
            "answer": "Weakest evidence records:\n" + _format_rows(rows[:10], ["code", "evidence_score", "evidence"]),
            "confidence": "High",
            "source": "Evidence scoring",
        }

    if _contains(lower, ["summary", "briefing", "today", "plan"]):
        work = todays_work()
        alerts = smart_alerts()[:10]
        return {
            "answer": (
                f"{brain_briefing()}\n{shift_briefing()}\n"
                f"Estimated visit: {work.get('estimated_duration', 'unknown')}.\n\n"
                "Current alerts:\n"
                + _format_rows(alerts, ["priority", "code", "alert", "reason"])
            ),
            "confidence": "High",
            "source": "Daily Operations + Apiary Brain",
        }

    # Try direct colony code lookup
    codes = {c["code"].lower(): c for c in repo.list_apiary_entities(True)}
    matched = None
    for code, colony in codes.items():
        if code in lower:
            matched = colony
            break
    if matched:
        brain = next((r for r in apiary_brain_state()["colonies"] if r["code"] == matched["code"]), {})
        inspections = [i for i in repo.list_inspections() if i.get("colony") == matched["code"]][:5]
        return {
            "answer": (
                f"{matched['code']} — {matched['name']}.\n"
                f"Type/equipment: {matched['type']} / {matched['equipment']}.\n"
                f"Objective: {matched.get('objective','')}.\n"
                f"Brain priority: {brain.get('priority_score','')}.\n"
                f"Inspection status: {brain.get('inspection_status','')}.\n"
                f"Next action: {brain.get('next_action','')}.\n\n"
                "Recent inspections:\n"
                + _format_rows(inspections, ["date", "queen_seen", "eggs_seen", "brood_frames", "stores_frames", "notes"])
            ),
            "confidence": "High",
            "source": "Colony record + Apiary Brain + inspections",
        }

    return {
        "answer": (
            "I could not match that question to a specific AOS workflow yet.\n\n"
            "Try asking:\n"
            "- What should I inspect today?\n"
            "- Which colonies worry you?\n"
            "- Which queens should I breed from?\n"
            "- Which colonies have weak evidence?\n"
            "- What feeding or treatment follow-ups are due?\n"
            "- Tell me about H16."
        ),
        "confidence": "Low",
        "source": "Fallback",
    }
