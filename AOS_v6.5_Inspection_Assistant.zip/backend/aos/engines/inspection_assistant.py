from aos.engines.intelligence_platform import predictive_risk_rows
from aos.engines.digital_twin import inspection_focus

def adaptive_checklist(code):
    risk = next((r for r in predictive_risk_rows() if r["code"] == code), {})
    checks = []
    if risk.get("swarm_prediction",0) >= 50:
        checks += ["Check queen cells", "Check space / supers", "Assess split or swarm control"]
    if risk.get("queen_failure_prediction",0) >= 50:
        checks += ["Confirm queen", "Look for eggs", "Check brood pattern"]
    if risk.get("starvation_prediction",0) >= 50:
        checks += ["Assess stores", "Consider feed", "Check robbing pressure"]
    checks += ["Record brood frames", "Record stores frames", "Record bee coverage", "Record temperament", "Add notes"]
    return list(dict.fromkeys(checks))

def consistency_warnings(payload):
    warnings = []
    if payload.get("eggs_seen") and not payload.get("queen_seen"):
        warnings.append("Eggs recorded without queen seen. This may be correct, but confirm before committing.")
    if float(payload.get("brood_frames") or 0) >= 6 and float(payload.get("stores_frames") or 0) <= 1:
        warnings.append("Strong brood with low stores: consider feeding or adding stores.")
    if int(payload.get("queen_cells") or 0) > 0 and "swarm" not in (payload.get("notes") or "").lower():
        warnings.append("Queen cells recorded but no swarm action/note entered.")
    return warnings
