from aos.engines.smart_apiary import smart_colony_rows
from aos.engines.operations_centre import one_click_actions_for

def field_route():
    rows = smart_colony_rows()
    due = [r for r in rows if r.get("status_badge","").startswith(("🔴","🟡"))]
    if not due:
        due = rows[:5]
    return [
        {
            "position": i + 1,
            "code": r["code"],
            "name": r["name"],
            "status": r["status_badge"],
            "health": r["health"],
            "primary_risk": max(r["swarm_risk"], r["queen_failure_risk"], r["starvation_risk"], r["disease_risk"]),
            "focus": r["recommendation"],
            "actions": ", ".join(one_click_actions_for(r["code"])),
        }
        for i, r in enumerate(due)
    ]

def current_stop(index=0):
    route = field_route()
    if not route:
        return None
    index = max(0, min(index, len(route)-1))
    return route[index]
