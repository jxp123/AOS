from datetime import datetime
from aos.core.settings import SCHEMA_VERSION, DATA_DIR, EXPORT_DIR, BACKUP_DIR, LOG_DIR
from aos.core.baseline import BASELINE_COLONIES, BASELINE_QUEENS, BASELINE_EQUIPMENT
from aos.db.session import init_db, session_scope
from aos.db.models import Colony, Queen, Equipment, SystemMeta, AuditLog
def boot():
    from aos.services.system_health_service import SystemHealthService
    from aos.core.settings import IMPORT_DIR
    for folder in [DATA_DIR, EXPORT_DIR, IMPORT_DIR, BACKUP_DIR, LOG_DIR]:
        folder.mkdir(exist_ok=True)
    init_db()
    try:
        SystemHealthService().create_startup_backup()
    except Exception:
        pass
    with session_scope() as s:
        meta = s.query(SystemMeta).filter_by(key="schema_version").first()
        if not meta:
            s.add(SystemMeta(key="schema_version", value=SCHEMA_VERSION))
        else:
            meta.value = SCHEMA_VERSION
        for c in BASELINE_COLONIES:
            if not s.query(Colony).filter_by(code=c[0]).first():
                s.add(Colony(code=c[0], name=c[1], colony_type=c[2], equipment=c[3], objective=c[4], status=c[5], notes=c[6]))
        for q in BASELINE_QUEENS:
            if not s.query(Queen).filter_by(code=q[0]).first():
                s.add(Queen(code=q[0], name=q[1], line=q[2], source=q[3], current_colony_code=q[4], status=q[5], evidence_status=q[6], notes=q[7]))
        for e in BASELINE_EQUIPMENT:
            if not s.query(Equipment).filter_by(code=e[0]).first():
                s.add(Equipment(code=e[0], name=e[1], type=e[2], current_location=e[3], compatible_with=e[4], status=e[5], notes=e[6]))
        s.add(AuditLog(date=str(datetime.now().replace(microsecond=0)), action="BOOT", details="AOS v3.1 booted"))
        s.commit()
