from datetime import datetime
import shutil
from aos.core.settings import DB_PATH, BACKUP_DIR, EXPORT_DIR
from aos.services.data_portability_service import DataPortabilityService
from aos.services.system_health_service import SystemHealthService

class UpgradeService:
    def pre_upgrade_package(self):
        BACKUP_DIR.mkdir(exist_ok=True)
        EXPORT_DIR.mkdir(exist_ok=True)
        stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        results = []

        if DB_PATH.exists():
            backup = BACKUP_DIR / f"aos_pre_upgrade_{stamp}.db"
            shutil.copy2(DB_PATH, backup)
            results.append({"step":"SQLite backup", "status":"PASS", "detail":str(backup)})
        else:
            results.append({"step":"SQLite backup", "status":"SKIP", "detail":"No database found"})

        try:
            json_export = DataPortabilityService().export_json()
            results.append({"step":"JSON export", "status":"PASS", "detail":str(json_export)})
        except Exception as e:
            results.append({"step":"JSON export", "status":"FAIL", "detail":str(e)})

        try:
            report = SystemHealthService().health_report()
            results.append({"step":"Health check", "status":report.get("status","UNKNOWN"), "detail":"Health report generated"})
        except Exception as e:
            results.append({"step":"Health check", "status":"FAIL", "detail":str(e)})
        return results
