from datetime import date
from aos.services.repository import Repository
from aos.services.draft_service import DraftService

class FieldInspectionService:
    def colony_options(self):
        return [
            {
                "id": c["id"],
                "code": c["code"],
                "label": f"{c['code']} — {c['name']} ({c['type']}, {c['equipment']})",
                "type": c["type"],
                "equipment": c["equipment"],
            }
            for c in Repository().list_apiary_entities(True)
        ]

    def stage_field_inspection(self, payload):
        return DraftService().stage({
            "colony_id": payload.get("colony_id"),
            "inspection_date": payload.get("inspection_date") or str(date.today()),
            "queen_seen": bool(payload.get("queen_seen")),
            "eggs_seen": bool(payload.get("eggs_seen")),
            "larvae_seen": bool(payload.get("larvae_seen")),
            "queen_cells": int(payload.get("queen_cells") or 0),
            "brood_frames": float(payload.get("brood_frames") or 0),
            "stores_frames": float(payload.get("stores_frames") or 0),
            "bee_coverage_frames": float(payload.get("bee_coverage_frames") or 0),
            "temperament": payload.get("temperament") or "Unknown",
            "notes": payload.get("notes") or "",
        })

    def inspection_quality(self, payload):
        score = 0
        evidence = []
        if payload.get("queen_seen"):
            score += 15; evidence.append("queen seen")
        if payload.get("eggs_seen"):
            score += 20; evidence.append("eggs seen")
        if payload.get("larvae_seen"):
            score += 10; evidence.append("larvae/open brood")
        if float(payload.get("brood_frames") or 0) > 0:
            score += 15; evidence.append("brood measured")
        if float(payload.get("stores_frames") or 0) > 0:
            score += 15; evidence.append("stores measured")
        if float(payload.get("bee_coverage_frames") or 0) > 0:
            score += 10; evidence.append("bee coverage measured")
        if payload.get("temperament") and payload.get("temperament") != "Unknown":
            score += 5; evidence.append("temperament recorded")
        if payload.get("notes"):
            score += 10; evidence.append("notes added")
        return {"score": min(score, 100), "evidence": ", ".join(evidence) if evidence else "No evidence yet"}

    def field_recommendation(self, payload):
        qcells = int(payload.get("queen_cells") or 0)
        stores = float(payload.get("stores_frames") or 0)
        brood = float(payload.get("brood_frames") or 0)
        bees = float(payload.get("bee_coverage_frames") or 0)
        queen_seen = bool(payload.get("queen_seen"))
        eggs_seen = bool(payload.get("eggs_seen"))
        notes = []

        if qcells > 0:
            notes.append("Queen cells recorded: review swarm control or queen status before closing.")
        if stores <= 1 and (brood > 0 or bees > 0):
            notes.append("Stores look low: consider feeding or adding a stores frame.")
        if not queen_seen and not eggs_seen:
            notes.append("No queen and no eggs recorded: schedule a targeted queen-status check.")
        if brood >= 6 and bees >= 8:
            notes.append("Strong colony: check space and super capacity.")
        if not notes:
            notes.append("No immediate red flag from entered evidence. Stage draft and commit after review.")
        return " ".join(notes)
