# AOS v5.0.1 — Sidebar Navigation Fix

## Fixed
- Sidebar position.
- Main content placement.
- Persistent assistant placement.
- Navigation button behaviour.
