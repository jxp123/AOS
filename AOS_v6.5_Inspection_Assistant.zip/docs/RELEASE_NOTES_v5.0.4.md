# AOS v5.0.4 — IMPORT_DIR Hotfix

## Fixed
- Startup crash caused by missing `IMPORT_DIR` in settings.
- Hardened DataPortabilityService.
