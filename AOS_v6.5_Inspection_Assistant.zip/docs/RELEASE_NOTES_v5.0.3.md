# AOS v5.0.3 — Data Portability Safety

## Added
- Data Safety page.
- JSON data export.
- SQLite database backup export.
- JSON re-import.
- Export and import batch files.
- `/export-data` route.
- Safety backup before import.

## Purpose
Protect live AOS data across future releases.
