# AOS v4.0 — Apiary Assistant

## Added
- Local conversational assistant.
- Assistant reasoning over scheduler, operations, Apiary Brain, breeding, feeding/treatment and evidence data.
- Quick question buttons.
- Export and test integration.
