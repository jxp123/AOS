# AOS v5.2 — Operations Centre Map

## Added
- Interactive Apiary Map.
- Colony cards.
- Health score.
- Inspection status badges.
- Colony detail with timeline.
- One-click action suggestions.
