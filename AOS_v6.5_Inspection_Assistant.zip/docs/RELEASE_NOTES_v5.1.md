# AOS v5.1 — Field Inspection Workflow Stable

## Added
- Field Inspection Mode.
- Evidence-quality scoring.
- Live inspection recommendation.
- Draft-first inspection staging.

## Includes
- v5.0.4 IMPORT_DIR startup hotfix.
