# AOS v5.0 — Operations Centre UI

## Added
- Left navigation shell.
- Persistent assistant panel.
- Dashboard-first layout.
- Grouped navigation.
- Improved visual hierarchy and spacing.

## Purpose
Make AOS feel like one operational application rather than a collection of independent pages.
