# AOS v5.3 — Digital Twin Workspace

## Added
- Digital Twin.
- Colony workspace.
- Confidence meter.
- Trend tables.
- Smart inspection focus.
- Upgrade Manager.
