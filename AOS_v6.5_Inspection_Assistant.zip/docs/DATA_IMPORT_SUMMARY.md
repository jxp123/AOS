# Data Import Summary

Source file:

`Apiary_Management_Database_v3_0_2026-07-01_REDESIGNED 2.xlsx`

Imported into:

`data/aos.db`

## Imported counts

- Colonies from workbook: 22
- Queens: 15
- Inspection events: 24
- Actions: 11
- Risks: 8
- Equipment actions: 4
- Nuc pipeline rows: 7
- Honey production rows: 8
- Management decisions: 5
- Opportunities: 5

## Mapping

- `Colonies` sheet → AOS colonies table.
- `Queens` sheet → AOS queens table.
- `Inspection_Events` sheet → AOS inspections table where a colony/nuc could be matched.
- Apiary-wide events, risks, decisions, opportunities, timelines and plans → Operations Log.
- Equipment sheet → AOS equipment table.
- Feed actions → feeding records.
- Jolanta strategic decision → breeding plan.

## Notes

Units were normalised:
- `Hive 16` → `H16`
- `Nuc 92` → `N92`
- `Apiary` events were kept in the Operations Log.
