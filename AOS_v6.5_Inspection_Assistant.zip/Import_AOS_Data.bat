@echo off
cd /d "%~dp0"
if not exist .venv call Install_AOS.bat
call .venv\Scripts\activate.bat
set PYTHONPATH=%CD%\backend
echo.
echo Put your aos_data_export_*.json file into the imports folder first.
echo.
set /p IMPORTFILE=Enter JSON filename from imports folder:
python -c "from aos.core.bootstrap import boot; boot(); from aos.services.data_portability_service import DataPortabilityService; print(DataPortabilityService().import_json(r'imports\%IMPORTFILE%', mode='replace'))"
echo.
pause
