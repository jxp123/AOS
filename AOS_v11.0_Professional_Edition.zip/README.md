# AOS v11.0 — Professional Edition

This release begins converting AOS from a feature-rich prototype into a polished application.

## Added

- Professional UI shell.
- Persistent left navigation.
- Command palette framework.
- Professional Home page.
- Right-hand assistant/help panel.
- Responsive layout.
- Clearer priority actions and risk overview.
- Professional Edition specification.

## Use

Run AOS as normal. The app opens into the new Professional Home page.
