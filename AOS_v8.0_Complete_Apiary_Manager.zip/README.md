# AOS v8.0 — Complete Apiary Manager

Integrates daily operations, workspace, intelligence, analytics and predictive management into a complete platform overview.
