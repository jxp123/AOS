# AOS v3.5 — Timelines and Inspection Wizard

## Added
- Inspection Wizard tab.
- Colony timeline.
- Queen timeline.
- Timeline summary.
- Alerts tab.
- Evidence-score view.
- AI export includes timeline summary.
- Self-test includes timeline check.

## Use
Start with **Daily Operations**, then use **Inspection Wizard** for fast staged inspection entry.
