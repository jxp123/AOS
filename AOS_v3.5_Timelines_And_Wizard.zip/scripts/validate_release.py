import py_compile, sys
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
BACKEND = ROOT / "backend"
sys.path.insert(0, str(BACKEND))
for p in BACKEND.rglob("*.py"):
    py_compile.compile(str(p), doraise=True)
from aos.utils.self_test import main
main()
print("VALIDATION PASSED")
