from nicegui import ui
from aos.utils.self_test import run_self_tests, summary
from aos.utils.exporters import export_ai_json, export_excel

def page():
    ui.label('Tests / Exports').classes('text-h5'); holder=ui.column().classes('w-full')
    def test():
        holder.clear(); rows=run_self_tests(); s=summary(rows)
        with holder: ui.label(f"PASS={s['pass']} FAIL={s['fail']} TOTAL={s['total']}"); ui.table(columns=[{'name':'status','label':'Status','field':'status'},{'name':'test','label':'Test','field':'test'},{'name':'message','label':'Message','field':'message'}],rows=rows,row_key='test').classes('w-full')
    def ai(): ui.notify(f'Exported {export_ai_json()}',type='positive')
    def excel(): ui.notify(f'Exported {export_excel()}',type='positive')
    with ui.row(): ui.button('Run Tests',on_click=test); ui.button('Export AI JSON',on_click=ai); ui.button('Export Excel',on_click=excel)
    test()
