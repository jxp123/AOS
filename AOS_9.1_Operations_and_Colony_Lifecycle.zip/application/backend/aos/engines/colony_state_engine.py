from __future__ import annotations

from dataclasses import dataclass, asdict
from datetime import date, datetime
from typing import Any, Dict, List, Optional

from aos.services.repository import Repository
from aos.services.inspection_commit_service import InspectionCommitService
from aos.services.colony_profile_service import ColonyProfileService


def _parse_date(value: Any) -> Optional[date]:
    if not value:
        return None
    s = str(value).strip()
    for fmt in ("%Y-%m-%d", "%d/%m/%Y", "%d-%m-%Y", "%Y/%m/%d"):
        try:
            return datetime.strptime(s[:10], fmt).date()
        except Exception:
            pass
    return None


def _days_since(value: Any) -> Optional[int]:
    d = _parse_date(value)
    if not d:
        return None
    return (date.today() - d).days


def _boolish(value: Any) -> bool:
    if isinstance(value, bool):
        return value
    return str(value).strip().lower() in ["yes", "true", "1", "seen", "y"]


def _num(value: Any) -> float:
    try:
        return float(value or 0)
    except Exception:
        return 0.0


@dataclass
class ColonyState:
    code: str
    name: str
    type: str
    status: str
    lane: str
    health: int
    latest_inspection: str
    days_since_inspection: Optional[int]
    next_action: str
    queen_status: str
    queen: str
    swarm_risk: str
    starvation_risk: str
    confidence: int
    evidence: List[str]
    warnings: List[str]
    source: str = "Colony State Engine"

    def to_card(self) -> Dict[str, Any]:
        symbol = {"Do Today": "●", "Watch Closely": "▲", "Healthy": "■", "Upcoming": "◆"}.get(self.lane, "◆")
        return {
            "code": self.code,
            "name": self.name,
            "type": self.type,
            "health": self.health,
            "status_badge": f"{symbol} {self.status}",
            "queen": self.queen or self.queen_status,
            "latest_inspection": self.latest_inspection or "Never",
            "next_action": self.next_action,
            "lane": self.lane,
            "swarm_risk": self.swarm_risk,
            "starvation_risk": self.starvation_risk,
            "confidence": self.confidence,
            "evidence": self.evidence,
            "warnings": self.warnings,
            "explain": self.explain(),
        }

    def explain(self) -> str:
        parts = []
        if self.days_since_inspection is None:
            parts.append("No inspection date is available.")
        else:
            parts.append(f"Last inspection was {self.days_since_inspection} day(s) ago.")
        if self.evidence:
            parts.extend(self.evidence[:3])
        if self.warnings:
            parts.extend(self.warnings[:3])

        clean = []
        seen = set()
        for p in parts:
            p = str(p).strip()
            if not p:
                continue
            key = p.lower()
            if key not in seen:
                clean.append(p)
                seen.add(key)
        return " ".join(clean)

    def asdict(self) -> Dict[str, Any]:
        data = asdict(self)
        data["explain"] = self.explain()
        return data


class ColonyStateEngine:
    """Single source of truth for operational colony state.

    The UI should not decide whether a colony is overdue/current. It should ask this
    engine. The first release uses deterministic rules based on inspections and
    colony records; later releases can add weather, production and AI models.
    """

    def __init__(self):
        self.repo = Repository()

    def _entities(self) -> List[Dict[str, Any]]:
        try:
            rows = self.repo.list_apiary_entities(True)
            if rows:
                return rows
        except Exception:
            pass
        try:
            return self.repo.list_colonies()
        except Exception:
            return []

    def _inspections_for(self, code: str) -> List[Dict[str, Any]]:
        rows = []
        try:
            rows.extend(InspectionCommitService().list_committed_inspections(code))
        except Exception:
            pass
        try:
            for i in self.repo.list_inspections():
                if i.get("colony") == code or i.get("colony_code") == code or i.get("apiary_entity_code") == code:
                    rows.append(i)
        except Exception:
            pass
        rows.sort(key=lambda r: str(r.get("date") or r.get("inspection_date") or ""), reverse=True)
        return rows

    def _latest_inspection(self, code: str) -> Dict[str, Any]:
        rows = self._inspections_for(code)
        return rows[0] if rows else {}

    def state_for(self, code: str) -> ColonyState:
        entity = next((e for e in self._entities() if e.get("code") == code), {"code": code, "name": code})
        try:
            entity = ColonyProfileService().merge(code, entity)
        except Exception:
            pass
        latest = self._latest_inspection(code)

        latest_date = latest.get("date") or latest.get("inspection_date") or entity.get("last_brood_inspection") or entity.get("last_management_visit")
        days = _days_since(latest_date)
        queen_seen = _boolish(latest.get("queen_seen")) or "queen seen" in str(entity.get("queen_status", "")).lower()
        eggs = _boolish(latest.get("eggs_seen")) or "egg" in str(entity.get("brood_summary", "")).lower()
        larvae = _boolish(latest.get("larvae_seen"))
        queen_cells = _num(latest.get("queen_cells"))
        stores = _num(latest.get("stores_frames") or latest.get("stores"))
        brood = _num(latest.get("brood_frames") or latest.get("brood"))
        health = 80
        evidence: List[str] = []
        warnings: List[str] = []

        if days is None:
            lane = "Do Today"
            status = "No inspection record"
            health = 40
            next_action = "Inspect today"
            warnings.append("No inspection date is available.")
        elif days <= 7:
            lane = "Healthy"
            status = "Current"
            next_action = f"Next inspection in {max(1, 7 - days)} days"
            evidence.append(f"Last inspection was {days} day(s) ago.")
        elif days <= 10:
            lane = "Watch Closely"
            status = "Due soon"
            health = 70
            next_action = "Inspect soon"
            evidence.append(f"Last inspection was {days} day(s) ago.")
        else:
            lane = "Do Today"
            status = "Overdue"
            health = 35
            next_action = "Inspect today"
            warnings.append(f"Last inspection was {days} day(s) ago.")

        if queen_cells > 0:
            lane = "Do Today"
            status = "Swarm risk"
            health = min(health, 45)
            next_action = "Check queen cells / swarm control"
            warnings.append(f"{int(queen_cells)} queen cell(s) recorded.")

        if not queen_seen and not eggs:
            if days is None or days > 3:
                lane = "Watch Closely" if lane == "Healthy" else lane
                health = min(health, 65)
                warnings.append("Queen and eggs were not confirmed.")

        if stores and stores <= 1:
            lane = "Do Today"
            health = min(health, 50)
            next_action = "Check stores / feed"
            warnings.append("Stores appear low.")

        if brood:
            evidence.append(f"Brood recorded: {brood:g} frame(s).")
        if stores:
            evidence.append(f"Stores recorded: {stores:g} frame(s).")
        if queen_seen:
            evidence.append("Queen seen.")
        elif eggs:
            evidence.append("Eggs present.")
        if larvae:
            evidence.append("Larvae/open brood present.")

        swarm_risk = "High" if queen_cells > 0 else ("Moderate" if brood >= 7 and lane != "Healthy" else "Low")
        starvation_risk = "High" if stores and stores <= 1 else "Low"
        queen_status = "Seen" if queen_seen else ("Laying evidence" if eggs else "Unconfirmed")
        confidence = 95 if days is not None and (queen_seen or eggs) else (70 if days is not None else 35)


        # Final consistency guard: a colony cannot be "Current" and still sit in "Do Today"
        # unless a separate high-risk condition is active.
        if status == "Current" and lane != "Healthy":
            if queen_cells > 0 or (stores and stores <= 1):
                pass
            else:
                lane = "Healthy"
                health = max(health, 80)
                next_action = next_action or "Monitor"

        return ColonyState(
            code=code,
            name=entity.get("name") or code,
            type=entity.get("type") or "",
            status=status,
            lane=lane,
            health=int(health),
            latest_inspection=str(latest_date or ""),
            days_since_inspection=days,
            next_action=next_action,
            queen_status=queen_status,
            queen=entity.get("queen_id") or entity.get("queen") or "",
            swarm_risk=swarm_risk,
            starvation_risk=starvation_risk,
            confidence=confidence,
            evidence=evidence,
            warnings=warnings,
        )

    def all_states(self) -> List[ColonyState]:
        return [self.state_for(e.get("code")) for e in self._entities() if e.get("code")]

    def cards(self) -> List[Dict[str, Any]]:
        return [s.to_card() for s in self.all_states()]

    def lanes(self) -> Dict[str, List[Dict[str, Any]]]:
        lanes = {"Do Today": [], "Watch Closely": [], "Healthy": [], "Upcoming": []}
        for card in self.cards():
            lanes.setdefault(card.get("lane", "Upcoming"), []).append(card)
        return lanes

    def mission_summary(self) -> Dict[str, Any]:
        lanes = self.lanes()
        return {
            "lanes": lanes,
            "total": sum(len(v) for v in lanes.values()),
            "high_risk": len(lanes.get("Do Today", [])),
            "watch": len(lanes.get("Watch Closely", [])),
            "healthy": len(lanes.get("Healthy", [])),
        }
