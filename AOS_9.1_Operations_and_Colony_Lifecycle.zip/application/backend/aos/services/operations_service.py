from __future__ import annotations

import sqlite3
from datetime import date, datetime
from pathlib import Path
from typing import Any, Dict, List, Optional

from aos.core.settings import DB_PATH


class OperationsService:
    """Records non-inspection beekeeper operations.

    Examples:
    - queen introduced
    - feeder added
    - super added
    - feeding given
    - treatment applied
    """

    def __init__(self):
        self.db_path = DB_PATH

    def ensure_schema(self) -> None:
        Path(self.db_path).parent.mkdir(parents=True, exist_ok=True)
        with sqlite3.connect(self.db_path) as con:
            con.execute("""
                CREATE TABLE IF NOT EXISTS aos_colony_operations (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    colony_code TEXT NOT NULL,
                    operation_date TEXT NOT NULL,
                    operation_type TEXT NOT NULL,
                    title TEXT NOT NULL,
                    details TEXT,
                    payload_json TEXT,
                    created_at TEXT NOT NULL
                )
            """)
            con.execute("""
                CREATE TABLE IF NOT EXISTS aos_queen_records (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    colony_code TEXT NOT NULL,
                    installed_date TEXT NOT NULL,
                    supplier TEXT,
                    breed TEXT,
                    queen_line TEXT,
                    colour TEXT,
                    queen_year TEXT,
                    marked INTEGER DEFAULT 0,
                    clipped INTEGER DEFAULT 0,
                    introduction_method TEXT,
                    reason TEXT,
                    status TEXT DEFAULT 'current',
                    notes TEXT,
                    created_at TEXT NOT NULL
                )
            """)
            con.execute("""
                CREATE TABLE IF NOT EXISTS aos_equipment_events (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    colony_code TEXT NOT NULL,
                    event_date TEXT NOT NULL,
                    event_type TEXT NOT NULL,
                    equipment_type TEXT NOT NULL,
                    box_standard TEXT,
                    box_depth TEXT,
                    frame_count REAL,
                    details TEXT,
                    created_at TEXT NOT NULL
                )
            """)
            con.commit()

    def record_operation(self, code: str, operation_type: str, title: str, details: str = "", payload_json: str = "{}") -> int:
        self.ensure_schema()
        with sqlite3.connect(self.db_path) as con:
            cur = con.execute("""
                INSERT INTO aos_colony_operations (
                    colony_code, operation_date, operation_type, title, details, payload_json, created_at
                )
                VALUES (?, ?, ?, ?, ?, ?, ?)
            """, (
                code,
                str(date.today()),
                operation_type,
                title,
                details,
                payload_json,
                datetime.now().isoformat(timespec="seconds"),
            ))
            con.commit()
            return int(cur.lastrowid)

    def install_queen(self, code: str, values: Dict[str, Any]) -> int:
        self.ensure_schema()
        with sqlite3.connect(self.db_path) as con:
            # Close earlier current queens for this colony.
            con.execute("UPDATE aos_queen_records SET status='replaced' WHERE colony_code=? AND status='current'", (code,))
            cur = con.execute("""
                INSERT INTO aos_queen_records (
                    colony_code, installed_date, supplier, breed, queen_line, colour, queen_year,
                    marked, clipped, introduction_method, reason, status, notes, created_at
                )
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'current', ?, ?)
            """, (
                code,
                values.get("installed_date") or str(date.today()),
                values.get("supplier") or "",
                values.get("breed") or "",
                values.get("queen_line") or "",
                values.get("colour") or "",
                values.get("queen_year") or "",
                1 if values.get("marked") else 0,
                1 if values.get("clipped") else 0,
                values.get("introduction_method") or "",
                values.get("reason") or "",
                values.get("notes") or "",
                datetime.now().isoformat(timespec="seconds"),
            ))
            con.commit()
            queen_id = int(cur.lastrowid)

        self.record_operation(
            code,
            "queen_install",
            "Queen installed",
            f"New queen installed. Supplier: {values.get('supplier') or 'unknown'}, breed: {values.get('breed') or 'unknown'}.",
        )
        return queen_id

    def add_feeder(self, code: str, values: Dict[str, Any]) -> int:
        self.ensure_schema()
        details = f"{values.get('feeder_type') or 'Feeder'} added. Capacity: {values.get('capacity') or 'unknown'}."
        with sqlite3.connect(self.db_path) as con:
            cur = con.execute("""
                INSERT INTO aos_equipment_events (
                    colony_code, event_date, event_type, equipment_type, box_standard, box_depth,
                    frame_count, details, created_at
                )
                VALUES (?, ?, 'add', 'feeder', '', '', 0, ?, ?)
            """, (
                code,
                values.get("event_date") or str(date.today()),
                details,
                datetime.now().isoformat(timespec="seconds"),
            ))
            con.commit()
            event_id = int(cur.lastrowid)
        self.record_operation(code, "equipment_add_feeder", "Feeder added", details)
        return event_id

    def add_super(self, code: str, values: Dict[str, Any]) -> int:
        self.ensure_schema()
        box_standard = values.get("box_standard") or ""
        box_depth = values.get("box_depth") or ""
        frame_count = float(values.get("frame_count") or 0)
        details = f"Super added: {box_standard} {box_depth}, {frame_count:g} frames."
        with sqlite3.connect(self.db_path) as con:
            cur = con.execute("""
                INSERT INTO aos_equipment_events (
                    colony_code, event_date, event_type, equipment_type, box_standard, box_depth,
                    frame_count, details, created_at
                )
                VALUES (?, ?, 'add', 'super', ?, ?, ?, ?, ?)
            """, (
                code,
                values.get("event_date") or str(date.today()),
                box_standard,
                box_depth,
                frame_count,
                details,
                datetime.now().isoformat(timespec="seconds"),
            ))
            con.commit()
            event_id = int(cur.lastrowid)

        self.record_operation(code, "equipment_add_super", "Super added", details)

        # Also create a basic super record for the honey engine if available.
        try:
            from aos.engines.honey_production_engine import HoneyProductionEngine
            HoneyProductionEngine().ensure_schema()
            with sqlite3.connect(self.db_path) as con:
                con.execute("""
                    INSERT INTO aos_super_records (
                        colony_code, record_date, super_type, frames_total, frames_drawn,
                        percent_capped, percent_uncapped, intended_for_harvest, notes
                    )
                    VALUES (?, ?, ?, ?, 0, 0, 0, 1, ?)
                """, (
                    code,
                    values.get("event_date") or str(date.today()),
                    f"{box_standard} {box_depth}".strip(),
                    frame_count,
                    "Created from Add Super operation",
                ))
                con.commit()
        except Exception:
            pass

        return event_id

    def timeline_operations(self, code: str) -> List[Dict[str, Any]]:
        self.ensure_schema()
        with sqlite3.connect(self.db_path) as con:
            con.row_factory = sqlite3.Row
            rows = con.execute("""
                SELECT operation_date AS date, operation_type AS type, title, details
                FROM aos_colony_operations
                WHERE colony_code=?
                ORDER BY operation_date DESC, id DESC
            """, (code,)).fetchall()
        return [dict(r) for r in rows]
