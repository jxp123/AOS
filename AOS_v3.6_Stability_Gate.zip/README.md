# AOS v3.6 — Stability Gate

This release stabilises the application before further features.

## Added

- Full UI shell rewritten with explicit tab variables.
- Runtime page-smoke test.
- `Run_Verification.bat`.
- Stronger release validation.
- Tests tab shows self-test and page-render checks.

## Run

1. `Install_AOS.bat`
2. `Run_Verification.bat`
3. `Run_AOS.bat`

Use this as the stable base before adding further features.
