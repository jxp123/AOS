import json
from datetime import datetime
import pandas as pd
from aos.core.settings import EXPORT_DIR
from aos.services.repository import Repository
from aos.engines.brain import apiary_brain_state, brain_briefing
from aos.engines.operations import todays_work
from aos.engines.scheduler import inspection_schedule
from aos.engines.daily_operations import daily_dashboard
from aos.engines.workbench import workbench_rows

def export_ai_json():
    EXPORT_DIR.mkdir(exist_ok=True); repo=Repository(); state={'brain':apiary_brain_state(),'briefing':brain_briefing(),'operations':todays_work(),'inspection_schedule':inspection_schedule(),'colonies':repo.list_colonies(),'queens':repo.list_queens(),'equipment':repo.list_equipment(),'inspections':repo.list_inspections(),'weather':repo.list_weather()}; path=EXPORT_DIR/'apiary_state.json'; path.write_text(json.dumps(state,indent=2),encoding='utf-8'); return path

def export_excel():
    EXPORT_DIR.mkdir(exist_ok=True); repo=Repository(); path=EXPORT_DIR/f"aos_export_{datetime.now().strftime('%Y%m%d_%H%M%S')}.xlsx"
    with pd.ExcelWriter(path,engine='openpyxl') as writer:
        pd.DataFrame(repo.list_colonies()).to_excel(writer,sheet_name='Colonies',index=False); pd.DataFrame(repo.list_queens()).to_excel(writer,sheet_name='Queens',index=False); pd.DataFrame(repo.list_equipment()).to_excel(writer,sheet_name='Equipment',index=False); pd.DataFrame(repo.list_inspections()).to_excel(writer,sheet_name='Inspections',index=False); pd.DataFrame(repo.list_weather()).to_excel(writer,sheet_name='Weather',index=False); pd.DataFrame(inspection_schedule()).to_excel(writer,sheet_name='Inspection Schedule',index=False)
    return path
