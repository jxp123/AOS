from nicegui import ui
from aos.core.settings import APP_VERSION
from aos.ui import brain, daily_operations, operations, workbench, scheduler, natural_language, guided, records, operations_log, tests

def render_app():
    ui.label("🐝 Apiary Operating System").classes("text-h4")
    ui.label(f"v{APP_VERSION} Daily Apiary Operations").classes("text-subtitle1")

    with ui.tabs().classes("w-full") as tabs:
        t_daily = ui.tab("Daily Operations")
        t_brain = ui.tab("Apiary Brain")
        t_ops = ui.tab("Operations")
        t_workbench = ui.tab("Inspection Workbench")
        t_sched = ui.tab("Inspection Scheduler")
        t_nl = ui.tab("Natural Language")
        t_guided = ui.tab("Guided Inspection")
        t_records = ui.tab("Records")
        t_log = ui.tab("Operations Log")
        t_tests = ui.tab("Tests")

    with ui.tab_panels(tabs, value=t_daily).classes("w-full"):
        with ui.tab_panel(t_daily): daily_operations.page()
        with ui.tab_panel(t_brain): brain.page()
        with ui.tab_panel(t_ops): operations.page()
        with ui.tab_panel(t_workbench): workbench.page()
        with ui.tab_panel(t_sched): scheduler.page()
        with ui.tab_panel(t_nl): natural_language.page()
        with ui.tab_panel(t_guided): guided.page()
        with ui.tab_panel(t_records): records.page()
        with ui.tab_panel(t_log): operations_log.page()
        with ui.tab_panel(t_tests): tests.page()
