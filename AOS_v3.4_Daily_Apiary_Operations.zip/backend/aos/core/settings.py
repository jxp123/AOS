from pathlib import Path
APP_VERSION = "3.4.0"
SCHEMA_VERSION = "3.4"
BACKEND_DIR = Path(__file__).resolve().parents[2]
ROOT_DIR = BACKEND_DIR.parent
DATA_DIR = ROOT_DIR / "data"
DB_PATH = DATA_DIR / "aos.db"
EXPORT_DIR = ROOT_DIR / "exports"
BACKUP_DIR = ROOT_DIR / "backups"
LOG_DIR = ROOT_DIR / "logs"
