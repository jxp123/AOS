# AOS v3.4 — Daily Apiary Operations

This release adds the daily operating layer and fixes:

`NameError: name 't_workbench' is not defined`

## Added
- Daily Operations tab
- Daily briefing cards
- Inspection route
- Smart alerts
- Evidence scores
- Apiary map/list
- Operations Log tab

## Fixed
- Rebuilt the UI shell so every tab is explicitly defined before use.
