# AOS 3.5 — Colony Summary & Live Status Update

This release addresses the latest usability feedback.

## Fixed / improved

- Colony Workspace no longer presents a confusing raw colony record as the main view.
- The main colony screen now shows a readable "Colony snapshot".
- The full technical colony record is still available, but moved into a collapsible section.
- After Finish Inspection, the colony is immediately marked as Current in the live session.
- Mission Control opens automatically after a successful inspection so the user can see the operational board update.
- The Inspector also reflects the updated current status.

## Important note

The live Mission Control update happens immediately in the current session. The existing AOS inspection service is still used to save/stage the inspection record safely.
