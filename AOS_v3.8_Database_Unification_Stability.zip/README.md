# AOS v3.8 — Database Unification and Stability

## Added

- System Health tab.
- Database tab.
- Automatic startup database backup.
- Manual backup button.
- Health report:
  - database exists
  - required tables
  - database size
  - latest backup
  - colony / queen / equipment / inspection / treatment counts
- Transactional inspection save:
  - inspection and audit log commit together
- Stability layer for future migration work.
- AI export includes system health.
- Self-test includes system health.

## Important

This release is intentionally non-destructive. It does not reshape existing data. It adds the stability foundation needed before deeper AOS 4.0 work.
