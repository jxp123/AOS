# AOS Professional 8.5 — Release Notes

## Included

- Persistent data foundation
- Apiary Intelligence Centre
- Honey production estimate
- Mission Control
- Colony Intelligence Workspace
- Adaptive Inspection Workflow
- Colony profile editing
- Data management page
- Windows PowerShell install/upgrade script

## Known limitation

This is not yet a compiled `Setup.exe`; it is a script-based installer candidate.
