# AOS Professional 8.5 — Installer Candidate

This package consolidates the latest AOS application into a professional installation layout.

## Important

This is a PowerShell installer candidate, not a compiled `.exe` installer.

## Install

1. Extract this ZIP.
2. Right-click `install_aos.ps1`.
3. Choose **Run with PowerShell**.
4. Launch AOS from the desktop shortcut.

## Data preservation

Your live data is stored outside the application folder:

`%LOCALAPPDATA%\AOS\data\aos.db`

Future upgrades replace only:

`%LOCALAPPDATA%\AOS\Application`

They do not overwrite:

- database
- backups
- exports
- config
- logs
