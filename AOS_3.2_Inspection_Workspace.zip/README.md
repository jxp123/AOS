# AOS 3.2 — Inspection Workspace

This release implements the inspection and history changes requested after AOS 3.1.

## Changed

- History is now shown as timeline cards, latest first.
- History is no longer presented as a table-first view.
- Inspect now opens a real Inspection Workspace.
- Inspection focus appears as a checklist.
- Inspection recording uses checkboxes, counters and short notes.
- Finish Inspection stages an inspection draft.
- Quick actions now say Start Inspection where appropriate.
- Colony Workspace shows Recent Timeline rather than a raw table first.

## Important note

Finish Inspection stages the inspection as a draft using the existing FieldInspectionService. This is safer than direct commit and preserves the review flow already built into AOS.
