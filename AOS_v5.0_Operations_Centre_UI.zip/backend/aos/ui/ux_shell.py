from nicegui import ui
from aos.core.settings import APP_VERSION
from aos.engines.apiary_assistant import assistant_answer
import importlib
import traceback

NAV_GROUPS = [
    ("Daily Work", [
        ("Dashboard", "aos.ui.v5_dashboard", "page"),
        ("Today", "aos.ui.daily_operations", "page"),
        ("Inspection Workbench", "aos.ui.workbench", "page"),
        ("Inspection Wizard", "aos.ui.inspection_wizard", "page"),
        ("Inspection Scheduler", "aos.ui.scheduler", "page"),
    ]),
    ("Colony Management", [
        ("Colonies / Records", "aos.ui.records", "page"),
        ("Queens", "aos.ui.breeding_studio", "page"),
        ("Timelines", "aos.ui.timelines", "page"),
    ]),
    ("Hive Health", [
        ("Feeding / Treatments", "aos.ui.feeding_treatments", "page"),
        ("Weather", "aos.ui.records", "page"),
        ("Alerts", "aos.ui.alerts", "page"),
    ]),
    ("Intelligence", [
        ("Apiary Brain", "aos.ui.brain", "page"),
        ("Apiary Assistant", "aos.ui.apiary_assistant", "page"),
        ("Operations Log", "aos.ui.operations_log", "page"),
    ]),
    ("Administration", [
        ("System Health", "aos.ui.system_health", "page"),
        ("Database", "aos.ui.database_unification", "page"),
        ("Tests / Exports", "aos.ui.tests", "page"),
    ]),
]

def _render_error(title, error):
    ui.label("AOS page error").classes("text-h5 text-negative")
    ui.label(f"{title} failed to load.").classes("text-negative")
    ui.label(str(error)).classes("text-negative")
    ui.textarea("Diagnostic traceback", value=traceback.format_exc()).props("readonly autogrow").classes("w-full")
    print(f"AOS PAGE ERROR — {title}: {error}")
    print(traceback.format_exc())

def render_modern_app():
    ui.add_head_html("""
    <style>
      body { background: #f6f7f9; }
      .aos-shell { min-height: 100vh; }
      .aos-sidebar { background: #102033; color: white; min-height: 88vh; border-radius: 14px; padding: 12px; }
      .aos-main { background: white; border-radius: 14px; padding: 18px; min-height: 88vh; }
      .aos-assistant { background: #f9fafb; border-radius: 14px; padding: 14px; min-height: 88vh; border: 1px solid #e5e7eb; }
      .aos-nav-button { width: 100%; justify-content: flex-start; margin-bottom: 4px; }
      .aos-section-title { color: #a8bdd8; font-size: 12px; text-transform: uppercase; letter-spacing: 0.04em; margin-top: 14px; }
      .aos-card { border: 1px solid #e5e7eb; border-radius: 12px; padding: 12px; background: #ffffff; }
    </style>
    """)

    ui.label("🐝 Apiary Operating System").classes("text-h4")
    ui.label(f"v{APP_VERSION} Operations Centre UI").classes("text-subtitle1")

    content = ui.column().classes("w-full")
    assistant_output = ui.column().classes("w-full")

    def load_page(title, module_name, function_name):
        content.clear()
        with content:
            try:
                ui.label(title).classes("text-h5")
                module = importlib.import_module(module_name)
                page_func = getattr(module, function_name)
                page_func()
            except Exception as e:
                _render_error(title, e)

    def ask_assistant(question):
        assistant_output.clear()
        result = assistant_answer(question)
        with assistant_output:
            ui.label("Answer").classes("text-subtitle1")
            ui.textarea(value=result["answer"]).props("readonly autogrow").classes("w-full")
            ui.label(f"Confidence: {result['confidence']}")
            ui.label(f"Source: {result['source']}")

    with ui.row().classes("w-full aos-shell").style("gap: 14px; align-items: stretch;"):
        with ui.column().classes("aos-sidebar").style("width: 250px; flex-shrink: 0;"):
            ui.label("Navigation").classes("text-h6")
            for group, pages in NAV_GROUPS:
                ui.label(group).classes("aos-section-title")
                for title, module_name, function_name in pages:
                    ui.button(title, on_click=lambda t=title, m=module_name, f=function_name: load_page(t, m, f)).classes("aos-nav-button")

        with ui.column().classes("aos-main").style("flex: 1; min-width: 0;"):
            content

        with ui.column().classes("aos-assistant").style("width: 330px; flex-shrink: 0;"):
            ui.label("Apiary Assistant").classes("text-h6")
            q = ui.textarea("Ask AOS", placeholder="What should I inspect today?").classes("w-full")
            with ui.row():
                ui.button("Ask", on_click=lambda: ask_assistant(q.value or "summary"))
                ui.button("Today", on_click=lambda: ask_assistant("What should I inspect today?"))
            with ui.row():
                ui.button("Risks", on_click=lambda: ask_assistant("Which colonies worry you?"))
                ui.button("Queens", on_click=lambda: ask_assistant("Which queens should I breed from?"))
            assistant_output

    load_page("Dashboard", "aos.ui.v5_dashboard", "page")
    ask_assistant("summary")
