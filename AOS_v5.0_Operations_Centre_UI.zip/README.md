# AOS v5.0 — Operations Centre UI

## Main change

AOS now uses a modern operations-centre layout:

- Left-hand navigation.
- Main workspace.
- Persistent right-hand Apiary Assistant.
- Dashboard-first experience.
- Grouped navigation:
  - Daily Work
  - Colony Management
  - Hive Health
  - Intelligence
  - Administration

## Added

- New Dashboard page.
- Persistent assistant panel.
- Side navigation replacing horizontal tab overload.
- Page-level error display retained.
- Existing features preserved through navigation links.

## Run

1. `Install_AOS.bat`
2. `Run_Verification.bat`
3. `Run_AOS.bat`
