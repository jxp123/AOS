# AOS 5.1 — Task Board Inspect Fix

## Fixed

- Removed the confusing Done button from task cards.
- Tasks are completed only by real workflow actions, such as Finish Inspection.
- Inspect buttons on Mission Control task cards now route through a robust inspection launcher.
- Repeated explanation sentences under due dates are removed.
- Completed Today remains, but it is populated from completed inspections rather than manual Done clicks.
