PAGES = [
    ("Operations Centre Dashboard", "aos.ui.v5_dashboard", "page"),
    ("Smart Apiary", "aos.ui.smart_apiary", "page"),
    ("Field Operations", "aos.ui.field_operations", "page"),
    ("Beekeeper Workspace", "aos.ui.beekeeper_workspace", "page"),
    ("Operations Centre", "aos.ui.operations_centre", "page"),
    ("Digital Twin", "aos.ui.digital_twin", "page"),
    ("Daily Operations", "aos.ui.daily_operations", "page"),
    ("Apiary Assistant", "aos.ui.apiary_assistant", "page"),
    ("Apiary Brain", "aos.ui.brain", "page"),
    ("Operations", "aos.ui.operations", "page"),
    ("Inspection Workbench", "aos.ui.workbench", "page"),
    ("Field Inspection Mode", "aos.ui.field_mode", "page"),
    ("Inspection Wizard", "aos.ui.inspection_wizard", "page"),
    ("Inspection Scheduler", "aos.ui.scheduler", "page"),
    ("Natural Language", "aos.ui.natural_language", "page"),
    ("Guided Inspection", "aos.ui.guided", "page"),
    ("Records", "aos.ui.records", "page"),
    ("Feeding / Treatments", "aos.ui.feeding_treatments", "page"),
    ("Queen Breeding", "aos.ui.breeding_studio", "page"),
    ("Timelines", "aos.ui.timelines", "page"),
    ("Alerts", "aos.ui.alerts", "page"),
    ("Operations Log", "aos.ui.operations_log", "page"),
    ("Data Safety", "aos.ui.data_safety", "page"),
    ("Upgrade Manager", "aos.ui.upgrade_manager", "page"),
    ("System Health", "aos.ui.system_health", "page"),
    ("Database", "aos.ui.database_unification", "page"),
    ("Tests", "aos.ui.tests", "page"),
]

def run_runtime_smoke():
    import importlib
    from aos.core.bootstrap import boot
    boot()
    results = []
    for name, module_name, function_name in PAGES:
        try:
            module = importlib.import_module(module_name)
            getattr(module, function_name)
            results.append({"page": name, "status": "PASS", "message": ""})
        except ModuleNotFoundError as e:
            if "nicegui" in str(e):
                results.append({"page": name, "status": "SKIP", "message": "NiceGUI not installed in this environment"})
            else:
                results.append({"page": name, "status": "FAIL", "message": repr(e)})
        except Exception as e:
            results.append({"page": name, "status": "FAIL", "message": repr(e)})
    return results

def main():
    rows = run_runtime_smoke()
    for row in rows:
        print(f"[{row['status']}] {row['page']}: {row['message']}")
    if any(r["status"] == "FAIL" for r in rows):
        raise SystemExit(1)

if __name__ == "__main__":
    main()
