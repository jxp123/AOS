# AOS v6.2 — Beekeeper Workspace

Adds colony-centred workspace with summary, history, trends, confidence and actions.
