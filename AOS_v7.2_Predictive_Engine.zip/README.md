# AOS v7.2 — Predictive Engine

Adds predictive risk board, seasonal planner and resource forecasting.
