# AOS v5.2 — Operations Centre Map

## Added

- Operations Centre page.
- Interactive Apiary Map.
- Red / Amber / Green inspection status.
- Colony health score.
- Clickable colony cards.
- Colony detail panel:
  - health
  - queen
  - latest inspection
  - brood/stores
  - next action
  - timeline
- One-click action suggestions:
  - inspect
  - feed
  - queen check
  - check super space
  - add note
- Dashboard now includes red-colony count.
- Export/self-test/runtime integration.

## Why

This release makes AOS easier to run at a glance. You can now see the apiary as a set of operational cards, not just tables.
