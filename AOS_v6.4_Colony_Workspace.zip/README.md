# AOS v6.4 — Colony Workspace

Adds a colony-centred workspace with overview, inspections, timeline, analytics and confidence.
