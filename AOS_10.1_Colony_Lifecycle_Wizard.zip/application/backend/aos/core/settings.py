from pathlib import Path
APP_VERSION = "10.1.0"
SCHEMA_VERSION = "10.1"
BACKEND_DIR = Path(__file__).resolve().parents[2]
ROOT_DIR = BACKEND_DIR.parent
DATA_DIR = ROOT_DIR / "data"
DB_PATH = DATA_DIR / "aos.db"
EXPORT_DIR = ROOT_DIR / "exports"
IMPORT_DIR = ROOT_DIR / "imports"
BACKUP_DIR = ROOT_DIR / "backups"
LOG_DIR = ROOT_DIR / "logs"


# AOS 8.0 persistent data foundation
import os
from pathlib import Path as _Path

AOS_HOME = _Path(os.environ.get("AOS_HOME", str(_Path.home() / "AOS")))
AOS_DATA_DIR = AOS_HOME / "data"
AOS_BACKUP_DIR = AOS_HOME / "backups"
AOS_EXPORT_DIR = AOS_HOME / "exports"
AOS_CONFIG_DIR = AOS_HOME / "config"
AOS_LOG_DIR = AOS_HOME / "logs"

# From AOS 8.0 onward, data lives outside the application release folder.
DB_PATH = str(AOS_DATA_DIR / "aos.db")
