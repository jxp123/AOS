from __future__ import annotations

from datetime import date
from typing import Any, Dict, List

from aos.services.colony_configuration_service import ColonyConfigurationService


class DynamicHiveInspectionEngine:
    """Builds an inspection form from the colony's current physical configuration."""

    def __init__(self):
        self.config = ColonyConfigurationService()

    def sections_for(self, code: str) -> Dict[str, Any]:
        cfg = self.config.configuration(code)
        supers = cfg.get("supers", [])
        feeders = cfg.get("feeders", [])
        brood_boxes = cfg.get("brood_boxes", [])
        components = cfg.get("components", [])

        return {
            "code": code,
            "inspection_date": str(date.today()),
            "brood_chamber": {
                "label": "Brood chamber",
                "adult_bee_label": "Adult bees covering brood chamber",
                "brood_boxes": brood_boxes,
            },
            "brood_stores": {
                "label": "Brood stores",
                "fields": ["nectar_frames", "pollen_frames", "feed_in_brood_frames"],
            },
            "supers": supers,
            "feeders": feeders,
            "hardware": [c for c in components if c.get("component_type") in {"roof", "floor", "crownboard", "queen_excluder", "dummy_board", "insulation"}],
        }

    def estimate_super_honey_kg(self, component: Dict[str, Any], percent_capped: float, percent_uncapped: float) -> Dict[str, float]:
        frames = float(component.get("frame_count") or 10)
        depth = (component.get("box_depth") or "").lower()
        standard = (component.get("box_standard") or "").lower()

        # Conservative practical estimates per fully capped frame.
        # These are rough modelling values, not legal trade measurements.
        per_frame = 1.6
        if "national" in standard and "shallow" in depth:
            per_frame = 1.1
        elif "langstroth" in standard and "medium" in depth:
            per_frame = 1.6
        elif "langstroth" in standard and "deep" in depth:
            per_frame = 2.5
        elif "dadant" in standard:
            per_frame = 2.8

        capped_kg = frames * per_frame * max(0, min(100, percent_capped)) / 100
        ripening_kg = frames * per_frame * 0.65 * max(0, min(100, percent_uncapped)) / 100
        return {
            "extractable_kg": round(capped_kg, 1),
            "ripening_kg": round(ripening_kg, 1),
            "total_honey_kg": round(capped_kg + ripening_kg, 1),
        }

    def colony_strength_equivalent(self, brood_adult_bees: float, super_bee_percentages: List[float], supers: List[Dict[str, Any]]) -> float:
        # Approximation: full medium/shallow super occupied by bees ~= 4 brood-frame equivalents.
        total = float(brood_adult_bees or 0)
        for pct, comp in zip(super_bee_percentages, supers):
            depth = (comp.get("box_depth") or "").lower()
            equivalent_full = 4.0
            if depth == "deep":
                equivalent_full = 6.0
            total += equivalent_full * max(0, min(100, float(pct or 0))) / 100
        return round(total, 1)
