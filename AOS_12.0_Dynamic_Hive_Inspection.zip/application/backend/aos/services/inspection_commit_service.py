from __future__ import annotations

import sqlite3
from datetime import date, datetime
from pathlib import Path
from typing import Any, Dict, List, Optional

from aos.core.settings import DB_PATH


def _today() -> str:
    return str(payload.get("inspection_date") or date.today())


def _bool_int(value: Any) -> int:
    return 1 if bool(value) else 0


def _float(value: Any) -> float:
    try:
        return float(value or 0)
    except Exception:
        return 0.0


def _int(value: Any) -> int:
    try:
        return int(value or 0)
    except Exception:
        return 0


def _safe_text(value: Any) -> str:
    return "" if value is None else str(value)


class InspectionCommitService:
    """Commits completed inspections so Mission Control updates immediately."""

    def __init__(self):
        self.db_path = DB_PATH

    def ensure_schema(self) -> None:
        Path(self.db_path).parent.mkdir(parents=True, exist_ok=True)
        with sqlite3.connect(self.db_path) as con:
            con.execute("""
                CREATE TABLE IF NOT EXISTS aos_committed_inspections (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    colony_code TEXT NOT NULL,
                    inspection_date TEXT NOT NULL,
                    queen_seen INTEGER DEFAULT 0,
                    eggs_seen INTEGER DEFAULT 0,
                    larvae_seen INTEGER DEFAULT 0,
                    brood_frames REAL DEFAULT 0,
                    stores_frames REAL DEFAULT 0,
                    bee_coverage_frames REAL DEFAULT 0,
                    queen_cells INTEGER DEFAULT 0,
                    temperament TEXT,
                    notes TEXT,
                    next_inspection_date TEXT,
                    next_inspection_reason TEXT,
                    created_at TEXT NOT NULL
                )
            """)
            try:
                con.execute("ALTER TABLE aos_committed_inspections ADD COLUMN next_inspection_date TEXT")
            except Exception:
                pass
            try:
                con.execute("ALTER TABLE aos_committed_inspections ADD COLUMN next_inspection_reason TEXT")
            except Exception:
                pass
            con.commit()

    def commit_inspection(self, code: str, payload: Dict[str, Any]) -> Dict[str, Any]:
        self.ensure_schema()
        inspection_date = payload.get("inspection_date") or _today()
        with sqlite3.connect(self.db_path) as con:
            cur = con.execute("""
                INSERT INTO aos_committed_inspections (
                    colony_code, inspection_date, queen_seen, eggs_seen, larvae_seen,
                    brood_frames, stores_frames, bee_coverage_frames, queen_cells,
                    temperament, notes, next_inspection_date, next_inspection_reason, created_at
                )
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                code,
                inspection_date,
                _bool_int(payload.get("queen_seen")),
                _bool_int(payload.get("eggs_seen")),
                _bool_int(payload.get("larvae_seen")),
                _float(payload.get("brood_frames")),
                _float(payload.get("stores_frames")),
                _float(payload.get("bee_coverage_frames")),
                _int(payload.get("queen_cells")),
                _safe_text(payload.get("temperament")),
                _safe_text(payload.get("notes")),
                _safe_text(payload.get("next_inspection_date")),
                _safe_text(payload.get("next_inspection_reason")),
                datetime.now().isoformat(timespec="seconds"),
            ))
            con.commit()
            row_id = cur.lastrowid

        return {
            "saved": True,
            "inspection_id": row_id,
            "title": "Inspection recorded",
            "message": f"Inspection for {code} has been saved and Mission Control can now recalculate the colony state.",
            "next_step": "Mission Control has been refreshed.",
        }

    def list_committed_inspections(self, code: Optional[str] = None) -> List[Dict[str, Any]]:
        self.ensure_schema()
        with sqlite3.connect(self.db_path) as con:
            con.row_factory = sqlite3.Row
            if code:
                rows = con.execute(
                    "SELECT * FROM aos_committed_inspections WHERE colony_code=? ORDER BY inspection_date DESC, id DESC",
                    (code,),
                ).fetchall()
            else:
                rows = con.execute(
                    "SELECT * FROM aos_committed_inspections ORDER BY inspection_date DESC, id DESC"
                ).fetchall()

        result = []
        for r in rows:
            d = dict(r)
            d["colony"] = d.get("colony_code")
            d["date"] = d.get("inspection_date")
            d["queen_seen"] = bool(d.get("queen_seen"))
            d["eggs_seen"] = bool(d.get("eggs_seen"))
            d["larvae_seen"] = bool(d.get("larvae_seen"))
            result.append(d)
        return result
