from __future__ import annotations

import sqlite3
from datetime import date
from pathlib import Path
from typing import Optional

from aos.core.settings import DB_PATH


class InspectionDateService:
    """Allows inspection date to be selected/amended when backfilling records."""

    def __init__(self):
        self.db_path = DB_PATH

    def ensure_schema(self) -> None:
        Path(self.db_path).parent.mkdir(parents=True, exist_ok=True)
        with sqlite3.connect(self.db_path) as con:
            # Existing tables may already have inspection_date; this is defensive.
            try:
                con.execute("ALTER TABLE aos_committed_inspections ADD COLUMN inspection_date TEXT")
            except Exception:
                pass
            con.commit()

    def normalize(self, value: Optional[str]) -> str:
        text = str(value or "").strip()
        return text or str(date.today())
