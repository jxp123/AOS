# AOS 12.0 — Dynamic Hive Inspection

## User feedback addressed

- Bee coverage did not make sense when supers were fitted.
- Inspections entered later were incorrectly recorded as today.
- Supers/honey inspection needs to support multiple fitted supers.
- Feed type and feeder uptake need to influence recommendations.

## Implemented

- Inspection date selector.
- Brood chamber adult bee coverage.
- Dynamic super section from hive setup.
- Dynamic feeder section from hive setup.
- Per-super honey and bee-workforce observations.
- Feed type and uptake observations.
