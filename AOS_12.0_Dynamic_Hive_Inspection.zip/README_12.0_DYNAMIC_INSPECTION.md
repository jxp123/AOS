# AOS 12.0 — Dynamic Hive Inspection

## Added

- Inspection date field for backfilling inspections from previous days.
- Bee coverage renamed/modelled as adult bees covering the brood chamber.
- Supers are generated from the current hive configuration.
- Each super records:
  - bees working this super
  - drawn comb
  - nectar / uncapped honey
  - capped honey
  - action
- Feeders are generated from the current hive configuration.
- Feeders record:
  - feed type
  - amount remaining
  - whether bees are taking feed
- Colony strength estimate now combines brood-chamber bees with bees working supers.
- Honey estimates are calculated per super.

## Important UX principle

Inspection records what was observed.  
Operations records what physically changed.  
The inspection screen is now built from the current hive configuration held in Operations.
