# AOS Professional 12.0 — Operations & Colony Lifecycle

This package is designed for normal use without Inno Setup.

## Install

Double-click:

`INSTALL_AOS.bat`

This will:

- create the AOS application folder
- create the permanent data folder
- back up any existing database before upgrade
- copy the latest application files
- create a desktop shortcut called **AOS Professional**

## Data preservation

Your live data is stored here:

`%LOCALAPPDATA%\AOS\data\aos.db`

Future releases should keep using the same folder.

## Important

This is still a script-based Windows installer, not a compiled `Setup.exe`.

A compiled `Setup.exe` must be built on Windows using an installer compiler such as Inno Setup. This environment cannot compile a real Windows executable.
