from pathlib import Path
APP_VERSION = "7.0.0"
SCHEMA_VERSION = "7.0"
BACKEND_DIR = Path(__file__).resolve().parents[2]
ROOT_DIR = BACKEND_DIR.parent
DATA_DIR = ROOT_DIR / "data"
DB_PATH = DATA_DIR / "aos.db"
EXPORT_DIR = ROOT_DIR / "exports"
IMPORT_DIR = ROOT_DIR / "imports"
BACKUP_DIR = ROOT_DIR / "backups"
LOG_DIR = ROOT_DIR / "logs"
