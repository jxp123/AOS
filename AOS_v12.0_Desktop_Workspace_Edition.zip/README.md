# AOS v12.0 — Desktop Workspace Edition

This release redesigns AOS for PC desktop use.

## Fixed UX issues

- Removed command palette from below tables.
- Added fixed left navigation.
- Added contextual right inspector.
- Added visible feedback after button clicks.
- Home button always returns to Home.
- Open buttons open a visible workspace.
- Select buttons update the inspector.
- Search moved to the top bar.
- Colour-blind-safe status system using both symbols and text.

## Layout

- Left: persistent navigation.
- Centre: main workspace.
- Right: contextual inspector.

## Colour-blind accessibility

Status is never communicated by colour alone:

- ● Urgent
- ▲ Review
- ■ OK
- ◆ Info

Each status also includes a text label.
