@echo off
set AOS_HOME=%LOCALAPPDATA%\AOS
cd /d "%~dp0application"
python backend\main.py
pause
