# AOS 9.1 — Operations & Colony Lifecycle

This release adds non-inspection operations to AOS.

## New Operations workspace

Use the Operations button from a selected colony to record:

- bought queen installed into an existing hive
- feeder added
- super / honey box added

## Queen operation

Records supplier, breed, queen line, colour, year, marking, clipping, introduction method and reason.

AOS closes the previous current queen record for that colony and creates a new current queen record.

## Feeder operation

Records feeder type and capacity. This is separate from inspection because adding a feeder is an action, not an observation.

## Super operation

Records:

- box standard: Langstroth / National / 14x12 / Commercial / WBC / Other
- depth: shallow / medium / deep
- number of frames fitted

This also creates a starter super record for the Honey Production Engine.

## Timeline

Operations now appear in the colony timeline alongside inspections.
