!define APPNAME "AOS Professional"
!define VERSION "8.6.0"
!define COMPANY "AOS"
!define INSTALLDIR "$LOCALAPPDATA\AOS\Application"
!define DATADIR "$LOCALAPPDATA\AOS"

Name "${APPNAME}"
OutFile "..\..\dist\AOS_Professional_8.6_Setup_NSIS.exe"
InstallDir "${INSTALLDIR}"
RequestExecutionLevel user

Page directory
Page instfiles

Section "Install"
  CreateDirectory "${DATADIR}\data"
  CreateDirectory "${DATADIR}\backups"
  CreateDirectory "${DATADIR}\exports"
  CreateDirectory "${DATADIR}\config"
  CreateDirectory "${DATADIR}\logs"

  IfFileExists "${DATADIR}\data\aos.db" 0 +2
    CopyFiles "${DATADIR}\data\aos.db" "${DATADIR}\backups\aos_before_8_6_upgrade.db"

  SetOutPath "$INSTDIR"
  File /r "..\..\application\*.*"

  CreateShortCut "$DESKTOP\AOS Professional.lnk" "$INSTDIR\RunAOS.bat" "" "$INSTDIR\RunAOS.bat"
  CreateDirectory "$SMPROGRAMS\AOS Professional"
  CreateShortCut "$SMPROGRAMS\AOS Professional\AOS Professional.lnk" "$INSTDIR\RunAOS.bat"

  WriteUninstaller "$INSTDIR\Uninstall.exe"
SectionEnd

Section "Uninstall"
  Delete "$DESKTOP\AOS Professional.lnk"
  Delete "$SMPROGRAMS\AOS Professional\AOS Professional.lnk"
  RMDir "$SMPROGRAMS\AOS Professional"
  RMDir /r "$INSTDIR"
  ; User data deliberately preserved in $LOCALAPPDATA\AOS
SectionEnd
