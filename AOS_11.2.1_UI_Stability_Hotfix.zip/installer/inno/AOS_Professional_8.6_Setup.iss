#define MyAppName "AOS Professional"
#define MyAppVersion "8.6.0"
#define MyAppPublisher "AOS"
#define MyAppExeName "RunAOS.bat"

[Setup]
AppId={{D02E49A3-7CC3-4E37-9D1F-8E7CBCCBFAOS}
AppName={#MyAppName}
AppVersion={#MyAppVersion}
AppPublisher={#MyAppPublisher}
DefaultDirName={localappdata}\AOS\Application
DefaultGroupName=AOS Professional
DisableProgramGroupPage=yes
OutputDir=..\..\dist
OutputBaseFilename=AOS_Professional_8.6_Setup
Compression=lzma
SolidCompression=yes
WizardStyle=modern
PrivilegesRequired=lowest
ArchitecturesInstallIn64BitMode=x64compatible
UninstallDisplayIcon={app}\RunAOS.bat

[Languages]
Name: "english"; MessagesFile: "compiler:Default.isl"

[Dirs]
Name: "{localappdata}\AOS"
Name: "{localappdata}\AOS\data"
Name: "{localappdata}\AOS\backups"
Name: "{localappdata}\AOS\exports"
Name: "{localappdata}\AOS\config"
Name: "{localappdata}\AOS\logs"

[Files]
Source: "..\..\application\*"; DestDir: "{app}"; Flags: recursesubdirs createallsubdirs ignoreversion

[Icons]
Name: "{group}\AOS Professional"; Filename: "{app}\RunAOS.bat"; WorkingDir: "{app}"
Name: "{commondesktop}\AOS Professional"; Filename: "{app}\RunAOS.bat"; WorkingDir: "{app}"; Tasks: desktopicon

[Tasks]
Name: "desktopicon"; Description: "Create a desktop shortcut"; GroupDescription: "Additional icons:"; Flags: unchecked

[Run]
Filename: "{app}\RunAOS.bat"; Description: "Launch AOS Professional"; Flags: nowait postinstall skipifsilent

[UninstallDelete]
Type: filesandordirs; Name: "{app}"

[Code]
procedure BackupExistingDatabase();
var
  DataDb: String;
  BackupDir: String;
  BackupPath: String;
begin
  DataDb := ExpandConstant('{localappdata}\AOS\data\aos.db');
  BackupDir := ExpandConstant('{localappdata}\AOS\backups');

  if FileExists(DataDb) then
  begin
    ForceDirectories(BackupDir);
    BackupPath := BackupDir + '\aos_' + GetDateTimeString('yyyymmdd_hhnnss', '', '') + '_before_8_6_upgrade.db';
    FileCopy(DataDb, BackupPath, False);
  end;
end;

function InitializeSetup(): Boolean;
begin
  ForceDirectories(ExpandConstant('{localappdata}\AOS\data'));
  ForceDirectories(ExpandConstant('{localappdata}\AOS\backups'));
  ForceDirectories(ExpandConstant('{localappdata}\AOS\exports'));
  ForceDirectories(ExpandConstant('{localappdata}\AOS\config'));
  ForceDirectories(ExpandConstant('{localappdata}\AOS\logs'));
  BackupExistingDatabase();
  Result := True;
end;
