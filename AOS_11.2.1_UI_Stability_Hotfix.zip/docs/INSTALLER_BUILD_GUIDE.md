# AOS 8.6 Installer Build Guide

## Recommended installer compiler

Use Inno Setup 6.

## Build steps

1. Install Inno Setup 6.
2. Extract this package.
3. Run `build_setup_with_inno.bat`.
4. The final setup executable appears in `dist`.

## Output

`dist/AOS_Professional_8.6_Setup.exe`

## Installer behaviour

- Installs application files under `%LOCALAPPDATA%/AOS/Application`
- Preserves user data under `%LOCALAPPDATA%/AOS`
- Creates data, backups, exports, config and logs folders
- Backs up the database before upgrade
- Creates Start Menu and optional Desktop shortcuts
- Preserves user data on uninstall
