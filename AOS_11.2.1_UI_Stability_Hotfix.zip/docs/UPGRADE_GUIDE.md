# Upgrade Guide

Run the new release's `install_aos.ps1`.

The installer backs up your existing database and replaces only the application files.

Your database remains at:

`%LOCALAPPDATA%\AOS\data\aos.db`
