# Installation Guide

Run `install_aos.ps1`.

The installer creates:

- `%LOCALAPPDATA%\AOS\Application`
- `%LOCALAPPDATA%\AOS\data`
- `%LOCALAPPDATA%\AOS\backups`
- `%LOCALAPPDATA%\AOS\exports`
- `%LOCALAPPDATA%\AOS\config`
- `%LOCALAPPDATA%\AOS\logs`

If an existing database is found, the installer creates a backup before copying application files.
