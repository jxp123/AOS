# User Data Preservation

## Live data location

`%LOCALAPPDATA%\AOS\data\aos.db`

## Backups

`%LOCALAPPDATA%\AOS\backups`

## Upgrade process

1. Installer detects existing database.
2. Installer copies it to backups.
3. Installer replaces application files.
4. AOS starts using the same database.

## Uninstall

Uninstall removes application files only.

It deliberately does not remove:

- database
- backups
- exports
- config
- logs
