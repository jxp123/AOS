# AOS 9.2 — Navigation Stability Hotfix

## Fixed

- NiceGUI deleted-parent slot runtime error when clicking navigation/action buttons.
- Direct UI rebuilds from button callbacks now use deferred stable navigation.
- Version updated to 9.2.

## Data

No database reset is required. Existing data is preserved.
