# AOS 11.2.1 — UI Stability Hotfix

- Removed timer-based deferred navigation.
- Added synchronous defensive navigation.
- Hardened notifications.
- Added stale UI callback exception guard.
