# AOS 11.2 — Interactive Hive Stack Operations

Operations now shows the current hive stack first. Each fitted layer opens actions specific to that equipment type.

Queen replacement is no longer permanently visible; it opens only from **Replace / introduce queen**.
