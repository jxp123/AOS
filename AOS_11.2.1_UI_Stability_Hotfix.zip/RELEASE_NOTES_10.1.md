# AOS 10.1 — Colony Lifecycle Wizard

## User issue

There was no way to add a new nuc or colony to the apiary.

## Resolution

- Added ColonyLifecycleService.
- Added New Colony / Nuc wizard.
- New colonies are added to the Colony State Engine.
- New colony registration creates timeline/operation events.
- Queen details can be registered during colony creation.
- Initial supers are linked into the honey estimate foundation.
