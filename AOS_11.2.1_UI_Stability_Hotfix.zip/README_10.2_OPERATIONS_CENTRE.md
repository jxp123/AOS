# AOS 10.2 — Operations Centre

## User issue

The Operations menu required a selected colony, but the only practical way to select a colony was through Mission Control, which only shows today's work.

## Resolution

Operations is now a whole-apiary dashboard.

It lists:

- Hives
- Nucs

Each card shows operations-relevant information:

- equipment
- health/status
- queen
- last operation
- suggested operation

Each card includes:

- Open
- Operations
- Inspect

## Inspection workflow

Because operations often happen during inspections, the inspection workflow now includes a quick route to record a follow-up operation after saving.

Examples:

- add feeder
- add super
- install queen
- record feeding
- record equipment change
