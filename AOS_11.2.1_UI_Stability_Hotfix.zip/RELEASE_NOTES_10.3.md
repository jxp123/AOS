# AOS 10.3 — Operations Centre Organisation

## User feedback addressed

Operations Centre needed sorting, with default H1, H2, H3 natural order.

## Resolution

- Added natural colony-code sorting.
- Added sort dropdown.
- Added search.
- Added Hive/Nuc filters.
- Added status colour coding.
