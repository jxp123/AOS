$env:AOS_HOME = "$env:LOCALAPPDATA\AOS"
Set-Location ".\application"
python backend\main.py
