from __future__ import annotations

import sqlite3
from datetime import date
from typing import Any, Dict

from aos.core.settings import DB_PATH
from aos.engines.honey_production_engine import HoneyProductionEngine


class SuperRecordService:
    def save_from_inspection(self, code: str, payload: Dict[str, Any]) -> None:
        count = int(float(payload.get("super_count") or 0))
        if count <= 0:
            return
        HoneyProductionEngine().ensure_schema()
        with sqlite3.connect(DB_PATH) as con:
            for _ in range(count):
                con.execute("""
                    INSERT INTO aos_super_records (
                        colony_code, record_date, super_type, frames_total, frames_drawn,
                        percent_capped, percent_uncapped, intended_for_harvest, notes
                    )
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                """, (
                    code,
                    str(date.today()),
                    payload.get("super_type") or "shallow",
                    float(payload.get("frames_total") or 10),
                    float(payload.get("frames_drawn") or 0),
                    float(payload.get("percent_capped") or 0),
                    float(payload.get("percent_uncapped") or 0),
                    1 if payload.get("harvest_intended", True) else 0,
                    "Saved from inspection workflow",
                ))
            con.commit()
