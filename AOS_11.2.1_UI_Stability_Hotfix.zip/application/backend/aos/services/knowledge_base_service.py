from __future__ import annotations
import json, sqlite3
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List
from aos.core.settings import DB_PATH

class KnowledgeBaseService:
    def __init__(self):
        self.db_path = DB_PATH

    def ensure_schema(self):
        Path(self.db_path).parent.mkdir(parents=True, exist_ok=True)
        with sqlite3.connect(self.db_path) as con:
            con.execute("""
                CREATE TABLE IF NOT EXISTS aos_colony_memory (
                    colony_code TEXT PRIMARY KEY,
                    traits_json TEXT NOT NULL,
                    notes_json TEXT NOT NULL,
                    updated_at TEXT NOT NULL
                )
            """)
            con.commit()

    def get_memory(self, code: str) -> Dict[str, Any]:
        self.ensure_schema()
        with sqlite3.connect(self.db_path) as con:
            con.row_factory = sqlite3.Row
            row = con.execute("SELECT * FROM aos_colony_memory WHERE colony_code=?", (code,)).fetchone()
        if not row:
            return {"traits": [], "notes": [], "updated_at": None}
        return {"traits": json.loads(row["traits_json"] or "[]"), "notes": json.loads(row["notes_json"] or "[]"), "updated_at": row["updated_at"]}

    def update_memory(self, code: str, traits: List[str], notes: List[str]) -> Dict[str, Any]:
        self.ensure_schema()
        now = datetime.now().isoformat(timespec="seconds")
        current = self.get_memory(code)
        merged_traits = list(dict.fromkeys((current.get("traits") or []) + traits))
        merged_notes = list(dict.fromkeys((current.get("notes") or []) + notes))[-50:]
        with sqlite3.connect(self.db_path) as con:
            con.execute("""
                INSERT INTO aos_colony_memory (colony_code, traits_json, notes_json, updated_at)
                VALUES (?, ?, ?, ?)
                ON CONFLICT(colony_code) DO UPDATE SET
                    traits_json=excluded.traits_json,
                    notes_json=excluded.notes_json,
                    updated_at=excluded.updated_at
            """, (code, json.dumps(merged_traits), json.dumps(merged_notes), now))
            con.commit()
        return self.get_memory(code)
