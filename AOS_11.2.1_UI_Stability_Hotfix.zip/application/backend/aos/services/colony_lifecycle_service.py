from __future__ import annotations

import sqlite3
from datetime import date, datetime
from pathlib import Path
from typing import Any, Dict, List, Optional

from aos.core.settings import DB_PATH


class ColonyLifecycleService:
    """Creates and archives colonies/nucs as lifecycle events.

    AOS treats a new colony as a biological and operational event, not just a row
    in a table. This service stores a dedicated lifecycle record and also creates
    a baseline operation/timeline event when OperationsService is available.
    """

    def __init__(self):
        self.db_path = DB_PATH

    def ensure_schema(self) -> None:
        Path(self.db_path).parent.mkdir(parents=True, exist_ok=True)
        with sqlite3.connect(self.db_path) as con:
            con.execute("""
                CREATE TABLE IF NOT EXISTS aos_colony_lifecycle (
                    colony_code TEXT PRIMARY KEY,
                    created_date TEXT NOT NULL,
                    status TEXT NOT NULL DEFAULT 'active',
                    entity_type TEXT NOT NULL,
                    apiary TEXT,
                    name TEXT,
                    origin_type TEXT,
                    parent_colony TEXT,
                    supplier TEXT,
                    hive_system TEXT,
                    box_type TEXT,
                    brood_boxes REAL DEFAULT 1,
                    supers REAL DEFAULT 0,
                    frames_per_box REAL DEFAULT 0,
                    floor_type TEXT,
                    roof_type TEXT,
                    feeder_fitted INTEGER DEFAULT 0,
                    queen_excluder INTEGER DEFAULT 0,
                    insulation INTEGER DEFAULT 0,
                    queen_present INTEGER DEFAULT 0,
                    queen_breed TEXT,
                    queen_supplier TEXT,
                    queen_year TEXT,
                    queen_colour TEXT,
                    queen_marked INTEGER DEFAULT 0,
                    queen_clipped INTEGER DEFAULT 0,
                    frames_bees REAL DEFAULT 0,
                    frames_brood REAL DEFAULT 0,
                    frames_stores REAL DEFAULT 0,
                    temperament TEXT,
                    notes TEXT,
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL
                )
            """)
            con.commit()

    def next_code(self, entity_type: str = "Hive") -> str:
        self.ensure_schema()
        prefix = "N" if str(entity_type).lower().startswith("nuc") else "H"
        with sqlite3.connect(self.db_path) as con:
            con.row_factory = sqlite3.Row
            rows = con.execute("SELECT colony_code FROM aos_colony_lifecycle").fetchall()
        max_num = 0
        for r in rows:
            code = str(r["colony_code"] or "")
            if code.startswith(prefix):
                try:
                    max_num = max(max_num, int(code[1:]))
                except Exception:
                    pass
        return f"{prefix}{max_num + 1}"

    def register_colony(self, values: Dict[str, Any]) -> Dict[str, Any]:
        self.ensure_schema()
        code = (values.get("code") or "").strip() or self.next_code(values.get("entity_type") or "Hive")
        now = datetime.now().isoformat(timespec="seconds")
        created_date = values.get("created_date") or str(date.today())

        with sqlite3.connect(self.db_path) as con:
            con.execute("""
                INSERT INTO aos_colony_lifecycle (
                    colony_code, created_date, status, entity_type, apiary, name,
                    origin_type, parent_colony, supplier, hive_system, box_type,
                    brood_boxes, supers, frames_per_box, floor_type, roof_type,
                    feeder_fitted, queen_excluder, insulation,
                    queen_present, queen_breed, queen_supplier, queen_year, queen_colour,
                    queen_marked, queen_clipped,
                    frames_bees, frames_brood, frames_stores, temperament, notes,
                    created_at, updated_at
                )
                VALUES (?, ?, 'active', ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(colony_code) DO UPDATE SET
                    updated_at=excluded.updated_at,
                    status='active',
                    entity_type=excluded.entity_type,
                    apiary=excluded.apiary,
                    name=excluded.name,
                    origin_type=excluded.origin_type,
                    parent_colony=excluded.parent_colony,
                    supplier=excluded.supplier,
                    hive_system=excluded.hive_system,
                    box_type=excluded.box_type,
                    brood_boxes=excluded.brood_boxes,
                    supers=excluded.supers,
                    frames_per_box=excluded.frames_per_box,
                    floor_type=excluded.floor_type,
                    roof_type=excluded.roof_type,
                    feeder_fitted=excluded.feeder_fitted,
                    queen_excluder=excluded.queen_excluder,
                    insulation=excluded.insulation,
                    queen_present=excluded.queen_present,
                    queen_breed=excluded.queen_breed,
                    queen_supplier=excluded.queen_supplier,
                    queen_year=excluded.queen_year,
                    queen_colour=excluded.queen_colour,
                    queen_marked=excluded.queen_marked,
                    queen_clipped=excluded.queen_clipped,
                    frames_bees=excluded.frames_bees,
                    frames_brood=excluded.frames_brood,
                    frames_stores=excluded.frames_stores,
                    temperament=excluded.temperament,
                    notes=excluded.notes
            """, (
                code,
                created_date,
                values.get("entity_type") or "Hive",
                values.get("apiary") or "",
                values.get("name") or code,
                values.get("origin_type") or "",
                values.get("parent_colony") or "",
                values.get("supplier") or "",
                values.get("hive_system") or "",
                values.get("box_type") or "",
                float(values.get("brood_boxes") or 0),
                float(values.get("supers") or 0),
                float(values.get("frames_per_box") or 0),
                values.get("floor_type") or "",
                values.get("roof_type") or "",
                1 if values.get("feeder_fitted") else 0,
                1 if values.get("queen_excluder") else 0,
                1 if values.get("insulation") else 0,
                1 if values.get("queen_present") else 0,
                values.get("queen_breed") or "",
                values.get("queen_supplier") or "",
                values.get("queen_year") or "",
                values.get("queen_colour") or "",
                1 if values.get("queen_marked") else 0,
                1 if values.get("queen_clipped") else 0,
                float(values.get("frames_bees") or 0),
                float(values.get("frames_brood") or 0),
                float(values.get("frames_stores") or 0),
                values.get("temperament") or "",
                values.get("notes") or "",
                now,
                now,
            ))
            con.commit()

        # Profile override makes new colony visible in screens that merge profile data.
        try:
            from aos.services.colony_profile_service import ColonyProfileService
            ColonyProfileService().save(code, {
                "name": values.get("name") or code,
                "type": values.get("entity_type") or "Hive",
                "equipment": self.equipment_summary(values),
                "objective": f"Origin: {values.get('origin_type') or 'unknown'}",
                "notes": values.get("notes") or "",
            })
        except Exception:
            pass

        # Add timeline operation.
        try:
            from aos.services.operations_service import OperationsService
            OperationsService().record_operation(
                code,
                "colony_registered",
                f"{values.get('entity_type') or 'Colony'} registered",
                self.lifecycle_summary(code),
            )
        except Exception:
            pass

        # If queen details are supplied, create queen record.
        if values.get("queen_present"):
            try:
                from aos.services.operations_service import OperationsService
                OperationsService().install_queen(code, {
                    "installed_date": created_date,
                    "supplier": values.get("queen_supplier") or "",
                    "breed": values.get("queen_breed") or "",
                    "queen_line": "",
                    "colour": values.get("queen_colour") or "",
                    "queen_year": values.get("queen_year") or "",
                    "marked": values.get("queen_marked"),
                    "clipped": values.get("queen_clipped"),
                    "introduction_method": "Registered with colony",
                    "reason": "Initial colony registration",
                    "notes": "Queen registered during colony creation.",
                })
            except Exception:
                pass

        # Supers baseline for honey intelligence.
        if float(values.get("supers") or 0) > 0:
            try:
                from aos.services.operations_service import OperationsService
                for _ in range(int(float(values.get("supers") or 0))):
                    OperationsService().add_super(code, {
                        "box_standard": values.get("hive_system") or "",
                        "box_depth": "shallow",
                        "frame_count": values.get("frames_per_box") or 10,
                        "event_date": created_date,
                    })
            except Exception:
                pass

        return self.get_colony(code)

    def equipment_summary(self, values: Dict[str, Any]) -> str:
        bits = []
        for key in ["hive_system", "box_type"]:
            if values.get(key):
                bits.append(str(values.get(key)))
        if values.get("frames_per_box"):
            bits.append(f"{values.get('frames_per_box')} frames")
        if values.get("brood_boxes"):
            bits.append(f"{values.get('brood_boxes')} brood")
        if values.get("supers"):
            bits.append(f"{values.get('supers')} supers")
        if values.get("feeder_fitted"):
            bits.append("feeder fitted")
        return ", ".join(bits)

    def lifecycle_summary(self, code: str) -> str:
        c = self.get_colony(code)
        if not c:
            return f"{code} registered."
        parts = [
            f"{c.get('entity_type')} {code} registered",
            f"origin: {c.get('origin_type') or 'unknown'}",
            f"equipment: {c.get('hive_system') or 'unknown'}",
        ]
        if c.get("parent_colony"):
            parts.append(f"parent: {c.get('parent_colony')}")
        if c.get("supplier"):
            parts.append(f"supplier: {c.get('supplier')}")
        return "; ".join(parts)

    def list_colonies(self, include_archived: bool = False) -> List[Dict[str, Any]]:
        self.ensure_schema()
        where = "" if include_archived else "WHERE status='active'"
        with sqlite3.connect(self.db_path) as con:
            con.row_factory = sqlite3.Row
            rows = con.execute(f"SELECT * FROM aos_colony_lifecycle {where} ORDER BY colony_code").fetchall()
        return [dict(r) for r in rows]

    def get_colony(self, code: str) -> Dict[str, Any]:
        self.ensure_schema()
        with sqlite3.connect(self.db_path) as con:
            con.row_factory = sqlite3.Row
            row = con.execute("SELECT * FROM aos_colony_lifecycle WHERE colony_code=?", (code,)).fetchone()
        return dict(row) if row else {}

    def archive_colony(self, code: str, reason: str = "") -> None:
        self.ensure_schema()
        with sqlite3.connect(self.db_path) as con:
            con.execute(
                "UPDATE aos_colony_lifecycle SET status='archived', notes=COALESCE(notes,'') || ?, updated_at=? WHERE colony_code=?",
                (f"\nArchived: {reason}", datetime.now().isoformat(timespec="seconds"), code),
            )
            con.commit()
        try:
            from aos.services.operations_service import OperationsService
            OperationsService().record_operation(code, "colony_archived", "Colony archived", reason)
        except Exception:
            pass
