from __future__ import annotations

import json
import os
import shutil
import sqlite3
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional
from zipfile import ZipFile

from aos.core.settings import (
    AOS_HOME,
    AOS_DATA_DIR,
    AOS_BACKUP_DIR,
    AOS_EXPORT_DIR,
    AOS_CONFIG_DIR,
    AOS_LOG_DIR,
    DB_PATH,
    APP_VERSION,
    SCHEMA_VERSION,
)


class PersistentDataService:
    """AOS 8.0 persistent data foundation.

    The application can be replaced release-by-release, while apiary data remains in
    a stable user data folder. This service creates the folder structure, migrates
    older embedded databases when possible, backs up data, and supports export/import.
    """

    def __init__(self):
        self.db_path = Path(DB_PATH)

    def ensure_directories(self) -> None:
        for p in [AOS_HOME, AOS_DATA_DIR, AOS_BACKUP_DIR, AOS_EXPORT_DIR, AOS_CONFIG_DIR, AOS_LOG_DIR]:
            Path(p).mkdir(parents=True, exist_ok=True)

    def _connect(self):
        self.ensure_directories()
        return sqlite3.connect(self.db_path)

    def _find_embedded_databases(self) -> List[Path]:
        candidates: List[Path] = []
        cwd = Path.cwd()
        for root in [cwd, cwd.parent, cwd.parent.parent]:
            for name in ["aos.db", "aos.sqlite", "apiary.db"]:
                p = root / name
                if p.exists() and p.resolve() != self.db_path.resolve():
                    candidates.append(p)
            for p in root.rglob("*.db"):
                if p.name.lower() in ["aos.db", "apiary.db"] and p.resolve() != self.db_path.resolve():
                    candidates.append(p)
        # preserve order and uniqueness
        seen = set()
        clean = []
        for p in candidates:
            key = str(p.resolve())
            if key not in seen:
                clean.append(p)
                seen.add(key)
        return clean[:10]

    def initialise(self) -> Dict[str, object]:
        self.ensure_directories()
        migrated_from = None

        if not self.db_path.exists():
            candidates = self._find_embedded_databases()
            if candidates:
                shutil.copy2(candidates[0], self.db_path)
                migrated_from = str(candidates[0])
            else:
                self._create_empty_database()

        self.ensure_metadata()
        self.run_migrations()
        backup = self.backup_database(reason="startup")

        return {
            "aos_home": str(AOS_HOME),
            "database": str(self.db_path),
            "migrated_from": migrated_from,
            "backup": backup,
            "app_version": APP_VERSION,
            "schema_version": SCHEMA_VERSION,
        }

    def _create_empty_database(self) -> None:
        with sqlite3.connect(self.db_path) as con:
            con.execute("PRAGMA journal_mode=WAL")
            con.execute("""
                CREATE TABLE IF NOT EXISTS aos_metadata (
                    key TEXT PRIMARY KEY,
                    value TEXT NOT NULL,
                    updated_at TEXT NOT NULL
                )
            """)
            con.commit()

    def ensure_metadata(self) -> None:
        with self._connect() as con:
            con.execute("""
                CREATE TABLE IF NOT EXISTS aos_metadata (
                    key TEXT PRIMARY KEY,
                    value TEXT NOT NULL,
                    updated_at TEXT NOT NULL
                )
            """)
            now = datetime.now().isoformat(timespec="seconds")
            for key, value in [
                ("app_version", APP_VERSION),
                ("schema_version", SCHEMA_VERSION),
                ("aos_home", str(AOS_HOME)),
            ]:
                con.execute("""
                    INSERT INTO aos_metadata (key, value, updated_at)
                    VALUES (?, ?, ?)
                    ON CONFLICT(key) DO UPDATE SET value=excluded.value, updated_at=excluded.updated_at
                """, (key, str(value), now))
            con.commit()

    def get_metadata(self) -> Dict[str, str]:
        self.ensure_metadata()
        with self._connect() as con:
            con.row_factory = sqlite3.Row
            rows = con.execute("SELECT key, value FROM aos_metadata").fetchall()
        return {r["key"]: r["value"] for r in rows}

    def run_migrations(self) -> Dict[str, object]:
        """Lightweight idempotent migration runner.

        AOS services remain responsible for their own feature tables, but this creates
        the central metadata, audit and migration tracking tables.
        """
        applied = []
        with self._connect() as con:
            con.execute("""
                CREATE TABLE IF NOT EXISTS aos_schema_migrations (
                    version TEXT PRIMARY KEY,
                    applied_at TEXT NOT NULL,
                    description TEXT
                )
            """)
            con.execute("""
                CREATE TABLE IF NOT EXISTS aos_audit_log (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    event_type TEXT NOT NULL,
                    details_json TEXT,
                    created_at TEXT NOT NULL
                )
            """)
            now = datetime.now().isoformat(timespec="seconds")
            migrations = [
                ("8.0.0", "Persistent data foundation metadata/audit tables"),
            ]
            for version, desc in migrations:
                exists = con.execute(
                    "SELECT 1 FROM aos_schema_migrations WHERE version=?",
                    (version,),
                ).fetchone()
                if not exists:
                    con.execute(
                        "INSERT INTO aos_schema_migrations (version, applied_at, description) VALUES (?, ?, ?)",
                        (version, now, desc),
                    )
                    applied.append(version)
            con.commit()
        return {"applied": applied}

    def backup_database(self, reason: str = "manual") -> Optional[str]:
        self.ensure_directories()
        if not self.db_path.exists():
            return None
        stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        dest = Path(AOS_BACKUP_DIR) / f"aos_{stamp}_{reason}.db"
        shutil.copy2(self.db_path, dest)
        self.prune_backups()
        return str(dest)

    def prune_backups(self, keep: int = 40) -> None:
        backups = sorted(Path(AOS_BACKUP_DIR).glob("aos_*.db"), key=lambda p: p.stat().st_mtime, reverse=True)
        for p in backups[keep:]:
            try:
                p.unlink()
            except Exception:
                pass

    def export_apiary(self) -> str:
        self.ensure_directories()
        stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        export_path = Path(AOS_EXPORT_DIR) / f"AOS_Apiary_{stamp}.zip"
        self.backup_database(reason="pre_export")
        with ZipFile(export_path, "w") as z:
            if self.db_path.exists():
                z.write(self.db_path, "data/aos.db")
            config_file = Path(AOS_CONFIG_DIR) / "settings.json"
            if config_file.exists():
                z.write(config_file, "config/settings.json")
            manifest = {
                "created_at": datetime.now().isoformat(timespec="seconds"),
                "app_version": APP_VERSION,
                "schema_version": SCHEMA_VERSION,
                "database": "data/aos.db",
            }
            z.writestr("MANIFEST.json", json.dumps(manifest, indent=2))
        return str(export_path)

    def import_apiary(self, zip_path: str, make_backup: bool = True) -> Dict[str, object]:
        self.ensure_directories()
        if make_backup and self.db_path.exists():
            self.backup_database(reason="pre_import")
        source = Path(zip_path)
        if not source.exists():
            raise FileNotFoundError(zip_path)
        with ZipFile(source, "r") as z:
            members = z.namelist()
            db_member = "data/aos.db" if "data/aos.db" in members else None
            if db_member is None:
                for m in members:
                    if m.endswith(".db"):
                        db_member = m
                        break
            if db_member is None:
                raise ValueError("No database found in import package.")
            tmp_db = Path(AOS_DATA_DIR) / "_imported_aos.db"
            with z.open(db_member) as src, open(tmp_db, "wb") as dst:
                shutil.copyfileobj(src, dst)
            shutil.move(str(tmp_db), self.db_path)
        self.ensure_metadata()
        self.run_migrations()
        return {"imported": True, "database": str(self.db_path)}

    def create_sandbox(self) -> Dict[str, str]:
        self.ensure_directories()
        sandbox = Path(AOS_DATA_DIR) / "sandbox_aos.db"
        if self.db_path.exists():
            shutil.copy2(self.db_path, sandbox)
        else:
            self._create_empty_database()
            shutil.copy2(self.db_path, sandbox)
        return {"sandbox": str(sandbox)}

    def promote_sandbox(self) -> Dict[str, str]:
        sandbox = Path(AOS_DATA_DIR) / "sandbox_aos.db"
        if not sandbox.exists():
            raise FileNotFoundError("No sandbox database exists.")
        self.backup_database(reason="pre_sandbox_promote")
        shutil.copy2(sandbox, self.db_path)
        return {"promoted": str(sandbox), "database": str(self.db_path)}

    def status(self) -> Dict[str, object]:
        self.ensure_directories()
        metadata = self.get_metadata()
        backups = sorted(Path(AOS_BACKUP_DIR).glob("aos_*.db"), key=lambda p: p.stat().st_mtime, reverse=True)
        exports = sorted(Path(AOS_EXPORT_DIR).glob("AOS_Apiary_*.zip"), key=lambda p: p.stat().st_mtime, reverse=True)
        return {
            "aos_home": str(AOS_HOME),
            "database": str(self.db_path),
            "database_exists": self.db_path.exists(),
            "metadata": metadata,
            "latest_backup": str(backups[0]) if backups else None,
            "backup_count": len(backups),
            "latest_export": str(exports[0]) if exports else None,
            "export_count": len(exports),
        }
