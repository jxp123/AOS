from __future__ import annotations

import sqlite3
from datetime import datetime
from pathlib import Path
from typing import Any, Dict

from aos.core.settings import DB_PATH


class ColonyProfileService:
    """Small editable profile layer for user-maintained colony metadata.

    This avoids forcing UI screens to edit seed/static colony records directly. The
    service stores overrides and screens merge these overrides on top of the
    repository colony record.
    """

    def __init__(self):
        self.db_path = DB_PATH

    def ensure_schema(self) -> None:
        Path(self.db_path).parent.mkdir(parents=True, exist_ok=True)
        with sqlite3.connect(self.db_path) as con:
            con.execute("""
                CREATE TABLE IF NOT EXISTS aos_colony_profile_overrides (
                    colony_code TEXT PRIMARY KEY,
                    name TEXT,
                    colony_type TEXT,
                    equipment TEXT,
                    objective TEXT,
                    notes TEXT,
                    updated_at TEXT NOT NULL
                )
            """)
            con.commit()

    def get(self, code: str) -> Dict[str, Any]:
        self.ensure_schema()
        with sqlite3.connect(self.db_path) as con:
            con.row_factory = sqlite3.Row
            row = con.execute(
                "SELECT * FROM aos_colony_profile_overrides WHERE colony_code=?",
                (code,),
            ).fetchone()
        return dict(row) if row else {}

    def save(self, code: str, values: Dict[str, Any]) -> Dict[str, Any]:
        self.ensure_schema()
        clean = {
            "name": values.get("name") or "",
            "colony_type": values.get("type") or values.get("colony_type") or "",
            "equipment": values.get("equipment") or "",
            "objective": values.get("objective") or "",
            "notes": values.get("notes") or "",
            "updated_at": datetime.now().isoformat(timespec="seconds"),
        }
        with sqlite3.connect(self.db_path) as con:
            con.execute("""
                INSERT INTO aos_colony_profile_overrides
                    (colony_code, name, colony_type, equipment, objective, notes, updated_at)
                VALUES (?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(colony_code) DO UPDATE SET
                    name=excluded.name,
                    colony_type=excluded.colony_type,
                    equipment=excluded.equipment,
                    objective=excluded.objective,
                    notes=excluded.notes,
                    updated_at=excluded.updated_at
            """, (
                code,
                clean["name"],
                clean["colony_type"],
                clean["equipment"],
                clean["objective"],
                clean["notes"],
                clean["updated_at"],
            ))
            con.commit()
        return self.get(code)

    def merge(self, code: str, colony: Dict[str, Any]) -> Dict[str, Any]:
        result = dict(colony or {})
        override = self.get(code)
        if not override:
            return result
        if override.get("name"):
            result["name"] = override["name"]
        if override.get("colony_type"):
            result["type"] = override["colony_type"]
        if override.get("equipment"):
            result["equipment"] = override["equipment"]
        if override.get("objective"):
            result["objective"] = override["objective"]
        if override.get("notes"):
            result["profile_notes"] = override["notes"]
        result["profile_updated_at"] = override.get("updated_at")
        return result
