from __future__ import annotations

from typing import Dict, List

from aos.engines.colony_state_engine import ColonyStateEngine
from aos.engines.colony_intelligence_engine import ColonyIntelligenceEngine

try:
    from aos.engines.apiary_intelligence_engine import ApiaryIntelligenceEngine
except Exception:
    ApiaryIntelligenceEngine = None


class ProfessionalBaselineService:
    """AOS 7.0 consolidated product baseline.

    This service exists to verify that the application's major engines are available
    and can work together from a single release package.
    """

    def healthcheck(self) -> Dict[str, object]:
        checks: List[Dict[str, str]] = []

        def add(name: str, fn):
            try:
                fn()
                checks.append({"name": name, "status": "PASS"})
            except Exception as exc:
                checks.append({"name": name, "status": "REVIEW", "detail": str(exc)})

        add("Colony State Engine", lambda: ColonyStateEngine().all_states())
        add("Colony Intelligence Engine", lambda: [ColonyIntelligenceEngine().analyse(s.code) for s in ColonyStateEngine().all_states()[:1]])
        if ApiaryIntelligenceEngine:
            add("Apiary Intelligence Engine", lambda: ApiaryIntelligenceEngine().summary())

        score = round(100 * len([c for c in checks if c["status"] == "PASS"]) / max(1, len(checks)))
        return {"score": score, "checks": checks}
