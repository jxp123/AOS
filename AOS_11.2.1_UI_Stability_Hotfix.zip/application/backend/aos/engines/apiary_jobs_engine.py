from __future__ import annotations

from datetime import date, timedelta
from typing import Any, Dict, List

from aos.engines.colony_state_engine import ColonyStateEngine
from aos.engines.evidence_based_intelligence_engine import EvidenceBasedIntelligenceEngine


class ApiaryJobsEngine:
    """Converts colony state into practical work columns for Mission Control."""

    def __init__(self):
        self.state_engine = ColonyStateEngine()

    def _clean_reason(self, reason: str) -> str:
        text = str(reason or "").strip()
        if not text:
            return ""
        chunks = []
        for part in text.replace(". ", ".|").split("|"):
            part = part.strip()
            if part:
                chunks.append(part if part.endswith(".") else part + ".")
        clean = []
        seen = set()
        for chunk in chunks:
            key = chunk.lower()
            if key not in seen:
                clean.append(chunk)
                seen.add(key)
        return " ".join(clean)

    def _job(self, code: str, title: str, lane: str, priority: str, reason: str, due: str = None, action: str = "Inspect") -> Dict[str, Any]:
        return {
            "code": code,
            "title": title,
            "lane": lane,
            "priority": priority,
            "reason": self._clean_reason(reason),
            "due": due or str(date.today()),
            "action": action,
        }

    def jobs(self) -> List[Dict[str, Any]]:
        jobs: List[Dict[str, Any]] = []
        evidence_engine = EvidenceBasedIntelligenceEngine()
        inspected_today_codes = set()
        for state in self.state_engine.all_states():
            s = state.asdict()
            code = s["code"]
            if evidence_engine.inspected_today(code):
                inspected_today_codes.add(code)
                continue

            if s["status"] in ["Overdue", "No inspection record", "Swarm risk"]:
                jobs.append(self._job(
                    code,
                    f"Inspect {code}",
                    "Today",
                    "Urgent",
                    s.get("explain") or s.get("next_action"),
                    action="Inspect",
                ))
                continue

            if s["next_action"] == "Check stores / feed":
                jobs.append(self._job(
                    code,
                    f"Check stores / feed {code}",
                    "Today",
                    "Urgent",
                    s.get("explain") or "Stores appear low.",
                    action="Inspect",
                ))
                continue

            if s["lane"] == "Watch Closely":
                jobs.append(self._job(
                    code,
                    f"Review {code}",
                    "Watch List",
                    "Review",
                    s.get("explain") or "Colony needs attention.",
                    action="Open",
                ))
                continue

            days = s.get("days_since_inspection")
            if days is not None:
                remaining = max(0, 7 - int(days))
                if remaining <= 2:
                    jobs.append(self._job(
                        code,
                        f"Inspection due soon: {code}",
                        "This Week",
                        "Soon",
                        s.get("explain") or f"Next inspection in {remaining} day(s).",
                        due=str(date.today() + timedelta(days=remaining)),
                        action="Open",
                    ))

        try:
            for op in EvidenceBasedIntelligenceEngine().operation_jobs():
                jobs.append(self._job(
                    op["code"],
                    op["title"],
                    "Today",
                    op.get("priority", "Operation"),
                    op.get("reason", ""),
                    action="Open",
                ))
        except Exception:
            pass
        return jobs

    def mission_lanes(self) -> Dict[str, List[Dict[str, Any]]]:
        lanes = {"Today": [], "This Week": [], "Watch List": [], "Completed Today": []}
        for j in self.jobs():
            lanes.setdefault(j["lane"], []).append(j)
        return lanes

    def summary(self) -> Dict[str, Any]:
        lanes = self.mission_lanes()
        return {
            "today": len(lanes.get("Today", [])),
            "this_week": len(lanes.get("This Week", [])),
            "watch": len(lanes.get("Watch List", [])),
            "completed": len(lanes.get("Completed Today", [])),
            "total_jobs": sum(len(v) for v in lanes.values()),
        }
