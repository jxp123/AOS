from __future__ import annotations

from typing import Dict, List

from aos.engines.colony_state_engine import ColonyStateEngine
from aos.engines.honey_production_engine import HoneyProductionEngine


class ApiaryIntelligenceCentre:
    """Whole-apiary intelligence report.

    This replaces the old low-value Analysis table with a strategic intelligence view.
    """

    def __init__(self):
        self.state_engine = ColonyStateEngine()
        self.honey_engine = HoneyProductionEngine()

    def report(self) -> Dict[str, object]:
        states = [s.asdict() for s in self.state_engine.all_states()]
        total = len(states)
        urgent = [s for s in states if s.get("lane") == "Do Today"]
        watch = [s for s in states if s.get("lane") == "Watch Closely"]
        current = [s for s in states if s.get("status") == "Current"]
        avg_health = round(sum(int(s.get("health") or 0) for s in states) / total) if total else 0
        honey = self.honey_engine.estimate_apiary()

        executive = (
            f"The apiary currently contains {total} colonies with an average health score of {avg_health}%. "
            f"{len(urgent)} colonies require attention today and {len(watch)} colonies are on the watch list. "
            f"{len(current)} colonies are currently marked as current. "
        )
        executive += honey.get("summary", "")

        emerging_risks: List[str] = []
        for s in urgent[:8]:
            emerging_risks.append(f"{s.get('code')}: {s.get('status')} — {s.get('explain')}")
        if not emerging_risks:
            emerging_risks.append("No urgent risks are currently flagged.")

        trends: List[str] = [
            f"Average colony health: {avg_health}%.",
            f"Inspection workload today: {len(urgent)} urgent colony/collonies.",
            f"Watch-list load: {len(watch)} colony/collonies.",
        ]
        if honey.get("available"):
            trends.append(f"Honey estimate: {honey.get('extractable_low')}–{honey.get('extractable_high')} kg extractable.")
            trends.append(f"Ripening honey estimate: {honey.get('ripening_low')}–{honey.get('ripening_high')} kg.")
        else:
            trends.append("Honey production estimate is not yet available because super records are missing.")

        recommendations: List[str] = []
        for s in urgent[:5]:
            recommendations.append(f"{s.get('code')}: {s.get('next_action')}")
        if honey.get("available") and honey.get("ripening_high", 0) > 0:
            recommendations.append("Review supers again within the next inspection cycle to confirm ripening progress.")
        if not recommendations:
            recommendations.append("Continue routine monitoring and keep inspection data current.")

        knowledge: List[str] = [
            "AOS is building long-term apiary knowledge from inspections, colony memory and super records.",
            "Future comparisons will strengthen as more repeated observations are entered.",
        ]
        if honey.get("available"):
            top = honey.get("top_contributors") or []
            if top:
                knowledge.append("Current top honey contributors: " + ", ".join(t["colony_code"] for t in top) + ".")

        confidence = {
            "overall": "Medium" if total else "Low",
            "inspection_coverage": "Good" if len(current) > max(1, total // 2) else "Needs improvement",
            "honey_estimate": "Available" if honey.get("available") else "Needs super records",
        }

        return {
            "executive": executive,
            "confidence": confidence,
            "emerging_risks": emerging_risks,
            "trends": trends,
            "recommendations": recommendations,
            "knowledge": knowledge,
            "honey": honey,
            "states": states,
        }
