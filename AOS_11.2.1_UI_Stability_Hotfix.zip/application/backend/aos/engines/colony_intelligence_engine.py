from __future__ import annotations
from dataclasses import dataclass, asdict
from datetime import date, timedelta
from typing import Any, Dict, List
from aos.engines.colony_state_engine import ColonyStateEngine
from aos.engines.evidence_based_intelligence_engine import EvidenceBasedIntelligenceEngine
from aos.services.knowledge_base_service import KnowledgeBaseService

try:
    from aos.engines.inspection_workspace_v32 import timeline_items
except Exception:
    timeline_items = None

@dataclass
class ColonyIntelligence:
    code: str
    executive_summary: str
    overall_health: int
    confidence: int
    current_assessment: str
    strengths: List[str]
    concerns: List[str]
    trends: List[str]
    predictions: List[str]
    recommendations: List[str]
    personality: List[str]
    apiary_comparison: List[str]
    history_summary: List[str]
    next_actions: List[str]
    alerts: List[str]
    next_inspection_date: str
    why: Dict[str, List[str]]

    def asdict(self) -> Dict[str, Any]:
        return asdict(self)

class ColonyIntelligenceEngine:
    def __init__(self):
        self.state_engine = ColonyStateEngine()

    def _history(self, code: str) -> List[Dict[str, Any]]:
        try:
            return timeline_items(code) if timeline_items else []
        except Exception:
            return []

    def _apiary_average_health(self) -> int:
        states = self.state_engine.all_states()
        if not states:
            return 0
        return round(sum(int(s.health or 0) for s in states) / len(states))

    def analyse(self, code: str) -> ColonyIntelligence:
        state = self.state_engine.state_for(code).asdict()
        history = self._history(code)
        health = int(state.get("health") or 0)
        confidence = int(state.get("confidence") or 0)

        strengths = []
        if state.get("queen_status") in ["Seen", "Laying evidence"]:
            strengths.append("Queen status has supporting evidence.")
        if state.get("swarm_risk") == "Low":
            strengths.append("No significant swarm indicators are currently recorded.")
        if state.get("starvation_risk") == "Low":
            strengths.append("Stores are not currently flagged as critical.")
        if not strengths:
            strengths.append("AOS is still learning this colony; more inspection evidence is needed.")

        concerns = list(state.get("warnings") or [])
        if not concerns:
            concerns.append("No major concerns are currently flagged.")

        trends = []
        if state.get("days_since_inspection") is None:
            trends.append("Trend confidence is low because there is no dated inspection record.")
        else:
            trends.append(f"Last inspection was {state.get('days_since_inspection')} day(s) ago.")
        trends.append(f"AOS has {len(history)} timeline item(s) to learn from.")

        predictions = []
        if state.get("status") == "Current":
            predictions.append("Routine monitoring is likely sufficient unless the next inspection reveals new concerns.")
        else:
            predictions.append("A full inspection is likely to improve confidence and may change the colony lane.")
        if state.get("starvation_risk") == "High":
            predictions.append("Stores may become limiting if not corrected.")
        if state.get("swarm_risk") in ["High", "Moderate"]:
            predictions.append("Swarm-control decisions may be needed before the next routine inspection.")

        evidence_rec = EvidenceBasedIntelligenceEngine().primary_recommendation(code)
        recommendations = []
        if evidence_rec:
            recommendations.append(evidence_rec.get("recommendation", ""))
        if state.get("next_action"):
            recommendations.append(state.get("next_action"))
        if state.get("queen_status") == "Unconfirmed":
            recommendations.append("Confirm queen status and look for eggs or young larvae.")
        if state.get("starvation_risk") == "High":
            recommendations.append("Check stores and feed if stores remain low.")
        if not recommendations:
            recommendations.append("Continue routine monitoring.")

        personality = ["Learning…"]
        if health >= 80:
            personality.append("Currently stable.")
        if health < 60:
            personality.append("Requires active support.")
        if state.get("queen_status") == "Seen":
            personality.append("Queen evidence present.")
        if state.get("swarm_risk") == "Low":
            personality.append("No current swarm tendency detected.")
        if state.get("starvation_risk") == "High":
            personality.append("Stores-sensitive colony.")
        if len(history) >= 5:
            personality.append("Sufficient history for emerging behavioural patterns.")

        try:
            mem = KnowledgeBaseService().update_memory(code, personality, history_summary[:3])
            personality = list(dict.fromkeys(personality + (mem.get("traits") or [])))
        except Exception:
            pass

        avg = self._apiary_average_health()
        if avg:
            if health > avg + 10:
                apiary_comparison = [f"{code} is performing above the apiary average health score ({health}% vs {avg}%)."]
            elif health < avg - 10:
                apiary_comparison = [f"{code} is performing below the apiary average health score ({health}% vs {avg}%)."]
            else:
                apiary_comparison = [f"{code} is broadly in line with the apiary average health score ({health}% vs {avg}%)."]
        else:
            apiary_comparison = ["Apiary comparison is in early learning mode."]

        history_summary = []
        for item in history[:5]:
            history_summary.append(f"{item.get('date', 'Undated')}: {item.get('title') or item.get('type') or 'Record'}. {item.get('details') or ''}".strip())
        if not history_summary:
            history_summary.append("No meaningful history is available yet.")

        next_date = date.today() + timedelta(days=7 if state.get("status") == "Current" else 0)

        executive = (
            f"{code} is currently assessed as {state.get('status')} with a health score of {health}%. "
            f"{state.get('explain') or 'AOS is still building confidence in this assessment.'}"
        )
        assessment = (
            f"AOS places this colony in the {state.get('lane')} lane. "
            f"Confidence is {confidence}% based on inspection and colony-state evidence."
        )

        alerts = []
        if state.get("lane") == "Do Today":
            alerts.append("This colony requires attention today.")
        if state.get("swarm_risk") == "High":
            alerts.append("Swarm risk is high.")
        if state.get("starvation_risk") == "High":
            alerts.append("Stores may be critically low.")

        if evidence_rec:
            concerns.append("Evidence-based recommendation: " + evidence_rec.get("reasoning", ""))

        why = {
            "status": [state.get("explain", "")],
            "recommendations": recommendations,
            "concerns": concerns,
            "confidence": [f"Confidence is {confidence}% based on available inspection, queen and stores evidence."],
        }

        return ColonyIntelligence(
            code=code,
            executive_summary=executive,
            overall_health=health,
            confidence=confidence,
            current_assessment=assessment,
            strengths=strengths,
            concerns=concerns,
            trends=trends,
            predictions=predictions,
            recommendations=recommendations,
            personality=personality,
            apiary_comparison=apiary_comparison,
            history_summary=history_summary,
            next_actions=recommendations,
            alerts=alerts,
            next_inspection_date=str(next_date),
            why=why,
        )
