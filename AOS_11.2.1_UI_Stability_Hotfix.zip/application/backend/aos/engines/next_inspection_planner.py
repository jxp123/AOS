from __future__ import annotations

from datetime import date, timedelta
from typing import Any, Dict


class NextInspectionPlanner:
    """Calculates next recommended inspection.

    Rule: never longer than 7 days. Concerns shorten the interval.
    """

    def _bool(self, value: Any) -> bool:
        if isinstance(value, bool):
            return value
        return str(value).lower() in ["1", "true", "yes", "seen"]

    def _num(self, value: Any) -> float:
        try:
            return float(value or 0)
        except Exception:
            return 0.0

    def recommend(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        days = 7
        reasons = ["Routine 7-day inspection interval."]

        queen_seen = self._bool(payload.get("queen_seen"))
        eggs_seen = self._bool(payload.get("eggs_seen"))
        queen_cells = self._num(payload.get("queen_cells"))
        stores = self._num(payload.get("stores_frames"))
        brood_pattern = str(payload.get("brood_pattern") or "").lower()
        disease_signs = str(payload.get("disease_signs") or "").lower()
        swarm_action = str(payload.get("swarm_action") or "").lower()

        if queen_cells > 0 or swarm_action not in ["", "none", "unknown"]:
            days = min(days, 2)
            reasons = ["Swarm-risk evidence or swarm action recorded. Recheck quickly."]

        if not queen_seen and not eggs_seen:
            days = min(days, 3)
            reasons.append("Queen and eggs were not confirmed.")

        if stores and stores <= 1:
            days = min(days, 3)
            reasons.append("Stores were low; check feed or stores again.")

        if brood_pattern in ["patchy", "poor"]:
            days = min(days, 4)
            reasons.append("Brood pattern needs follow-up.")

        if disease_signs and disease_signs not in ["none", "unknown"]:
            days = min(days, 2)
            reasons.append("Disease signs or concern recorded.")

        next_date = date.today() + timedelta(days=days)
        return {
            "next_inspection_date": str(next_date),
            "interval_days": days,
            "reason": " ".join(dict.fromkeys(reasons)),
        }
