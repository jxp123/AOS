from __future__ import annotations
from typing import Dict, List
from aos.engines.colony_state_engine import ColonyStateEngine

class ApiaryIntelligenceEngine:
    def summary(self) -> Dict[str, object]:
        states = [s.asdict() for s in ColonyStateEngine().all_states()]
        total = len(states)
        if not states:
            return {"summary": "No colonies available.", "insights": [], "average_health": 0}
        avg_health = round(sum(int(s.get("health") or 0) for s in states) / total)
        current = len([s for s in states if s.get("status") == "Current"])
        urgent = len([s for s in states if s.get("lane") == "Do Today"])
        watch = len([s for s in states if s.get("lane") == "Watch Closely"])
        insights: List[str] = [
            f"{total} colonies are currently known to AOS.",
            f"Average colony health is {avg_health}%.",
            f"{current} colonies are current.",
            f"{urgent} colonies need attention today.",
            f"{watch} colonies are on the watch list.",
        ]
        return {"summary": f"Apiary average health is {avg_health}% across {total} colonies.", "insights": insights, "average_health": avg_health}
