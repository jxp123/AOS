from __future__ import annotations

from typing import Any, Dict, List
import re

from aos.engines.colony_state_engine import ColonyStateEngine

try:
    from aos.services.colony_lifecycle_service import ColonyLifecycleService
except Exception:
    ColonyLifecycleService = None

try:
    from aos.services.operations_service import OperationsService
except Exception:
    OperationsService = None

try:
    from aos.engines.evidence_based_intelligence_engine import EvidenceBasedIntelligenceEngine
except Exception:
    EvidenceBasedIntelligenceEngine = None



def natural_code_key(code: str):
    text = str(code or "").strip().upper()
    m = re.match(r"([A-Z]+)(\d+)$", text)
    if m:
        return (m.group(1), int(m.group(2)))
    return (text, 0)


class OperationsCentreEngine:
    """Whole-apiary operations dashboard.

    This is deliberately different from Mission Control:
    - Mission Control shows today's work.
    - Operations Centre shows every active hive/nuc so the beekeeper can choose one
      and record a management event.
    """

    def __init__(self):
        self.state_engine = ColonyStateEngine()

    def _lifecycle_lookup(self) -> Dict[str, Dict[str, Any]]:
        if not ColonyLifecycleService:
            return {}
        try:
            rows = ColonyLifecycleService().list_colonies()
            return {r.get("colony_code"): r for r in rows if r.get("colony_code")}
        except Exception:
            return {}

    def _last_operation(self, code: str) -> str:
        if not OperationsService:
            return "No operation recorded"
        try:
            rows = OperationsService().timeline_operations(code)
            if rows:
                r = rows[0]
                return f"{r.get('date', 'Undated')}: {r.get('title', r.get('type', 'Operation'))}"
        except Exception:
            pass
        return "No operation recorded"

    def _recommendation(self, code: str, state: Dict[str, Any]) -> str:
        if EvidenceBasedIntelligenceEngine:
            try:
                rec = EvidenceBasedIntelligenceEngine().primary_recommendation(code)
                if rec and rec.get("title"):
                    return rec.get("title")
            except Exception:
                pass
        return state.get("next_action") or "Routine monitoring"

    def _equipment(self, state: Dict[str, Any], life: Dict[str, Any]) -> str:
        bits = []
        if life:
            for key in ["hive_system", "box_type"]:
                if life.get(key):
                    bits.append(str(life.get(key)))
            if life.get("frames_per_box"):
                bits.append(f"{life.get('frames_per_box')} frames")
            if life.get("supers"):
                bits.append(f"{life.get('supers')} supers")
            if life.get("feeder_fitted"):
                bits.append("feeder fitted")
        if not bits:
            for key in ["equipment", "type"]:
                if state.get(key):
                    bits.append(str(state.get(key)))
        return ", ".join(bits) or "Equipment not recorded"


    def sort_cards(self, cards: List[Dict[str, Any]], sort_by: str = "Apiary order") -> List[Dict[str, Any]]:
        sort_by = sort_by or "Apiary order"
        if sort_by == "Health lowest first":
            return sorted(cards, key=lambda x: (int(x.get("health") or 0), natural_code_key(x.get("code"))))
        if sort_by == "Health highest first":
            return sorted(cards, key=lambda x: (-int(x.get("health") or 0), natural_code_key(x.get("code"))))
        if sort_by == "Status":
            return sorted(cards, key=lambda x: (str(x.get("status") or ""), natural_code_key(x.get("code"))))
        if sort_by == "Suggested operation":
            return sorted(cards, key=lambda x: (str(x.get("suggested_operation") or ""), natural_code_key(x.get("code"))))
        if sort_by == "Last operation":
            return sorted(cards, key=lambda x: (str(x.get("last_operation") or ""), natural_code_key(x.get("code"))))
        if sort_by == "Colony code":
            return sorted(cards, key=lambda x: natural_code_key(x.get("code")))
        return sorted(cards, key=lambda x: natural_code_key(x.get("code")))

    def filter_cards(self, cards: List[Dict[str, Any]], query: str = "") -> List[Dict[str, Any]]:
        query = (query or "").strip().lower()
        if not query:
            return cards
        result = []
        for card in cards:
            haystack = " ".join(str(v) for v in card.values() if v is not None).lower()
            if query in haystack:
                result.append(card)
        return result

    def cards(self) -> Dict[str, List[Dict[str, Any]]]:
        life = self._lifecycle_lookup()
        hives: List[Dict[str, Any]] = []
        nucs: List[Dict[str, Any]] = []

        for s in self.state_engine.all_states():
            st = s.asdict()
            code = st.get("code")
            lc = life.get(code, {})
            entity_type = (lc.get("entity_type") or st.get("type") or "").lower()
            card = {
                "code": code,
                "title": code,
                "entity_type": lc.get("entity_type") or st.get("type") or "Hive",
                "status": st.get("status"),
                "lane": st.get("lane"),
                "health": st.get("health"),
                "queen": lc.get("queen_breed") or st.get("queen_status") or st.get("queen_id") or "Unknown",
                "equipment": self._equipment(st, lc),
                "last_operation": self._last_operation(code),
                "suggested_operation": self._recommendation(code, st),
                "reason": st.get("explain") or "",
            }
            if "nuc" in entity_type or str(code).upper().startswith("N"):
                nucs.append(card)
            else:
                hives.append(card)

        return {
            "hives": sorted(hives, key=lambda x: natural_code_key(x.get("code"))),
            "nucs": sorted(nucs, key=lambda x: natural_code_key(x.get("code"))),
        }
