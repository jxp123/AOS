from __future__ import annotations

import sqlite3
from dataclasses import dataclass, asdict
from datetime import date
from typing import Any, Dict, List

from aos.core.settings import DB_PATH


SUPER_KG = {
    "shallow": 12.0,
    "medium": 16.0,
    "deep": 24.0,
    "national shallow": 12.0,
    "langstroth shallow": 14.0,
    "langstroth medium": 18.0,
    "langstroth deep": 27.0,
}


@dataclass
class HoneyEstimate:
    colony_code: str
    supers: int
    estimated_extractable_kg_low: float
    estimated_extractable_kg_high: float
    ripening_kg_low: float
    ripening_kg_high: float
    notes: str

    def asdict(self) -> Dict[str, Any]:
        return asdict(self)


class HoneyProductionEngine:
    """Estimates honey from current super records.

    The engine is deliberately conservative. It separates:
    - capped/extractable honey
    - uncapped/ripening honey

    If no super table exists yet, it returns a data-needed insight rather than guessing.
    """

    def __init__(self):
        self.db_path = DB_PATH

    def ensure_schema(self) -> None:
        with sqlite3.connect(self.db_path) as con:
            con.execute("""
                CREATE TABLE IF NOT EXISTS aos_super_records (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    colony_code TEXT NOT NULL,
                    record_date TEXT NOT NULL,
                    super_type TEXT DEFAULT 'shallow',
                    frames_total REAL DEFAULT 10,
                    frames_drawn REAL DEFAULT 0,
                    percent_capped REAL DEFAULT 0,
                    percent_uncapped REAL DEFAULT 0,
                    intended_for_harvest INTEGER DEFAULT 1,
                    notes TEXT
                )
            """)
            con.commit()

    def list_super_records(self) -> List[Dict[str, Any]]:
        self.ensure_schema()
        with sqlite3.connect(self.db_path) as con:
            con.row_factory = sqlite3.Row
            rows = con.execute("""
                SELECT * FROM aos_super_records
                ORDER BY record_date DESC, colony_code ASC, id ASC
            """).fetchall()
        return [dict(r) for r in rows]

    def latest_by_colony(self) -> Dict[str, List[Dict[str, Any]]]:
        records = self.list_super_records()
        latest_date = {}
        for r in records:
            code = r["colony_code"]
            latest_date[code] = max(latest_date.get(code, ""), r.get("record_date") or "")
        grouped: Dict[str, List[Dict[str, Any]]] = {}
        for r in records:
            code = r["colony_code"]
            if (r.get("record_date") or "") == latest_date.get(code):
                grouped.setdefault(code, []).append(r)
        return grouped

    def estimate_colony(self, code: str, records: List[Dict[str, Any]]) -> HoneyEstimate:
        extractable = 0.0
        ripening = 0.0
        supers = 0
        for r in records:
            if not int(r.get("intended_for_harvest") or 0):
                continue
            supers += 1
            super_type = str(r.get("super_type") or "shallow").lower()
            capacity = SUPER_KG.get(super_type, SUPER_KG["shallow"])
            frames_total = float(r.get("frames_total") or 10) or 10
            frames_drawn = min(float(r.get("frames_drawn") or 0), frames_total)
            capped = max(0.0, min(100.0, float(r.get("percent_capped") or 0))) / 100.0
            uncapped = max(0.0, min(100.0, float(r.get("percent_uncapped") or 0))) / 100.0
            drawn_factor = frames_drawn / frames_total
            extractable += capacity * drawn_factor * capped
            ripening += capacity * drawn_factor * uncapped

        return HoneyEstimate(
            colony_code=code,
            supers=supers,
            estimated_extractable_kg_low=round(extractable * 0.85, 1),
            estimated_extractable_kg_high=round(extractable * 1.05, 1),
            ripening_kg_low=round(ripening * 0.70, 1),
            ripening_kg_high=round(ripening * 0.95, 1),
            notes="Estimate is based on current super records, frame draw, capped percentage and uncapped percentage.",
        )

    def estimate_apiary(self) -> Dict[str, Any]:
        grouped = self.latest_by_colony()
        estimates = [self.estimate_colony(code, rows) for code, rows in grouped.items()]
        low = round(sum(e.estimated_extractable_kg_low for e in estimates), 1)
        high = round(sum(e.estimated_extractable_kg_high for e in estimates), 1)
        rip_low = round(sum(e.ripening_kg_low for e in estimates), 1)
        rip_high = round(sum(e.ripening_kg_high for e in estimates), 1)

        if not estimates:
            return {
                "available": False,
                "summary": "No super records are available yet. Add super state during inspections to enable honey estimates.",
                "extractable_low": 0,
                "extractable_high": 0,
                "ripening_low": 0,
                "ripening_high": 0,
                "colonies": [],
            }

        top = sorted(estimates, key=lambda e: e.estimated_extractable_kg_high, reverse=True)[:5]
        return {
            "available": True,
            "summary": f"Estimated extractable honey is {low}–{high} kg, with a further {rip_low}–{rip_high} kg ripening.",
            "extractable_low": low,
            "extractable_high": high,
            "ripening_low": rip_low,
            "ripening_high": rip_high,
            "colonies": [e.asdict() for e in estimates],
            "top_contributors": [e.asdict() for e in top],
        }
