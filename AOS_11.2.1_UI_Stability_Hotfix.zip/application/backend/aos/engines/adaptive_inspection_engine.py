from __future__ import annotations

from typing import Any, Dict, List

from aos.engines.colony_state_engine import ColonyStateEngine


def _field(label: str, field: str, field_type: str, reason: str, options=None, default=None) -> Dict[str, Any]:
    return {
        "label": label,
        "field": field,
        "type": field_type,
        "reason": reason,
        "options": options or [],
        "default": default,
    }


class AdaptiveInspectionEngine:
    """Turns Colony State Engine output into an inspection guide and form specification."""

    def state(self, code: str) -> Dict[str, Any]:
        return ColonyStateEngine().state_for(code).asdict()

    def focus(self, code: str) -> List[Dict[str, Any]]:
        state = self.state(code)
        focus: List[Dict[str, Any]] = []

        def add(title, reason, severity="review"):
            focus.append({"title": title, "reason": reason, "severity": severity})

        if state.get("status") in ["Overdue", "No inspection record"]:
            add("Complete full inspection", state.get("explain", "Inspection is due."), "urgent")

        if state.get("queen_status") in ["Unconfirmed", "Laying evidence"]:
            add("Confirm queen status", "Queen was not directly confirmed in the latest evidence.", "review")

        if state.get("starvation_risk") == "High":
            add("Check stores carefully", "Previous evidence suggests stores may be low.", "urgent")
        else:
            add("Record stores", "Stores determine whether feeding or adding frames is needed.", "standard")

        if state.get("swarm_risk") in ["High", "Moderate"]:
            add("Assess swarm signs", "Brood expansion or queen-cell evidence suggests swarm risk.", "urgent")
        else:
            add("Check space and queen cells", "Routine swarm prevention check.", "standard")

        if state.get("health", 100) < 70:
            add("Assess brood pattern and disease signs", "Health score is reduced; confirm brood quality and visible disease signs.", "review")
        else:
            add("Record brood strength", "Brood trend supports next inspection timing and colony strength.", "standard")

        return focus

    def questions(self, code: str) -> List[Dict[str, Any]]:
        state = self.state(code)
        questions = [
            _field("Queen seen", "queen_seen", "bool", "Confirms queenright status.", default=False),
            _field("Eggs seen", "eggs_seen", "bool", "Fresh eggs confirm recent laying even if queen is not seen.", default=False),
            _field("Larvae / open brood seen", "larvae_seen", "bool", "Open brood confirms brood continuity.", default=False),
            _field("Brood frames", "brood_frames", "number", "Tracks colony growth and swarm risk.", default=0),
            _field("Stores frames", "stores_frames", "number", "Confirms feeding/supering needs.", default=0),
            _field("Bee coverage frames", "bee_coverage_frames", "number", "Tracks colony strength.", default=0),
            _field("Queen cells", "queen_cells", "number", "Any queen cells affect swarm risk and next action.", default=0),
            _field("Temperament", "temperament", "select", "Tracks handling quality and queen-line suitability.", ["Calm", "OK", "Defensive", "Aggressive", "Unknown"], "Unknown"),
        ]

        # Add targeted questions that answer the reason the colony was flagged.
        if state.get("starvation_risk") == "High" or state.get("next_action") == "Check stores / feed":
            questions.append(_field("Feeding started", "feeding_started", "bool", "Low stores were flagged; confirm whether feed was given.", default=False))

        if state.get("swarm_risk") in ["High", "Moderate"]:
            questions.append(_field("Swarm action taken", "swarm_action", "select", "Swarm risk was flagged; record the action taken.", ["None", "Added super", "Removed queen cells", "Artificial swarm", "Made nuc", "Other"], "None"))

        if state.get("health", 100) < 70:
            questions.append(_field("Brood pattern", "brood_pattern", "select", "Low health was flagged; brood pattern explains colony condition.", ["Excellent", "Good", "Patchy", "Poor", "Unknown"], "Unknown"))
            questions.append(_field("Disease signs", "disease_signs", "select", "Low health was flagged; confirm visible disease signs.", ["None", "Chalkbrood", "Sacbrood", "EFB concern", "AFB concern", "Other", "Unknown"], "Unknown"))

        return questions

    def post_inspection_message(self, code: str) -> Dict[str, Any]:
        state = self.state(code)
        return {
            "title": f"{code} inspection updated",
            "state": state.get("status"),
            "lane": state.get("lane"),
            "health": state.get("health"),
            "next_action": state.get("next_action"),
            "reason": state.get("explain"),
        }
