from aos.core.settings import APP_VERSION, DB_PATH
from aos.services.system_health_service import SystemHealthService

from aos.services.persistent_data_service import PersistentDataService


def diagnostic_rows():
    try:
        report = SystemHealthService().health_report()
        status = report.get("status", "Unknown")
    except Exception as e:
        status = f"Health check failed: {e}"
    return [
        {"item": "AOS version", "value": APP_VERSION},
        {"item": "Database path", "value": str(DB_PATH)},
        {"item": "Health status", "value": status},
    ]
