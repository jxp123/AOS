from nicegui import ui
from aos.core.bootstrap import boot
from aos.ui.aos3_desktop import render_aos3
from aos.ui.diagnostics import diagnostic_rows
from aos.services.data_portability_service import DataPortabilityService
from aos.services.professional_baseline_service import ProfessionalBaselineService
from aos.services.persistent_data_service import PersistentDataService

boot()
PersistentDataService().initialise()

@ui.page("/")
def index():
    render_aos3()


@ui.page("/data")
def data_management():
    ui.label("AOS Data Management").classes("text-h4")
    status = PersistentDataService().status()

    ui.label("Persistent data location").classes("text-h5")
    ui.label(status["aos_home"])
    ui.label(f"Database: {status['database']}")
    ui.label(f"Latest backup: {status.get('latest_backup') or 'None'}")
    ui.label(f"Latest export: {status.get('latest_export') or 'None'}")

    with ui.row():
        def do_backup():
            path = PersistentDataService().backup_database(reason="manual")
            ui.notify(f"Backup created: {path}", type="positive")

        def do_export():
            path = PersistentDataService().export_apiary()
            ui.notify(f"Export created: {path}", type="positive")

        def do_sandbox():
            result = PersistentDataService().create_sandbox()
            ui.notify(f"Sandbox created: {result['sandbox']}", type="positive")

        ui.button("Create Backup", on_click=do_backup)
        ui.button("Export Apiary", on_click=do_export)
        ui.button("Create Sandbox Copy", on_click=do_sandbox)

    ui.label("Metadata").classes("text-h5")
    rows = [{"key": k, "value": v} for k, v in status.get("metadata", {}).items()]
    ui.table(
        columns=[
            {"name":"key","label":"Key","field":"key"},
            {"name":"value","label":"Value","field":"value"},
        ],
        rows=rows,
        row_key="key",
    ).classes("w-full")


@ui.page("/export-data")
def data_export_page():
    ui.label("AOS Data Export").classes("text-h4")
    try:
        json_path = DataPortabilityService().export_json()
        db_path = DataPortabilityService().export_sqlite_backup()
        ui.label(f"JSON export created: {json_path}")
        ui.label(f"SQLite backup created: {db_path}")
    except Exception as e:
        ui.label(str(e)).classes("text-negative")


@ui.page("/healthcheck")
def healthcheck():
    ui.label("AOS 7.0 Professional Baseline Healthcheck").classes("text-h4")
    result = ProfessionalBaselineService().healthcheck()
    ui.label(f"Score: {result['score']}%").classes("text-h5")
    ui.table(
        columns=[
            {"name":"name","label":"Check","field":"name"},
            {"name":"status","label":"Status","field":"status"},
            {"name":"detail","label":"Detail","field":"detail"},
        ],
        rows=result["checks"],
        row_key="name",
    ).classes("w-full")

@ui.page("/diag")
def diag():
    ui.label("AOS Diagnostics").classes("text-h4")
    ui.table(
        columns=[
            {"name":"item","label":"Item","field":"item"},
            {"name":"value","label":"Value","field":"value"},
        ],
        rows=diagnostic_rows(),
        row_key="item",
    ).classes("w-full")

ui.run(title="AOS 7.0 Professional Edition", host="127.0.0.1", port=8000, reload=False)
