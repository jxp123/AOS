# AOS 8.1 — Apiary Intelligence Centre

This release replaces the old low-value Analysis workspace with a whole-apiary Intelligence Centre.

## Added

- Apiary Intelligence Centre
- Executive apiary brief
- Emerging risks
- Recommendations
- Trends
- Knowledge observations
- Honey Production Estimate
- Supers / Honey section in inspection workflow
- Super records saved from inspections

## Honey estimate

AOS estimates honey from current super records:

- super type
- number of supers
- frames in super
- frames drawn / occupied
- % capped
- % filled but uncapped
- whether intended for harvest

It reports:

- estimated extractable honey now
- estimated ripening honey
- top contributing colonies

The estimate is deliberately conservative and returns a range rather than a single number.
