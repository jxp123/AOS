@echo off
set AOS_HOME=%LOCALAPPDATA%\AOS
cd /d "%~dp0"
python backend\main.py
pause
