# AOS 7.0 — Professional Edition

## Purpose

Consolidates the AOS 6.0 Colony Intelligence programme into a single release.

## Highlights

- One intelligence-driven Colony Workspace.
- One Colony State Engine powering operational state.
- One task-centric Mission Control model.
- Inspection completion refreshes state.
- Colony profile details can be edited.
- Living Knowledge Base persists colony memory.
- Explainable AI shows reasoning through Why? sections.
- Healthcheck route added for engine validation.
