# AOS 4.2 — Adaptive Inspection Intelligence

## User feedback addressed

- Current colonies should not remain in Do Today.
- Static inspection priorities were confusing.
- Concerns from previous inspections should become direct questions in the inspection form.

## Resolution

- Added AdaptiveInspectionEngine.
- Added targeted questions based on stores, swarm risk, health and queen status.
- Added State Engine consistency guard.
- Added reason text to Mission Control cards.
