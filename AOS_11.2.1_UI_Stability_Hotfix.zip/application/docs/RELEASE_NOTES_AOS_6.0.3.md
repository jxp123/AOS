# AOS 6.0.3 — Colony Personality

Adds emerging colony personality traits.
