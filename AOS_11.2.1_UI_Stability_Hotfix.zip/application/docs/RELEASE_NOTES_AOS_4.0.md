# AOS 4.0 — Colony State Engine

## User-reported issue

After finishing an inspection for H2, Mission Control still showed H2 as Overdue.

## Cause

Mission Control was reading precomputed/stale card status rather than deriving state from the latest inspection.

## Fix

A new Colony State Engine now calculates operational status from inspection records every time Mission Control is loaded.
