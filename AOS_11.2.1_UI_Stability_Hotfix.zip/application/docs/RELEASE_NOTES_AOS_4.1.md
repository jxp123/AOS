# AOS 4.1 — Commit Inspection & State Refresh

## User issue

Inspection was entered and Finish Inspection clicked, but Mission Control still showed the colony as Overdue.

## Cause

The inspection workflow staged the inspection but Mission Control calculated status from committed inspection records.

## Fix

Added InspectionCommitService and connected the Colony State Engine to committed inspection events.
