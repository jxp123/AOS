# AOS 7.1 — Intelligent Inspection Workflow

## User feedback addressed

- Start Inspection created a deleted-parent lifecycle error.
- Completed Today showed a due date that was not meaningful.
- Completed Today needed next inspection date and summary.

## Resolution

- Added NextInspectionPlanner.
- Replaced Start Inspection with Record Inspection.
- Added page-anchor scroll behaviour for inspection form.
- Completed Today now shows next recommended inspection rather than due date.
