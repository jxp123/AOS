# AOS 6.0.2 — AI Colony Workspace

Replaces Colony Workspace with an intelligence-report layout.
