# AOS 6.0.8 — Living Knowledge Base

Adds persistent colony memory foundations.
