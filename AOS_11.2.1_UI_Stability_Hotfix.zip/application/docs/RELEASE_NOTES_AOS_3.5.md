# AOS 3.5 — Colony Summary & Live Status Update

## User-reported issues

- Colony record screen was hard to understand.
- After finishing an inspection, the operational board did not visibly change from overdue to current.

## Changes

- Added readable Colony Snapshot.
- Moved full technical record into expandable panel.
- Added session-level live completion state.
- Completed colonies now show Current in Mission Control immediately.
- Successful inspection returns to Mission Control so the update is visible.
