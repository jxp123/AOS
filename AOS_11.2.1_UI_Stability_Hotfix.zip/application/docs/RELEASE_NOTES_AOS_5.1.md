# AOS 5.1 — Task Board Inspect Fix

## User feedback addressed

- Done button did not make sense.
- Inspect from the operational dashboard did not open inspection.
- Explanation text repeated the same sentence twice.

## Resolution

- Removed Done from task cards.
- Added guarded inspection launcher.
- Deduplicated explanation text.
