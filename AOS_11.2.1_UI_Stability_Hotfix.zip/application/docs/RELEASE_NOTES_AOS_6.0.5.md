# AOS 6.0.5 — Apiary Intelligence

Adds apiary-level comparison and insights.
