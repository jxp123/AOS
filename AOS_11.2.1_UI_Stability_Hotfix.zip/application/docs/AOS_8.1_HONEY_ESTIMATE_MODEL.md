# AOS 8.1 Honey Estimate Model

## Inputs

- Colony
- Super type
- Super count
- Frames total
- Frames drawn / occupied
- % capped
- % uncapped
- Harvest intended

## Outputs

- Extractable honey range
- Ripening honey range
- Apiary total
- Colony contribution

## Conservative assumptions

Capped honey is treated as extractable.
Uncapped honey is treated as ripening and discounted.
All estimates are ranges.
