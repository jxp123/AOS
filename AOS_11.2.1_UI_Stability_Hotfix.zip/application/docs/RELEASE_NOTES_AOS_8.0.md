# AOS 8.0 — Persistent Data Foundation

## Purpose

Makes AOS safe for real-world use by separating application releases from user data.

## Added

- Persistent data directory
- Persistent database path
- Startup data initialisation
- Automatic startup backup
- Migration tracking
- Data Management page
- Apiary export
- Import API foundation
- Sandbox copy
- Backup pruning

## User impact

Future AOS releases should no longer wipe inspection data when extracted or installed.
