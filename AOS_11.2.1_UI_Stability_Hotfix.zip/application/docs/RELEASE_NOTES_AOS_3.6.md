# AOS 3.6 — apply_live_status Hotfix

## Fixed
- 500 server error caused by `apply_live_status` not being defined.
- Startup should now proceed normally.
