# AOS 8.0 Data Model

## Folder structure

~/AOS/
  data/
    aos.db
  backups/
    aos_YYYYMMDD_HHMMSS_startup.db
  exports/
    AOS_Apiary_YYYYMMDD_HHMMSS.zip
  config/
  logs/

## Environment override

Set `AOS_HOME` to choose a different location.

Example:

AOS_HOME=D:\AOS_Data

## Database

The active database is:

`AOS_HOME/data/aos.db`

## Upgrade principle

Future release ZIPs replace the application code only. They must not overwrite `AOS_HOME`.
