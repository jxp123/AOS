# AOS 5.0 — Task-Centric Mission Control

## User feedback addressed

- Today's Jobs and Operational Board were inconsistent.
- Due jobs such as H17 should appear in the board.
- Upcoming was unclear.
- Inspect from the dashboard did not reliably open inspection.

## Resolution

- Added ApiaryJobsEngine.
- Replaced primary board with Today / This Week / Watch List / Completed Today.
- Fixed dashboard Inspect actions.
- Kept colony-state view as a secondary expandable view.
