# AOS 6.0.1 — Intelligence Core

Adds the ColonyIntelligenceEngine core narrative model.
