# AOS 6.0.6 — Explainable AI

Adds Why? reasoning for status and recommendations.
