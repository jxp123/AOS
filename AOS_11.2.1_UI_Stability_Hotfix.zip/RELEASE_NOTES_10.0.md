# AOS 10.0 — Evidence-Based Intelligence Engine

## Fixed / improved

- Colonies inspected today are removed from inspection jobs for today.
- Store/feed recommendations are not automatically turned into repeat inspections.
- Free-text inspection notes are analysed for management context.
- Feeding recommendations now check for phrases such as feeder present, not taking syrup, ignoring feed.
- Evidence-based recommendations are shown in the Colony Workspace.
- Operation jobs are separated from inspection jobs.

## Data safety

No data reset is required. Install using `INSTALL_AOS.bat`; the database remains in `%LOCALAPPDATA%\AOS\data\aos.db`.
