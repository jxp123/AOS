# AOS 10.0 — Evidence-Based Intelligence Engine

## Purpose

AOS now reasons from both structured inspection fields and free-text notes.

## Key rules

1. A colony inspected today should not return as another inspection job today.
2. Follow-up needs after inspection become operations, not duplicate inspections.
3. Notes are used as evidence.

## Example

If stores are low but the notes say:

> feeder present and bees are not using it

AOS no longer blindly recommends another inspection or simple feeding. It reasons:

- stores are low
- feeder is already fitted
- bees are not taking syrup
- therefore immediate feeding is uncertain
- monitor stores at the next scheduled inspection unless conditions worsen

## New engine

`EvidenceBasedIntelligenceEngine`

Outputs:

- recommendation
- confidence
- evidence for
- evidence against
- reasoning
- operation vs inspection classification
- next inspection date
