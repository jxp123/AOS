# AOS 11.0 — Colony Configuration & Inspection Integration

AOS now treats each colony as a current physical configuration — a digital twin — rather than isolated add/remove events.

## Added

- Current hive stack / digital twin.
- Configure Hive workspace.
- Add/update/remove components.
- Current configuration shown in Colony Workspace.
- Feeder feed-type support: 1:1 syrup, 2:1 syrup, fondant, dry sugar, pollen patty, protein substitute.
- Evidence engine uses fitted feeder/feed state.
- Inspection loads current supers and feeders.
- Separate observations per super.
- Super observations feed the honey estimate engine.
- Operations during inspection shortcut.
