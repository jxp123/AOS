# AOS 10.1 — Colony Lifecycle Wizard

## Added

AOS now supports registering new colonies and nucs directly from the UI.

## New workspace

Use:

**New Colony**

from the Workspaces menu.

## The wizard records

### Identity
- Hive or nuc
- Colony code, or auto-generate
- Apiary/location
- Name/label

### Origin
- Bought nuc
- Bought full colony
- Artificial split
- Swarm
- Moved from another apiary
- Colony united
- Other
- Parent colony, if relevant
- Supplier/source

### Equipment
- Hive system: Langstroth, National, 14x12, Dadant, Commercial, WBC, Other
- Box type
- Brood boxes
- Supers
- Frames per box
- Floor and roof type
- Feeder
- Queen excluder
- Insulation

### Queen
- Queen present
- Breed/strain
- Supplier/breeder
- Year
- Mark colour
- Marked/clipped

### Starting condition
- Frames of bees
- Brood
- Stores
- Temperament
- Notes

## Intelligence benefit

AOS now understands where a colony came from and its baseline equipment, queen and strength. This gives the Evidence-Based Intelligence Engine better context for future recommendations.
