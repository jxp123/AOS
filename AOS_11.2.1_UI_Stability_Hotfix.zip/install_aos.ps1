param(
    [string]$InstallDir = "$env:LOCALAPPDATA\AOS\Application",
    [string]$DataDir = "$env:LOCALAPPDATA\AOS"
)

$ErrorActionPreference = "Stop"
Write-Host "AOS Professional 8.5 Installer Candidate" -ForegroundColor Cyan
Write-Host "Install directory: $InstallDir"
Write-Host "Data directory:    $DataDir"

$BackupDir = Join-Path $DataDir "backups"
$DataDb = Join-Path $DataDir "data\aos.db"
$Timestamp = Get-Date -Format "yyyyMMdd_HHmmss"

New-Item -ItemType Directory -Force -Path $InstallDir | Out-Null
New-Item -ItemType Directory -Force -Path (Join-Path $DataDir "data") | Out-Null
New-Item -ItemType Directory -Force -Path $BackupDir | Out-Null
New-Item -ItemType Directory -Force -Path (Join-Path $DataDir "exports") | Out-Null
New-Item -ItemType Directory -Force -Path (Join-Path $DataDir "config") | Out-Null
New-Item -ItemType Directory -Force -Path (Join-Path $DataDir "logs") | Out-Null

if (Test-Path $DataDb) {
    $BackupPath = Join-Path $BackupDir "aos_${Timestamp}_before_8_5_upgrade.db"
    Copy-Item $DataDb $BackupPath -Force
    Write-Host "Backup created: $BackupPath" -ForegroundColor Green
} else {
    Write-Host "No existing database found. AOS will initialise a new database on first launch." -ForegroundColor Yellow
}

Write-Host "Copying application files..."
Copy-Item -Path ".\application\*" -Destination $InstallDir -Recurse -Force

$Launcher = Join-Path $DataDir "Run AOS.ps1"
@"
`$env:AOS_HOME = "$DataDir"
Set-Location "$InstallDir"
python backend\main.py
"@ | Set-Content -Path $Launcher -Encoding UTF8

$Desktop = [Environment]::GetFolderPath("Desktop")
$ShortcutPath = Join-Path $Desktop "AOS Professional.lnk"
$WScriptShell = New-Object -ComObject WScript.Shell
$Shortcut = $WScriptShell.CreateShortcut($ShortcutPath)
$Shortcut.TargetPath = "powershell.exe"
$Shortcut.Arguments = "-ExecutionPolicy Bypass -File `"$Launcher`""
$Shortcut.WorkingDirectory = $InstallDir
$Shortcut.Save()

Write-Host "Installation complete." -ForegroundColor Green
Write-Host "Launch AOS using the desktop shortcut: AOS Professional"
Write-Host "Your data is stored in: $DataDir"
