param([string]$InstallDir = "$env:LOCALAPPDATA\AOS\Application")
if (Test-Path $InstallDir) { Remove-Item $InstallDir -Recurse -Force }
Write-Host "Application removed. User data remains in: $env:LOCALAPPDATA\AOS"
