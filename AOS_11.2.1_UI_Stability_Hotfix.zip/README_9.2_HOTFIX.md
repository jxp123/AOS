# AOS 9.2 — Navigation Stability Hotfix

This hotfix addresses the NiceGUI runtime error:

`RuntimeError: The parent element this slot belongs to has been deleted.`

## Cause

Some buttons rebuilt the current screen directly from inside their own button callback.  
When the page container is cleared during that callback, NiceGUI can detect that the button's parent slot has already been deleted.

## Fix

Navigation actions are now deferred very slightly using a stable navigation helper.  
This lets the click event finish before AOS clears and rebuilds the page.

## What to test

- Mission Control → Open
- Mission Control → Inspect
- Colony Workspace → Record Inspection
- Colony Workspace → History
- Colony Workspace → Trends
- Colony Workspace → Operations
- Colony Workspace → Mission Control

## Install

Run `INSTALL_AOS.bat`.  
Your data remains in `%LOCALAPPDATA%\AOS\data\aos.db`.
