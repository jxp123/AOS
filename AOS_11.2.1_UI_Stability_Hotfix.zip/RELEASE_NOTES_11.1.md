# AOS 11.1 — Operations Hive Setup UX

## User feedback addressed

- Configure Hive should sit under Operations, not exist as its own feature.
- Current setup should be visible and amendable against each current option.
- Additional fields should depend on equipment type.

## Implemented

- Operations now opens directly to the current hive setup.
- Each current component has its own amend/remove panel.
- Quick add buttons create new equipment in the setup.
- Equipment-specific fields for feeders, supers, brood boxes and fixed hive parts.
