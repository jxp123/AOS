# AOS 11.1 — Operations Hive Setup UX

## Changed

Configure Hive is no longer treated as a standalone feature. It now lives inside Operations.

## Operations now defaults to the current setup

Each fitted component is displayed as an amendable row:

- roof
- crownboard
- brood box
- floor
- feeders
- supers
- queen excluder
- dummy board
- insulation

Each current item can be amended or removed directly.

## Add equipment

Quick add buttons sit below the current setup:

- Add brood box
- Add feeder
- Add super
- Add queen excluder
- Add dummy board
- Add insulation
- Add crownboard
- Add roof
- Add floor

After adding, the item appears in the current setup and can be amended with fields relevant to that equipment type.

## Feeders

Feeders ask feeder-specific questions:

- feeder type / asset label
- feed type / contents
- amount added / capacity
- remaining amount

## Supers and brood boxes

Boxes ask box-specific questions:

- standard
- depth
- number of frames
