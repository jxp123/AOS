# AOS 10.2 — Operations Centre

## Added

- Whole-apiary Operations Centre.
- Hives and nucs listed separately.
- Mission Control-style cards for operations.
- Direct links to Open, Operations and Inspect.
- Quick path from inspection completion to follow-up operation.

## Changed

- Left-menu Operations no longer requires a pre-selected colony.
