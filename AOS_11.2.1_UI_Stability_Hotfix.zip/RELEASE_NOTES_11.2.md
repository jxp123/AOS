# AOS 11.2 — Interactive Hive Stack Operations

- Interactive hive stack layers.
- Component-specific action dialogs.
- Hidden queen replacement wizard.
- Feeder actions: refill, change feed, move, remove.
- Super actions: inspect honey, harvest, move, remove.
