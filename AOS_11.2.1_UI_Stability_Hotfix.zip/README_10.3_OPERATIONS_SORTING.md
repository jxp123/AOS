# AOS 10.3 — Operations Centre Organisation

## Added

- Natural default sorting: H1, H2, H3, H10 rather than H1, H10, H2.
- Sort dropdown.
- Live search.
- Hives/Nucs visibility filters.
- Separate Hives and Nucs groups retained.
- Status-coloured card borders.

## Default order

AOS now uses apiary-natural order by default:

- H1
- H2
- H3
- H10
- N1
- N2
- N10

## Sort options

- Apiary order
- Colony code
- Health lowest first
- Health highest first
- Status
- Suggested operation
- Last operation

## Search

Search matches across colony code, equipment, queen, status, last operation and suggested operation.
