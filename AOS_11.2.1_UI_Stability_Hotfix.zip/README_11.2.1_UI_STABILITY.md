# AOS 11.2.1 — UI Stability Hotfix

Fixes the recurring NiceGUI deleted-parent-slot runtime error by removing timer-based navigation and wrapping UI notifications/callbacks defensively.

Install with `INSTALL_AOS.bat`. Existing data remains in `%LOCALAPPDATA%\AOS\data\aos.db`.
