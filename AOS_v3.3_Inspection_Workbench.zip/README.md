# AOS v3.3 — Inspection Workbench

This release adds the practical workflow layer between the 7-day scheduler and recording inspections.

## Added

- Inspection Workbench tab.
- Select due/overdue colonies from a work queue.
- Record quick external checks.
- Stage guided drafts directly from the work queue.
- Inspection note editing.
- Inspection delete.
- Operations now points users to the workbench.
- AI export includes workbench data.
- Self-test includes workbench check.

## Use

Start with:
1. **Apiary Brain**
2. **Operations**
3. **Inspection Workbench**
4. **Guided Inspection** or **Records → Inspections**
