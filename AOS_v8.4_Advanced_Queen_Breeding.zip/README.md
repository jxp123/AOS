# AOS v8.4 — Advanced Queen Breeding

Adds pedigree/family-tree workspace and advanced queen-breeding framework.
